import { EtudiantDTO } from "./etudiant.dto";
import { MatiereDTO } from "./matiere.dto";

export interface TypeUEDTO {
    nomTypeUE: string;
    matieres: MatiereDTO[];
    etudiants: EtudiantDTO[];
  }
  