export interface NoteDTO {
    etudiantId: number;
    nomEtudiant: string;
    prenomEtudiant: string;
    matricule: string;
    noteClasse: number;
    noteExamen: number;
    moyenne: number;
    noteCredit: number;
    validation: string; // "Validé" ou "Non Validé"
  }
  