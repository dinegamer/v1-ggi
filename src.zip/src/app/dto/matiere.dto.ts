import { NoteDTO } from "./note.dto";


export interface MatiereDTO {
  nomMatiere: string;
  credit: number;
  notes: NoteDTO[];
}
