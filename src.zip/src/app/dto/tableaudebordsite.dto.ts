import { Cycle } from "../model/cycle.model";
import { FiliereDTO } from './filiere.dto';
export interface TableauDeBordSite{
    cycle: Cycle,
    filieres: FiliereDTO[],
    nombreetudiant: number,
    frai: number,
    reduction: number,
    payes: number,
    reliquats: number,
    reliquatsPayes: number,
}