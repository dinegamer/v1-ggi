import { Filiere } from "../model/filiere.model";

export interface FiliereDTO{
    filiere: Filiere
    nombreinscrit: number
    frai: number,
    reduction: number
    payes: number
    reliquats: number
    reliquatsPayes: number
}