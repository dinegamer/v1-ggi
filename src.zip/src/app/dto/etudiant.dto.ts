export interface EtudiantDTO {
    id: number;
    nom: string;
    prenom: string;
    matricule: string;
  }
  