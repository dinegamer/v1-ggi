import { Anneeuv } from "../model/anneeuv.model";
import { Etudiant } from "../model/etudiant.model";
import { Filiere } from "../model/filiere.model";
import { Semestre } from "../model/semestre.model";
import { Notepartypeue } from "./notepartypeue";

export interface Noteparsemestre {
    semestre: Semestre;
    noteParTypeUe: Notepartypeue[];
    mgsemestre: string;
    creditsemestre: string;
    mentionsemestre: string;
    appreciationsemestre: string;
    anneeuv: Anneeuv;
    filiere: Filiere;
    etudiant: Etudiant;
}
