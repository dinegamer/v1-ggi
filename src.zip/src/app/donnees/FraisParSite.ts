import { Site } from "../model/site.model";
import { FraisParCycle } from "./FraisParCycle";

export interface FraisParSite{
    site: Site;
    fraisParCycles: FraisParCycle[]
    totalfrais: number;
    totalreduction: number;
}