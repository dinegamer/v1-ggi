
import { StatistiqueParEtudiant } from "../donnees/statistiqueParEtudiant";

export interface Statistiqueparclasse {
    statistiqueParEtudiants: StatistiqueParEtudiant[];
    totalfrais: number;
    totalreduction: number;
    totaldue: number;
    montantpaie: number;
    resteapaie: number;
    pourcentage: number;
}
