import { Fraixscolaire } from "../model/fraixscolaire.model";
import { Paiement } from "../model/paiement.model";
import { Etudiant } from "../model/etudiant.model";

export class StatistiqueParEtudiant{ 
    etudiant!: Etudiant;  
    paiements: Paiement[] = [];
    frais!: number;
    reduction!: number;
    due!: number;
    paie!: number;
    reste!: number;
    pourcentage!: number;
}