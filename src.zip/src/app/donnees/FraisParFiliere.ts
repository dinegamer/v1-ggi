import { Filiere } from "../model/filiere.model";
import { Fraixscolaire } from "../model/fraixscolaire.model";

export interface FraisParFiliere{
    filiere: Filiere;
    fraixscolaires: Fraixscolaire[];
    montanttotal: number;
    reductiontotal: number;
}