import { Typeue } from "../model/Typeue.model";
import { NoteParMatiere } from "./NoteParMatiere";

export class ReleveParClasse{
    typeue!: Typeue;
    noteParMatieres!: NoteParMatiere[]
}