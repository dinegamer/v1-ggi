import { Matieresup } from "../model/matieresup.model";
import { NoteParClasse } from "./NoteParClasse";

export class NoteParMatiere{
    matieresup!: Matieresup;
    noteParClasses!: NoteParClasse[]
}