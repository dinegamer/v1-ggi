import { Cycle } from "../model/cycle.model";
import { NombreEtudiantParFiliere } from "./NombreEtudiantParFiliere";

export class NombreEtudiantParCycle{
    cycle!: Cycle;
    nombreEtudiantParFilieres!: NombreEtudiantParFiliere[];
    nombreEtudiant!: number;
}