import { Cycle } from "../model/cycle.model";
import { FraisParFiliere } from "./FraisParFiliere";

export interface FraisParCycle{
    cycle: Cycle;
    fraisParFilieres: FraisParFiliere[];
    montantotal: number;
    totalreduction: number;
}