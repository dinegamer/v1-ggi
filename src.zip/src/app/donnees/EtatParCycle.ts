import { Cycle } from "../model/cycle.model";

export class EtatParCycle{    
    cycle!: Cycle;
    nombreEtudiant!: number;
    chiffreAffaire!: number;
    reduction!: number;
    montantpaye!: number;
    reliquat!: number;
    reliquatpays!: number;
}