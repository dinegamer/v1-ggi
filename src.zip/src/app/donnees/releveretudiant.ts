import { Matieresup } from "../model/matieresup.model";

export interface Releveretudiant{
    matieresup: Matieresup;
    cc: string;
    ex: string;
    mg: string;
    credit: string;
    mention: string;
}