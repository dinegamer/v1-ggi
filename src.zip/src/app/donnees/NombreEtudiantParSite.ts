import { NombreEtudiantParCycle } from "./NombreEtudiantParCycle";
import { Site } from '../../../src/app/model/site.model';

export class NombreEtudiantParSite{
    site!: Site;
    nombreEtudiantParCycles!: NombreEtudiantParCycle[];
    nombreEtudiant!: number;
}