import { Typeue } from "../model/Typeue.model";
import { Releveretudiant } from "./releveretudiant";


export interface Notepartypeue {
    typeue: Typeue;
    releveretudiants: Releveretudiant[];
    mgtypeue: string;
    credittypeue: string;
    mentiontypeue: string;
    appreciationtypeue: string;
    nombreMatiere: number;    
}
