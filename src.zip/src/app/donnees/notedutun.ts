import { Etudiant } from '../model/etudiant.model';
import { Semestre } from '../model/semestre.model';


export interface Notedutun {
    etudiant: Etudiant;
    sun: Semestre;
    sdeux: Semestre;
    mgsun: string;
    mgsdeux: string;
    mannuel: string;
    mention: string;
    credit: string;
    appreciation: string;
}
