import { Filiere } from "../model/filiere.model";

export interface NombreEtudiantParFiliere{
    filiere: Filiere;
    nombreEtudiant: number;
}