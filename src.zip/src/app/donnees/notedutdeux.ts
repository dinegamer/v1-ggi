import { Etudiant } from "../model/etudiant.model";


export class Notedutdeux {
    etudiant!: Etudiant;    
    mgsun!: string;
    mgsdeux!: string;
    mannuel!: string;
    mdut!: string;
    mgenerale!: string;
    mention!: string;
    credit!: string;
    appreciation!: string;
}
