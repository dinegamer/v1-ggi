import { Etudiant } from "../model/etudiant.model";

export class NoteParClasse{
    etudiant!: Etudiant;
    cc!: number;
    ex!: number;
    mg!: number;
    credit!: number;
    validation!: string;
}