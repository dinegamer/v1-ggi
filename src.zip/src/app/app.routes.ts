import { Routes } from '@angular/router';
import { DefaultLayoutComponent } from './layout';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path: '',
    component: DefaultLayoutComponent,
    data: {
      title: 'Accueil'
    },
    children: [
      {
        path: 'dashboard',
        loadChildren: () => import('./views/dashboard/routes').then((m) => m.routes)
      },
      {
        path: 'etudiants',
        loadChildren: () => import('./views/etudiants/routes').then((m) => m.routes)
      },
      {
        path: 'notes',
        loadChildren: () => import('./views/notes/routes').then((m) => m.routes)
      },
      {
        path: 'pedagogie',
        loadChildren: () => import('./views/pedagogie/routes').then((m) => m.routes)
      },
      {
        path: 'comptabilite',
        loadChildren: () => import('./views/comptabilite/routes').then((m) => m.routes)
      },
      {
        path: 'base',
        loadChildren: () => import('./views/base/routes').then((m) => m.routes)
      },
      {
        path: 'paiements',
        loadChildren: () => import('./views/paiements/routes').then((m) => m.routes)
      },
      {
        path: 'configuration',
        loadChildren: () => import('./views/configuration/routes').then((m) => m.routes)
      },
      {
        path: 'frais',
        loadChildren: () => import('./views/frais/routes').then((m) => m.routes)
      },
      {
        path: 'administrateur',
        loadChildren: () => import('./views/administrateur/routes').then((m) => m.routes)
      },
      {
        path: 'parametre',
        loadChildren: () => import('./views/parametre/routes').then((m) => m.routes)
      }
    ]
  },
  {
    path: 'login',
    loadComponent: () => import('./views/pages/login/login.component').then(m => m.LoginComponent),
    data:{
      title: 'Connexion'
    }
  }
];
