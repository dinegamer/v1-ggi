import { INavData } from '@coreui/angular';

export interface INavDataExtended extends INavData {
  role?: string[]; // Ajoute la propriété "role"
}

export const navItems: INavDataExtended[] = [
  {
    name: 'Tableau de Bord',
    url: '/dashboard',
    iconComponent: { name: 'cil-speedometer' },
    badge: {
      color: 'info',
      text: 'Nouveau'
    },
    role: ['DGA','DG','DEV']
  },
  {    
    name:'Gestion des notes',
    url:'/notes',
    iconComponent: { name: 'cil-star' },
    role: ['DGA','DG','DE','AP','RS','DEV','RI','AA']
  },
  {    
    name:'Etudiants',
    url:'/etudiants', 
    iconComponent: { name: 'cil-puzzle' },
    role: ['DGA','DG','RS','AP','AA','DE','DEV','SG','RI']
  },
  {
    name: 'Comptes etudiants',
    url: '/etudiants/compte-etudiant',
    iconComponent: { name: 'cil-drop' },
    role: ['DGA','DG','DE','DEV','SG','RI','AA']
  },
  {
    name: 'Frais scolaire',
    url: '/frais',
    iconComponent: { name: 'cil-bell' },
    role: ['DGA','DG','AA','DE','DEV','SG','RI']
  },
  {
    name: 'Comptabilite',
    url: '/paiements',
    iconComponent: { name: 'cil-cursor' },
    role: ['DGA','DG','AA','DE','DEV','SG','RI']
  },
  {
    name: 'Gestions',
    title: true,
    role: ['DEV','DGA','RI']
  },
  {
    name: 'Configuration',
    url: '/configuration',
    iconComponent: { name: 'cil-notes' },
    role: ['DEV','DGA','RI'],
    children: [      
      {
        name: 'Annee',
        url: '/configuration/anneeuv',
        icon: 'nav-icon-bullet'
      },
      {
        name: 'Categorie',
        url: '/configuration/categorie',
        icon: 'nav-icon-bullet'
      },
      {
        name: 'Role',
        url: '/configuration/role',
        icon: 'nav-icon-bullet'
      },
      {
        name: 'Site',
        url: '/configuration/site',
        icon: 'nav-icon-bullet'
      },
      {
        name: 'Filiere',
        url: '/configuration/filiere',
        icon: 'nav-icon-bullet'
      },
      {
        name: 'Cycle',
        url: '/configuration/cycle',
        icon: 'nav-icon-bullet'
      },
      {
        name: 'Departement',
        url: '/configuration/departement',
        icon: 'nav-icon-bullet'
      },
      {
        name: 'Ecole',
        url: '/configuration/ecole',
        icon: 'nav-icon-bullet'
      }
    ]
  }, 
  {
    name: 'Administrateur',
    url: '/administrateur',
    iconComponent: { name: 'cil-calculator' },
    badge: {
      color: 'info',
      text: 'Nouveau'
    },
    role: ['DEV','DGA','RI']
  }
];
