export class Typeue{
    id!:string;
    code!:string;
    nom!:string;
}