export interface Departement{
    id:number;
    nom:string;
}