export interface Cycle{
    id:number;
    nom:string;
}