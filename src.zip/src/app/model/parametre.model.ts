import { Anneeuv } from "./anneeuv.model";

export class Parametre {
    id!: number;
    anneepardefaut!: Anneeuv
    c1!:number;
    c2!:number;
    c3!:number;
    c4!:number;
    c5!:number;
    c6!:number;
    c7!:number;
    pourcentage!:number;
}
