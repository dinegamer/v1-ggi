import { Anneeuv } from "./anneeuv.model";
import { Etudiant } from "./etudiant.model";
import { Filiere } from "./filiere.model";

export interface Paiement{
    id:number;
    montant:number;
    etudiant:Etudiant;
    datepaie:string;
    dateaction:string;
    enlettre:string;
    anneunv:Anneeuv;
    motif:string;
    filiere:Filiere;
    reliquat:string;
    anneeuvreliquat:Anneeuv;
}