import { EtatParCycle } from "../donnees/EtatParCycle";
import { Anneeuv } from "./anneeuv.model";
import { Site } from "./site.model";
import { Tableaudebord } from "./tableaudebord.model";

export class Tableaudeborddg {
    anneep!: Anneeuv;    
    tableaudebords: Tableaudebord[] = [];
    etatParCycles: EtatParCycle[] = [];  
    totalEtudiant!: number;  
    totalChiffre!: number;
    totalReduction!: number;
    totalPaie!: number;
    totalReliquat!: number;
    totalReliquatp!: number;
    etatParRapportAnP!: number;
    etatFraisParAnp!: number;
    tauxRecouvrement!: number;

}
