import { Categorie } from "./categorie.model";

export interface Ecole{
     idEcole:number;
     nomEcole:string;
     descriptionEcole:string;
     adresseEcole:string;
     categorie:Categorie;
}