import { Filiere } from "./filiere.model";

export interface Statistique{
    classe: Filiere;
    jour: string;
    soir: string;
    nombrejour: string;
    nombresoir: string;
    validejour: string[];
    validesoir: string[];
    enjabementjour: string[];
    enjabementsoir: string[];
    nonvalidejour: string[];
    nonvalidesoir: string[];
    pourcentagejour: string[];
    pourcentagesoir: string[];
}