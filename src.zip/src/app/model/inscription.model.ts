import { Anneeuv } from "./anneeuv.model";
import { Etudiant } from "./etudiant.model";
import { Filiere } from "./filiere.model";
import { Site } from "./site.model";

export interface Inscrire{
    id:number;
    rive:Site;
    cours:string;
    observation:string;
    filiere:Filiere;
    anneeuv:Anneeuv;
    etudiant:Etudiant;
    dateajout:string;
    heureajout:string;
}