import { Role } from "./role.model";
import { Site } from "./site.model";

export interface Administrateur{
    id:number;
    nom:string;
    prenom:string;
    adresse:string;
    telephone:string;
    email:string;
    lieun:string;
    datedn:string;
    photo:string;    
    username:string;
    password:string;
    site:Site;
    role:Role;
}