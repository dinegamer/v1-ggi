import { Anneeuv } from "./anneeuv.model";
import { Etudiant } from "./etudiant.model";
import { Filiere } from "./filiere.model";

export interface Fraixscolaire{
    id:number;
    montant:string;
    filiere:Filiere;
    etudiant:Etudiant;
    anneeuv:Anneeuv;
    reduction:string;
}