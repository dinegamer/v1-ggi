import { Filiere } from "./filiere.model";
import { Semestre } from "./semestre.model";
import { Ue } from "../model/Ue.model";

export class Matieresup{
    id!:string;
    code!:string;
    nom!:string;
    credit!:string;
    ue!:Ue;
    filiere!:Filiere;
    semestre!:Semestre;
}