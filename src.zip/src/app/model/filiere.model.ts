import { Cycle } from '../../app/model/cycle.model';
import { Departement } from '../../app/model/departement.model';
export interface Filiere{
    id?:number;
    nom:string;
    description:string;
    cycle:Cycle;
    departement:Departement;
}