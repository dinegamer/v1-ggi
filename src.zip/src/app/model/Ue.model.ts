import { Typeue } from "./Typeue.model";

export class Ue{
    id!:string;
    code!:string;
    nom!:string;
    typeue!:Typeue;
}