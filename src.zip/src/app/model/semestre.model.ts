export class Semestre{
    id!:string;
    libelle!:string;
}