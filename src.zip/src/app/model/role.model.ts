import { Categorie } from "./categorie.model";

export interface Role {
    id: number;
    nom: string;
    description: string;
    categorie: Categorie
  }
  