export interface Etudiant{
    id:number;
    photo:string;
    matricule:string;
    password:string;
    nom:string;
    prenom:string;
    telephone:string;
    genre: string;
    nationalite: string;
    adresse: string;
    email: string;
    naissance: string;
    teltuteur: string;
    label: string
    prenompere: string;
    prenommere: string;
    nommere: string;
    dateajout:string;
    heureajout:string;
}