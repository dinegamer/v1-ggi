
import { Site } from './site.model';
import { Cycle } from './cycle.model';
import { EtatParCycle } from '../donnees/EtatParCycle';
import { Anneeuv } from './anneeuv.model';

export interface Tableaudebord{
    site:Site;
    anneeuvp: Anneeuv;
    etatParCycles: EtatParCycle[];
    totalEtudiant: number;
    totalFrais: number;
    totalReduction: number;
    totalpaie: number;
    totalReliquat: number;
    totalReliquatPaie: number;
    etatParRapportAnP: number;
    etatFraisParAnp: number;
    tauxRecouvrement: number;
}