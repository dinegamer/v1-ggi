import { Etudiant } from '../model/etudiant.model';
import { Semestre } from '../model/semestre.model';
import { Matieresup } from '../model/matieresup.model';
import { Anneeuv } from '../model/anneeuv.model';
import { Filiere } from './filiere.model';

export interface NoteModel{
    id:string;
    noteclasse:string;
    noteexamen:string;
    datec:string;
    etudiant:Etudiant;
    semestre:Semestre;
    matieresup:Matieresup;
    anneeuv:Anneeuv;
    filiere:Filiere;
    utilisateur:string;
}