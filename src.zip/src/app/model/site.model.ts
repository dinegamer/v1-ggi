import { Ecole } from "./ecole.model";

export interface Site{
    id:number;
    nom:string;
    adresse:string;
    signature:string;
    titre:string;
    ecole: Ecole;
    responsable:string;
}