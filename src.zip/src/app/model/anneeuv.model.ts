export interface Anneeuv{
    id:number;
    nom:string;
    debutannee:string;
    finannee:string;
}