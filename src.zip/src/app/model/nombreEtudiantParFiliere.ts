import { Filiere } from './filiere.model';

export interface NombreEtudiantParFiliere{
    filiere: Filiere;
    nombreEtudiant: number;
}