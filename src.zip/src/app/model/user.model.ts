import { Administrateur } from "./administrateur.model";
import { Parametre } from "./parametre.model";
import { Site } from "./site.model";

export interface User{
    administrateur: Administrateur;
    site: Site;
    parametre: Parametre
}