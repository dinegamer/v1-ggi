import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { NgSelectModule } from '@ng-select/ng-select';
import { Parametre } from '../../model/parametre.model';
import { ParametreService } from '../../service/parametre.service';

@Component({
  selector: 'app-parametre',
  standalone: true,
  imports: [
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent, 
    ColComponent,
    RowComponent,
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    NgSelectModule 
  ],
  templateUrl: './parametre.component.html',
  styleUrl: './parametre.component.scss'
})
export class ParametreComponent implements OnInit{

  parametre!: Parametre ;
  isEdit: boolean = false;

  constructor(
    private parametreService: ParametreService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.isEdit = true;
      this.parametreService.getById(+id).subscribe((data) => (this.parametre = data));
    }
  }

  save() {
    if (this.isEdit) {
      this.parametreService.update(this.parametre.id!, this.parametre).subscribe(() => {
        this.router.navigate(['/']);
      });
    } else {
      this.parametreService.create(this.parametre).subscribe(() => {
        this.router.navigate(['/']);
      });
    }
  }

}
