import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    data: {
      title: 'Pedagogie'
    },
    children: [
      {
        path: '',
        redirectTo: 'pedagogie',
        pathMatch: 'full'
      },
      {
        path: 'pedagogie',
        loadComponent: () => import('./pedagogie.component').then(m => m.PedagogieComponent),
        data: {
          title: 'Pedagogie'
        }
      }
    ]
  }
];

