import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MdeuxComponent } from './mdeux.component';

describe('MdeuxComponent', () => {
  let component: MdeuxComponent;
  let fixture: ComponentFixture<MdeuxComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MdeuxComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(MdeuxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
