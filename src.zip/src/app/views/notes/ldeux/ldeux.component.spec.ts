import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LdeuxComponent } from './ldeux.component';

describe('LdeuxComponent', () => {
  let component: LdeuxComponent;
  let fixture: ComponentFixture<LdeuxComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LdeuxComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(LdeuxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
