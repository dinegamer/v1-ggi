import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReleveretudiantComponent } from './releveretudiant.component';

describe('ReleveretudiantComponent', () => {
  let component: ReleveretudiantComponent;
  let fixture: ComponentFixture<ReleveretudiantComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReleveretudiantComponent]
    })
      .compileComponents();

    fixture = TestBed.createComponent(ReleveretudiantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
