import { CommonModule } from "@angular/common"
import { Component, type OnInit } from "@angular/core"
import { FormControl, FormGroup, ReactiveFormsModule } from "@angular/forms"
import { RouterModule } from "@angular/router"
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from "@coreui/angular"
import { NgSelectModule } from "@ng-select/ng-select"
import { jsPDF } from "jspdf"

// Imports réguliers pour les services injectés
import { NoteService } from "../../../service/note.service"
import { AnneeuvService } from "../../../service/anneeuv.service"
import { FiliereService } from "../../../service/filiere.service"
import { SemestreService } from "../../../service/semestre.service"
import { InscriptionService } from "../../../service/inscription.service"
import { AuthService } from "../../../service/auth.service"

// Imports de type pour les modèles qui ne sont pas injectés
import type { Anneeuv } from "../../../model/anneeuv.model"
import type { Etudiant } from "../../../model/etudiant.model"
import type { Semestre } from "../../../model/semestre.model"
import type { Typeue } from "../../../model/Typeue.model"
import type { Noteparsemestre } from "../../../donnees/noteparsemestre"
import type { User } from "../../../model/user.model"

@Component({
  selector: "app-releveretudiant",
  standalone: true,
  imports: [
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent,
    ColComponent,
    RowComponent,
    RouterModule,
    ReactiveFormsModule,
    CommonModule,
    NgSelectModule,
  ],
  templateUrl: "./releveretudiant.component.html",
  styleUrl: "./releveretudiant.component.scss",
})
export class ReleveretudiantComponent implements OnInit {
  currentTime = ""
  // Timer pour mettre à jour l'heure chaque seconde
  private timer: any
  // Variable pour stocker la date
  currentDate = ""
  user!: User
  nomSignateur = "M. Moctar KOME"
  roleSignateur = "Directeur Général Adjoint"

  readonly myFormGroup = new FormGroup({
    annee: new FormControl(""),
    cours: new FormControl(""),
    filiere: new FormControl(""),
    semestre: new FormControl(""),
    etudiant: new FormControl(""),
    site: new FormControl(""),
  })

  noteparsemestre!: Noteparsemestre
  anneeuvs: Anneeuv[] = []
  filieres!: any
  semestres: Semestre[] = []
  etudiants!: Etudiant[]
  typeues: Typeue[] = []
  nomsemestre!: string
  cours = [
    { id: 1, nom: "JOUR" },
    { id: 2, nom: "SOIR" },
  ]
  espace = false

  constructor(
    private noteService: NoteService,
    private anneeuvService: AnneeuvService,
    private filiereService: FiliereService,
    private semestreService: SemestreService,
    private inscrireService: InscriptionService,
    private authService: AuthService,
  ) {}
  ngOnInit() {
    this.user = this.authService.getUserFromLocalStorage()
    this.getAllAnnee()
    this.getAllFiliere()
    this.getAllSemestre()
    // Met à jour l'heure au démarrage
    this.updateTime()
    // Actualise l'heure toutes les secondes
    this.timer = setInterval(() => this.updateTime(), 1000)
    // Met à jour la date au démarrage du composant
    this.updateDate()
    if (this.user && this.user.administrateur.site.id) {
      this.signateur()
    } else {
      alert("Utilisateur ou site manquant au chargement")
    }
  }
  // Fonction pour mettre à jour l'heure
  updateTime(): void {
    const now = new Date()
    this.currentTime = now.toLocaleTimeString() // Affiche l'heure sous forme locale
  }
  // Fonction pour mettre à jour la date
  updateDate(): void {
    const now = new Date()
    this.currentDate = now.toLocaleDateString() // Affiche la date sous forme locale
  }

  AfficherEtudiants() {
    const donnees = this.myFormGroup.value
    const donnee = [donnees.annee, donnees.cours, donnees.filiere, this.user.administrateur.site.id]
    //console.log("test test *- ***")
    this.inscrireService.getListeParClasse(donnee).subscribe((data: any) => {
      this.etudiants = data
    })
  }

  getAllAnnee() {
    this.anneeuvService.getAllAnnee().subscribe((data) => {
      this.anneeuvs = data
    })
  }
  getAllFiliere() {
    this.filiereService.getAllFilieres().subscribe((data) => {
      this.filieres = data
    })
  }
  getAllSemestre() {
    this.semestreService.getAllSemestre().subscribe((res: any) => {
      this.semestres = res
    })
  }
  //Recherche du signateur
  signateur() {
    if (!this.user || !this.user.administrateur.site.id) {
      console.warn("Utilisateur ou site non défini")
      return
    }

    // Toujours utiliser Moctar KOME comme signataire
    this.nomSignateur = "M. Moctar KOME"
    this.roleSignateur = "Directeur Général Adjoint"
  }
  rechercheNoteEtudiant() {
    //oredre des recherches an filiere etudiant cours
    const donnees = this.myFormGroup.value
    const search = [donnees.annee, donnees.filiere, donnees.etudiant, donnees.semestre]

    this.noteService.getControleParSemestre(search).subscribe({
      next: (res) => {
        this.espace = true
        this.noteparsemestre = res
      },
      error: (error) => {
        console.log("erreur !! " + error)
      },
    })
  }

  // Fonction utilitaire pour formater les nombres ou les chaînes
  formatNumber(value: any): string {
    if (typeof value === "number") {
      return value.toFixed(2)
    } else if (typeof value === "string") {
      // Essayer de convertir en nombre si c'est une chaîne
      const num = Number.parseFloat(value)
      if (!isNaN(num)) {
        return num.toFixed(2)
      }
    }
    // Si ce n'est ni un nombre ni une chaîne convertible en nombre, retourner tel quel
    return String(value)
  }

  // Fonction pour calculer la hauteur nécessaire pour un texte
  calculateTextHeight(text: string, width: number, fontSize: number, doc: jsPDF): number {
    doc.setFontSize(fontSize)
    const lines = doc.splitTextToSize(text, width - 4) // 4 = marge intérieure
    return Math.max(7, lines.length * 5) // Minimum 7 points, sinon 5 points par ligne
  }

  // Fonction pour déterminer la mention en fonction de la moyenne
  getMentionForAverage(moyenne: number | string): string {
    // Convertir en nombre si c'est une chaîne
    const moyenneNum = typeof moyenne === "string" ? Number.parseFloat(moyenne) : moyenne

    if (moyenneNum >= 16) return "Très Bien"
    if (moyenneNum >= 14) return "Bien"
    if (moyenneNum >= 12) return "Assez Bien"
    if (moyenneNum >= 10) return "Passable"
    if (moyenneNum >= 8) return "Faible"
    if (moyenneNum >= 6) return "Médiocre"
    return "Insuffisant"
  }

  printDiv(): void {
    // Créer un nouveau document PDF
    const doc = new jsPDF()

    // Définir les dimensions de la page
    const pageWidth = doc.internal.pageSize.getWidth()
    const pageHeight = doc.internal.pageSize.getHeight()
    const margin = 8

    // Ajouter l'heure en haut à gauche
    const now = new Date()
    const timeString =
      now.getHours().toString().padStart(2, "0") +
      ":" +
      now.getMinutes().toString().padStart(2, "0") +
      ":" +
      now.getSeconds().toString().padStart(2, "0")
    doc.setFontSize(9)
    doc.setTextColor(0, 0, 0)
    doc.text(timeString, margin, margin)

    // Définir les dimensions du tableau d'en-tête
    const headerTableWidth = pageWidth - 2 * margin
    const headerTableHeight = 50

    // Ajuster les proportions des colonnes selon l'exemple
    const leftColWidth = headerTableWidth * 0.38 // 38% pour la colonne de gauche (augmenté pour accommoder le texte)
    const centerColWidth = headerTableWidth * 0.15 // 15% pour la colonne du logo
    const rightColWidth = headerTableWidth * 0.47 // 47% pour la colonne de droite (ajusté en conséquence)

    // Dessiner le tableau d'en-tête avec des bordures très fines
    doc.setLineWidth(0.1) // Bordure fine mais visible
    doc.setDrawColor(180, 180, 180) // Bordures grises adoucies

    // Rectangle principal
    doc.rect(margin, margin + 5, headerTableWidth, headerTableHeight)

    // Lignes verticales
    doc.line(margin + leftColWidth, margin + 5, margin + leftColWidth, margin + 5 + headerTableHeight)
    doc.line(
      margin + leftColWidth + centerColWidth,
      margin + 5,
      margin + leftColWidth + centerColWidth,
      margin + 5 + headerTableHeight,
    )

    // Colonne 1 - Informations institutionnelles
    let currentY = margin + 10
    doc.setFont("times", "bold")
    doc.setFontSize(11)
    doc.text("République du Mali", margin + leftColWidth / 2, currentY, { align: "center" })
    currentY += 5

    doc.setFontSize(10)
    doc.text("Un Peuple - Un But - Une Foi", margin + leftColWidth / 2, currentY, { align: "center" })
    currentY += 5

    doc.setFont("times", "normal")
    doc.setFontSize(9)
    doc.text("*****************************", margin + leftColWidth / 2, currentY, { align: "center" })
    currentY += 5

    doc.setFont("times", "bold")
    doc.setFontSize(10)
    doc.text("Ministère de l'Enseignement Supérieur", margin + leftColWidth / 2, currentY, { align: "center" })
    currentY += 5
    doc.text("et de la Recherche Scientifique - MESRS", margin + leftColWidth / 2, currentY, { align: "center" })
    currentY += 5

    doc.setFont("times", "normal")
    doc.setFontSize(9)
    doc.text("*****************************", margin + leftColWidth / 2, currentY, { align: "center" })
    currentY += 5

    doc.setFont("times", "bold")
    doc.setFontSize(10)
    // Modification: "Institut Supérieur des Techniques Economiques" sur une seule ligne
    doc.text("Institut Supérieur des Techniques Economiques", margin + leftColWidth / 2, currentY, { align: "center" })
    currentY += 5
    // "Comptables et Commerciales - INTEC SUP" sur la ligne suivante
    doc.text("Comptables et Commerciales - INTEC SUP", margin + leftColWidth / 2, currentY, { align: "center" })

    // Colonne 2 - Logo (plus petite)
    doc.addImage(
      "assets/images/logo.png",
      "PNG",
      margin + leftColWidth + centerColWidth / 2 - 10, // Centrer le logo dans une zone plus petite
      margin + 15,
      20, // Réduire la taille du logo
      20,
    )

    // Colonne 3 - Informations du bulletin et de l'étudiant (plus grande)
    currentY = margin + 10
    doc.setFont("times", "bold")
    doc.setFontSize(14) // Police plus grande pour le titre
    doc.text("BULLETIN DE NOTES", margin + leftColWidth + centerColWidth + rightColWidth / 2, currentY, {
      align: "center",
    })
    currentY += 7

    // Récupérer les informations du semestre et de l'année
    const semestre = this.noteparsemestre.semestre?.libelle || "Semestre 1"
    const annee = this.noteparsemestre.anneeuv?.nom || "2023 - 2024"

    doc.setFontSize(12)
    doc.text(`${semestre} : ${annee}`, margin + leftColWidth + centerColWidth + rightColWidth / 2, currentY, {
      align: "center",
    })
    currentY += 7

    // Récupérer les informations de l'étudiant
    const filiere = this.noteparsemestre.filiere?.nom || "1ière Année Gestion d'Entreprise et d'Administration"
    const nom = this.noteparsemestre.etudiant?.nom || "KOUYATE"
    const prenom = this.noteparsemestre.etudiant?.prenom || "Boubacar"
    const naissance = this.noteparsemestre.etudiant?.naissance || "04/11/2005"
    const matricule = this.noteparsemestre.etudiant?.matricule || "23A0026"

    // Ajuster la marge pour aligner à gauche dans la colonne de droite
    const rightColMargin = margin + leftColWidth + centerColWidth + 5

    // Diviser le texte de la filière si nécessaire
    const maxFiliereWidth = rightColWidth - 10
    const filiereLines = doc.splitTextToSize(`Filière : ${filiere}`, maxFiliereWidth)

    doc.text(`Filière : ${filiere}`, rightColMargin, currentY)
    currentY += 5

    doc.text(`Nom : ${nom}`, rightColMargin, currentY)
    currentY += 5

    doc.text(`Prénom : ${prenom}`, rightColMargin, currentY)
    currentY += 5

    doc.text(`Date et lieu de naissance : ${naissance}`, rightColMargin, currentY)
    currentY += 5

    doc.text(`N° Matricule : ${matricule}`, rightColMargin, currentY)

    // Positionner pour le tableau des notes
    currentY = margin + 5 + headerTableHeight + 10

    // Définir les en-têtes du tableau
    const headers = [
      "UNITES\nD'ENSEIGNEMENTS",
      "ELEMENTS\nCONSTITUTIFS",
      "CC",
      "EX",
      "MG",
      "CREDITS",
      "MENTION",
      "APPRECIATION",
    ]

    // Définir les largeurs des colonnes - ajuster pour éviter les débordements
    const columnWidths = [
      pageWidth * 0.21, // UNITES D'ENSEIGNEMENTS
      pageWidth * 0.21, // ELEMENTS CONSTITUTIFS
      pageWidth * 0.07, // CC
      pageWidth * 0.07, // EX
      pageWidth * 0.07, // MG
      pageWidth * 0.07, // CREDITS
      pageWidth * 0.11, // MENTION
      pageWidth * 0.11, // APPRECIATION - augmentée
    ]

    // Dessiner l'en-tête du tableau avec des bordures grises et fond blanc
    let xPos = margin
    doc.setFillColor(255, 255, 255) // Fond blanc pour l'en-tête (comme dans la deuxième image)
    doc.setDrawColor(180, 180, 180) // Bordures grises adoucies
    doc.setTextColor(0, 0, 0) // Texte noir
    doc.setFont("times", "bold")
    doc.setFontSize(9) // Police plus petite

    // Hauteur augmentée pour les en-têtes sur deux lignes
    const headerHeight = 14

    // Dessiner le fond blanc pour tout l'en-tête
    doc.rect(margin, currentY, pageWidth - 2 * margin, headerHeight, "F")

    // Dessiner chaque cellule d'en-tête
    headers.forEach((header, i) => {
      // Dessiner le contour de la cellule
      doc.rect(xPos, currentY, columnWidths[i], headerHeight)

      // Pour les en-têtes sur deux lignes, centrer verticalement
      if (header.includes("\n")) {
        const lines = header.split("\n")
        doc.text(lines[0], xPos + columnWidths[i] / 2, currentY + 5, { align: "center" })
        doc.text(lines[1], xPos + columnWidths[i] / 2, currentY + 10, { align: "center" })
      } else {
        // Pour les en-têtes sur une seule ligne, centrer verticalement
        doc.text(header, xPos + columnWidths[i] / 2, currentY + headerHeight / 2, {
          align: "center",
          baseline: "middle",
        })
      }
      xPos += columnWidths[i]
    })

    currentY += headerHeight // Hauteur augmentée pour les en-têtes sur deux lignes

    // Dessiner les lignes du tableau pour chaque type d'UE
    doc.setFontSize(8) // Police encore plus petite pour le contenu

    // Parcourir les types d'UE
    this.noteparsemestre.noteParTypeUe?.forEach((typeUe: any, typeIndex: number) => {
      // Stocker la position Y de début pour ce type d'UE (pour la fusion de la colonne APPRECIATION)
      const typeStartY = currentY
      let typeRowCount = 0 // Compter le nombre de lignes pour ce type d'UE

      // Ajouter les matières de ce type d'UE
      typeUe.releveretudiants.forEach((matiere: any, index: number) => {
        typeRowCount++

        // Récupérer les informations des unités d'enseignement et éléments constitutifs
        const ueCode = matiere.matieresup.ue.code || ""
        const ueName = matiere.matieresup.ue.nom || ""
        const ecCode = matiere.matieresup.code || ""
        const ecName = matiere.matieresup.nom || ""

        // Préparer les textes complets
        const ueText = `${ueCode} : ${ueName}`
        const ecText = `${ecCode} : ${ecName}`

        // Calculer la hauteur nécessaire pour chaque cellule
        const ueHeight = this.calculateTextHeight(ueText, columnWidths[0], 8, doc)
        const ecHeight = this.calculateTextHeight(ecText, columnWidths[1], 8, doc)
        const rowHeight = Math.max(ueHeight, ecHeight, 7) // Minimum 7 points de hauteur

        // Alternance de couleurs pour les lignes (style Bootstrap)
        if (index % 2 === 1) {
          doc.setFillColor(248, 249, 250) // Couleur gris très clair pour les lignes impaires (comme Bootstrap)
          doc.rect(margin, currentY, pageWidth - 2 * margin, rowHeight, "F")
        } else {
          doc.setFillColor(255, 255, 255) // Blanc pour les lignes paires
        }

        xPos = margin

        // Colonne 1: UNITES D'ENSEIGNEMENTS
        doc.rect(xPos, currentY, columnWidths[0], rowHeight)
        const ueLines = doc.splitTextToSize(ueText, columnWidths[0] - 1)
        for (let i = 0; i < ueLines.length; i++) {
          if (i === 0) {
            // Pour la première ligne, mettre en gras le code
            const parts = ueLines[i].split(" : ")
            if (parts.length > 1) {
              doc.setFont("times", "bold")
              doc.text(parts[0], xPos + 2, currentY + 4)
              const codeWidth = doc.getTextWidth(parts[0])
              doc.setFont("times", "normal")
              doc.text(` : ${parts[1]}`, xPos + 2 + codeWidth, currentY + 4)
            } else {
              doc.text(ueLines[i], xPos + 2, currentY + 4)
            }
          } else {
            doc.setFont("times", "normal")
            doc.text(ueLines[i], xPos + 2, currentY + 4 + i * 4)
          }
        }
        xPos += columnWidths[0]

        // Colonne 2: ELEMENTS CONSTITUTIFS
        doc.rect(xPos, currentY, columnWidths[1], rowHeight)
        const ecLines = doc.splitTextToSize(ecText, columnWidths[1] - 4)
        for (let i = 0; i < ecLines.length; i++) {
          if (i === 0) {
            // Pour la première ligne, mettre en gras le code
            const parts = ecLines[i].split(" : ")
            if (parts.length > 1) {
              doc.setFont("times", "bold")
              doc.text(parts[0], xPos + 2, currentY + 4)
              const codeWidth = doc.getTextWidth(parts[0])
              doc.setFont("times", "normal")
              doc.text(` : ${parts[1]}`, xPos + 2 + codeWidth, currentY + 4)
            } else {
              doc.text(ecLines[i], xPos + 2, currentY + 4)
            }
          } else {
            doc.setFont("times", "normal")
            doc.text(ecLines[i], xPos + 2, currentY + 4 + i * 4)
          }
        }
        xPos += columnWidths[1]

        // Colonne 3: CC
        doc.rect(xPos, currentY, columnWidths[2], rowHeight)
        doc.setFont("times", "normal")
        doc.text(this.formatNumber(matiere.cc), xPos + columnWidths[2] / 2, currentY + rowHeight / 2, {
          align: "center",
          baseline: "middle",
        })
        xPos += columnWidths[2]

        // Colonne 4: EX
        doc.rect(xPos, currentY, columnWidths[3], rowHeight)
        doc.text(this.formatNumber(matiere.ex), xPos + columnWidths[3] / 2, currentY + rowHeight / 2, {
          align: "center",
          baseline: "middle",
        })
        xPos += columnWidths[3]

        // Colonne 5: MG
        doc.rect(xPos, currentY, columnWidths[4], rowHeight)
        doc.text(this.formatNumber(matiere.mg), xPos + columnWidths[4] / 2, currentY + rowHeight / 2, {
          align: "center",
          baseline: "middle",
        })
        xPos += columnWidths[4]

        // Colonne 6: CREDITS
        doc.rect(xPos, currentY, columnWidths[5], rowHeight)
        doc.text(matiere.credit.toString(), xPos + columnWidths[5] / 2, currentY + rowHeight / 2, {
          align: "center",
          baseline: "middle",
        })
        xPos += columnWidths[5]

        // Colonne 7: MENTION
        doc.rect(xPos, currentY, columnWidths[6], rowHeight)
        doc.text(matiere.mention, xPos + columnWidths[6] / 2, currentY + rowHeight / 2, {
          align: "center",
          baseline: "middle",
        })
        xPos += columnWidths[6]

        // Colonne 8: APPRECIATION - laissée vide car elle sera fusionnée
        doc.rect(xPos, currentY, columnWidths[7], rowHeight)

        currentY += rowHeight
      })

      // Ajouter la ligne de résumé pour ce type d'UE
      const summaryHeight = 7
      doc.setFillColor(240, 240, 240) // Gris clair pour les lignes de résumé
      doc.rect(margin, currentY, pageWidth - 2 * margin, summaryHeight, "F")
      xPos = margin

      // Colonnes 1-2: RESULTATS UE XXX (fusion des colonnes UNITES D'ENSEIGNEMENTS et ELEMENTS CONSTITUTIFS)
      const ueEcWidth = columnWidths[0] + columnWidths[1]
      doc.rect(xPos, currentY, ueEcWidth, summaryHeight)
      doc.setFont("times", "bold")
      doc.text(`RESULTATS ${typeUe.typeue.nom}`, xPos + ueEcWidth / 2, currentY + 4, {
        align: "center",
      })
      xPos += ueEcWidth

      // Colonnes 3-5: CC, EX, MG fusionnées
      const ccExMgWidth = columnWidths[2] + columnWidths[3] + columnWidths[4]
      doc.rect(xPos, currentY, ccExMgWidth, summaryHeight)
      doc.text(this.formatNumber(typeUe.mgtypeue), xPos + ccExMgWidth / 2, currentY + 4, {
        align: "center",
      })
      xPos += ccExMgWidth

      // Colonne 6: CREDITS
      doc.rect(xPos, currentY, columnWidths[5], summaryHeight)
      doc.text(typeUe.credittypeue.toString(), xPos + columnWidths[5] / 2, currentY + 4, {
        align: "center",
      })
      xPos += columnWidths[5]

      // Colonne 7: MENTION
      doc.rect(xPos, currentY, columnWidths[6], summaryHeight)
      // Déterminer la mention en fonction de la moyenne
      const mention = this.getMentionForAverage(typeUe.mgtypeue)
      doc.text(mention, xPos + columnWidths[6] / 2, currentY + 4, {
        align: "center",
      })
      xPos += columnWidths[6]

      // Colonne 8: APPRECIATION - Nous ne dessinons pas de texte ici car nous allons fusionner cette cellule

      // Fusionner la colonne APPRECIATION pour toutes les lignes de ce type d'UE, y compris la ligne de résultat
      const totalTypeHeight = currentY - typeStartY + summaryHeight // Inclure la hauteur de la ligne de résultat

      // Dessiner un rectangle blanc pour effacer les lignes précédentes
      doc.setFillColor(255, 255, 255)
      doc.rect(
        margin +
        columnWidths[0] +
        columnWidths[1] +
        columnWidths[2] +
        columnWidths[3] +
        columnWidths[4] +
        columnWidths[5] +
        columnWidths[6],
        typeStartY,
        columnWidths[7],
        totalTypeHeight,
        "F",
      )

      // Redessiner le contour
      doc.setDrawColor(180, 180, 180)
      doc.rect(
        margin +
        columnWidths[0] +
        columnWidths[1] +
        columnWidths[2] +
        columnWidths[3] +
        columnWidths[4] +
        columnWidths[5] +
        columnWidths[6],
        typeStartY,
        columnWidths[7],
        totalTypeHeight,
      )

      // Écrire "Validé" ou "Non Validé" au milieu de la cellule fusionnée
      const appreciation = typeUe.appreciationtypeue === "Validé" ? "Validé" : "Non Validé"
      doc.setFont("times", "bold")
      doc.text(
        appreciation,
        margin +
        columnWidths[0] +
        columnWidths[1] +
        columnWidths[2] +
        columnWidths[3] +
        columnWidths[4] +
        columnWidths[5] +
        columnWidths[6] +
        columnWidths[7] / 2,
        typeStartY + totalTypeHeight / 2,
        {
          align: "center",
          baseline: "middle",
        },
      )

      currentY += summaryHeight
    })

    // Ajouter la ligne de total du semestre
    const totalHeight = 7
    doc.setFillColor(230, 230, 230) // Gris un peu plus foncé pour la ligne de total
    doc.rect(margin, currentY, pageWidth - 2 * margin, totalHeight, "F")
    xPos = margin

    // Colonnes 1-2: TOTAL SEMESTRE X (fusion des colonnes UNITES D'ENSEIGNEMENTS et ELEMENTS CONSTITUTIFS)
    const ueEcWidth = columnWidths[0] + columnWidths[1]
    doc.rect(xPos, currentY, ueEcWidth, totalHeight)
    doc.setFont("times", "bold")
    doc.text(`TOTAL ${this.noteparsemestre.semestre?.libelle}`, xPos + ueEcWidth / 2, currentY + 4, {
      align: "center",
    })
    xPos += ueEcWidth

    // Colonnes 3-5: CC, EX, MG fusionnées
    const ccExMgWidth = columnWidths[2] + columnWidths[3] + columnWidths[4]
    doc.rect(xPos, currentY, ccExMgWidth, totalHeight)
    doc.text(this.formatNumber(this.noteparsemestre.mgsemestre), xPos + ccExMgWidth / 2, currentY + 4, {
      align: "center",
    })
    xPos += ccExMgWidth

    // Colonne 6: CREDITS
    doc.rect(xPos, currentY, columnWidths[5], totalHeight)
    doc.text(this.noteparsemestre.creditsemestre.toString(), xPos + columnWidths[5] / 2, currentY + 4, {
      align: "center",
    })
    xPos += columnWidths[5]

    // Colonne 7: MENTION
    doc.rect(xPos, currentY, columnWidths[6], totalHeight)
    // Déterminer la mention en fonction de la moyenne
    const totalMention = this.getMentionForAverage(Number.parseFloat(this.noteparsemestre.mgsemestre.toString()))
    doc.text(totalMention, xPos + columnWidths[6] / 2, currentY + 4, {
      align: "center",
    })
    xPos += columnWidths[6]

    // Colonne 8: APPRECIATION
    doc.rect(xPos, currentY, columnWidths[7], totalHeight)
    // Déterminer si le semestre est validé ou non
    const semesterAppreciation = this.noteparsemestre.appreciationsemestre === "Validé" ? "Validé" : "Non Validé"
    doc.text(semesterAppreciation, xPos + columnWidths[7] / 2, currentY + 4, {
      align: "center",
    })

    // Ajouter la date et la signature avec l'espacement ajusté
    const dateY = currentY + 30
    const formattedDate = new Date().toLocaleDateString("fr-FR", { day: "2-digit", month: "2-digit", year: "numeric" })

    doc.setFontSize(10)
    doc.text(`Bamako le ${formattedDate}`, pageWidth - margin, dateY, { align: "right" })
    // Réduire l'espacement entre la date et le titre
    const rolesignatureOffset = -4 // Décalage de -4 points vers la droite
    doc.text(this.roleSignateur, pageWidth - margin - rolesignatureOffset, dateY + 5, { align: "right" })

    // Décaler légèrement le nom vers la gauche
    const signatureOffset = 1 // Décalage de 1 point vers la gauche
    doc.text(this.nomSignateur, pageWidth - margin - signatureOffset, dateY + 25, { align: "right" })

    // Pas de pied de page

    // Ouvrir le PDF dans un nouvel onglet de manière plus fiable
    const blob = doc.output("blob")
    const blobUrl = URL.createObjectURL(blob)

    // Ouvrir dans un nouvel onglet
    const newWindow = window.open(blobUrl, "_blank")

    // Si le navigateur bloque l'ouverture d'une nouvelle fenêtre
    if (!newWindow || newWindow.closed || typeof newWindow.closed === "undefined") {
      // Fallback: proposer le téléchargement direct
      const link = document.createElement("a")
      link.href = blobUrl
      link.download = `Bulletin_${nom}_${prenom}_${semestre.replace(/\s+/g, "_")}.pdf`
      link.click()

      // Nettoyer l'URL
      setTimeout(() => {
        URL.revokeObjectURL(blobUrl)
      }, 100)
    } else {
      // Nettoyer l'URL quand la fenêtre est fermée
      newWindow.addEventListener("beforeunload", () => {
        URL.revokeObjectURL(blobUrl)
      })
    }
  }
}
