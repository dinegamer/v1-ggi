import { Component, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { NgSelectModule } from '@ng-select/ng-select';
import { Semestre } from '../../../model/semestre.model';
import { SemestreService } from '../../../service/semestre.service';
import { Filiere } from '../../../model/filiere.model';
import { FiliereService } from '../../../service/filiere.service';
import { Matieresup } from '../../../model/matieresup.model';
import { Etudiant } from '../../../model/etudiant.model';
import { EtudiantService } from '../../../service/etudiant.service';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { InscriptionService } from '../../../service/inscription.service';
import { CommonModule } from '@angular/common';
import { NoteService } from '../../../service/note.service';
import { MatieresupService } from '../../../service/matieresup.service';
import { User } from '../../../model/user.model';
import { AuthService } from '../../../service/auth.service';
import { NoteModel } from '../../../model/note.model';
import { AnneeuvService } from '../../../service/anneeuv.service';
import { Anneeuv } from '../../../model/anneeuv.model';

@Component({
  selector: 'app-modifierparetudiant',
  standalone: true,
  imports: [
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent, 
    ColComponent,
    RowComponent,
    RouterModule,
    NgSelectModule,
    ReactiveFormsModule,
    CommonModule
  ],
  templateUrl: './modifierparetudiant.component.html',
  styleUrl: './modifierparetudiant.component.scss'
})
export class ModifierparetudiantComponent implements OnInit {
  user!: User
  cours = [
    {id:1, nom:'JOUR'},
    {id:2, nom:'SOIR'}
  ]
  semestres: Semestre[] = []
  filieres: Filiere[] = []
  matieres: Matieresup[] = []
  etudiants: Etudiant[] = []
  ajoutnote: boolean = false
  confirme: boolean = false
  confirmemsg: string = ""
  donnee: string[] = []
  control!: NoteModel
  annees: Anneeuv[] = []
  //form
   readonly myFormGroup = new FormGroup({
      annee: new FormControl(""),
      cours: new FormControl(""),
      filiere: new FormControl(""),
      semestre: new FormControl(""),
      etudiant: new FormControl(""),
      matiere: new FormControl(""),
      site: new FormControl(""),
      annees: new FormControl("")
    });
  readonly FormulaireDAjout = new FormGroup({
    controlId: new FormControl(""),
    noteclasse: new FormControl(""),
    noteexamen: new FormControl("")
  });
  //constructeur
  constructor(
    private semestreService: SemestreService,
    private filiereService: FiliereService,
    private matieresupService: MatieresupService,
    private etudiantService: EtudiantService,
    private inscrireService: InscriptionService,
    private noteService: NoteService,
    private authService: AuthService,
    private anneeService: AnneeuvService
  ){}
  //initialement
  ngOnInit(): void {
    //this.getAllSite()
    this.getAllSemestre()
    this.getAllAnnee()
    this.getAllFiliere()
    this.user = this.authService.getUserFromLocalStorage()
    console.log(this.user+" mdt 123")
  }
  Modifier(){
    const informations = this.myFormGroup.value 
    const donnees = this.FormulaireDAjout.value 
    //construction des données
    const infos = [
      donnees.controlId,
      informations.annee,
      informations.etudiant,
      informations.filiere,
      informations.matiere,
      informations.semestre,
      donnees.noteclasse,
      donnees.noteexamen]
    //console.log(" mdt "+infos+" mdt ")
    this.noteService.updateNoteEtudiant(infos).subscribe({
      next: (response) =>{
        this.confirme = true
        this.confirmemsg = response.message
        this.ajoutnote = false
        }, 
      error:  (error) =>{
          this.confirme = true
          this.confirmemsg = "Erreur lors du traitement !."+error
          this.ajoutnote = false
        },
      complete: () => {console.log('complete !!')}
      })
  }
  AjoutNote(){
    const donnees = this.myFormGroup.value 
    this.donnee[0] = donnees.filiere || ''
    this.donnee[1] = donnees.annee || ''
    this.donnee[2] = donnees.etudiant || ''
    this.donnee[3] = donnees.matiere || ''
    this.donnee[4] = donnees.semestre || ''
    
    this.FormulaireDAjout.reset({
      controlId: '',
      noteclasse: '',
      noteexamen: ''
    });
     

    this.noteService.getverifiernotedunetudiant(this.donnee).subscribe({      
      next: (response) => {
        if(response.message == "false"){
          this.ajoutnote = false
          this.confirme = true
          this.confirmemsg = "Cette parti est reserver pour la mise à jour, Merci"
          //console.log(response.control+" mdt test 1")
        }else{                  
          //console.log(response.control.etudiant.id+" tes test mdt !")
          this.confirme = false
          this.ajoutnote = true
          // Mise à jour réactive du formulaire
          this.FormulaireDAjout.patchValue({
            controlId: response.control.id || '',
            noteclasse: response.control.noteclasse || '',
            noteexamen: response.control.noteexamen || ''
          });
          //this.confirmemsg = "Une note existe deja pour l'etudiant pour les meme informations, Merci"
        }
        console.log(response.message)
      },
      error: (error) => {console.log("Erreur !!!"+error) },
      complete: () => {console.log("complete !!!")}
    })
    
  }
  getAllAnnee(){
    this.anneeService.getAllAnnee().subscribe({
      next: (data) =>{ this.annees = data }
    })
  }
  RechercheEtudiant(){
    const donnees = this.myFormGroup.value    
    let donnee = [
      donnees.annee,
      donnees.cours,
      donnees.filiere,
      this.user.administrateur.site.id
    ]
    if(donnees.cours == ""){
      alert("Choisir un cours ?")
      return
    }
    
    this.etudiants = []
    this.inscrireService.getListeParClasse(donnee).subscribe(data =>{
      this.etudiants = data
    })
    this.RechercheMatiere()
  }
  RechercheMatiere(){
    const donnees = this.myFormGroup.value    
    let donnee = [donnees.semestre,donnees.filiere]
    if(donnees.semestre == ""){
      alert("Choisir le semestre ?")
      return
    }    

    this.matieres = [];
    this.matieresupService.ListeMFS(donnee).subscribe((data: any) =>{
      this.matieres = data
    })
  }
  
  getAllSemestre(){
    this.semestreService.getAllSemestre().subscribe((res: any) =>{
      this.semestres = res
      //console.log(res+" mdt test !")
    })
  }
  
  getAllFiliere(){
    this.filiereService.getAllFilieres().subscribe(data => {
       this.filieres = data
    });
  }
  getAllMatiere(){
   this.matieresupService.getAllMatieresup().subscribe(data =>{
    this.matieres = data
   })
  }
  getAllEtudiant(){
    this.etudiantService.getEtudiants().subscribe(data =>{
          this.etudiants = data
    })
  }
}
