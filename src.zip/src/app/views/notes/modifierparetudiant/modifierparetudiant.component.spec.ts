import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ModifierparetudiantComponent } from './modifierparetudiant.component';

describe('ModifierparetudiantComponent', () => {
  let component: ModifierparetudiantComponent;
  let fixture: ComponentFixture<ModifierparetudiantComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ModifierparetudiantComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ModifierparetudiantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
