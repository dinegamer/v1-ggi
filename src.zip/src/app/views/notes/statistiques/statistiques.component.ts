import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { Anneeuv } from '../../../model/anneeuv.model'; 
import { Statistique } from '../../../model/statistique.model';
import { Cycle } from '../../../model/cycle.model';
import { Site } from '../../../model/site.model';
import { AnneeuvService } from '../../../service/anneeuv.service';
import { NoteService } from '../../../service/note.service';
import { CycleService } from '../../../service/cycle.service';
import { SiteService } from '../../../service/site.service';
import { NgSelectModule } from '@ng-select/ng-select';

@Component({
  selector: 'app-statistiques',
  standalone: true,
  imports: [
    CommonModule,
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent, 
    ColComponent,
    RowComponent,
    ReactiveFormsModule,
    NgSelectModule
  ],
  templateUrl: './statistiques.component.html',
  styleUrl: './statistiques.component.scss'
})
export class StatistiquesComponent {
  cycle: string = "4";
  donnee: any[] = [];
  cycles: Cycle[] = [];
  annees: Anneeuv[] = [];
  statistiques: Statistique[] = [];
  statisquesdut: Statistique[] = [];
  totalstatisques: Statistique[] = [];
  sites: Site[] = []
  istatistique: boolean = false
  istatistiquedut: boolean = false
  istatistiquetotal: boolean = false

  readonly myFormGroup = new FormGroup({
    annee: new FormControl(""),
    site: new FormControl(""),
    cyclec: new FormControl("")
  });

  constructor(
    private anneeuvService: AnneeuvService, 
    private noteService: NoteService,
    private siteService: SiteService,
    private cycleService: CycleService
  ){}

  ngOnInit(): void {
    this.getAnneeuv()
    this.getAllSite()
    this.getAllCycle()
  }
  getAllSite(){
    this.siteService.getAllSite().subscribe(data =>{
      this.sites = data
    })
  }
  getAllCycle(){
    this.cycleService.getAllCycle().subscribe(data =>{
      this.cycles = data
    })
  }

  getAnneeuv(){
    this.anneeuvService.getAllAnnee().subscribe(data =>{
      this.annees = data
    })
  }
  Statistiques(){
    const donnees = this.myFormGroup.value
    this.donnee[0] = donnees.annee
    this.donnee[1] = donnees.site
    this.donnee[2] = donnees.cyclec
    this.noteService.getStatistique(this.donnee).subscribe((data:any) =>{
      this.statistiques = data
    });
    this.istatistique = true
    this.istatistiquedut = false
    this.istatistiquetotal = false
  }
  StatistiquesDut(){
    this.istatistiquedut = true
    this.istatistiquetotal = false
    this.istatistique = false
  }
  StatistiquesTotal(){
    this.istatistiquetotal = true
    this.istatistique = false
    this.istatistiquedut = false

  }
}
