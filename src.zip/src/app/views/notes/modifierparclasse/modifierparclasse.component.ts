import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { NgSelectModule } from '@ng-select/ng-select';
import { Anneeuv } from '../../../model/anneeuv.model';
import { Site } from '../../../model/site.model';
import { Filiere } from '../../../model/filiere.model';
import { Matieresup } from '../../../model/matieresup.model';
import { Semestre } from '../../../model/semestre.model';
import { FiliereService } from '../../../service/filiere.service';
import { MatieresupService } from '../../../service/matieresup.service';
import { SemestreService } from '../../../service/semestre.service';
import { NoteService } from '../../../service/note.service';
import { ChangeDetectorRef } from '@angular/core';
import { User } from '../../../model/user.model';
import { AuthService } from '../../../service/auth.service';
import { AnneeuvService } from '../../../service/anneeuv.service';
import $ from 'jquery';
import 'datatables.net';

@Component({
  selector: 'app-modifierparclasse',
  standalone: true,
  imports: [   
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent, 
    ColComponent,
    RowComponent,
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    NgSelectModule
  ],
  templateUrl: './modifierparclasse.component.html',
  styleUrl: './modifierparclasse.component.scss'
})
export class ModifierparclasseComponent implements OnInit{
  myFormGroup!: FormGroup;
  myFormNote!: FormGroup;
  user!: User
  filieres: Filiere[] = [];
  annees: Anneeuv[] = [];
  semestres: Semestre[] = [];
  matieres: Matieresup[] = [];
  donnee: any[] = [];
  sites: Site[] = [];
  donnees: any[] = [];
  controles: any[] = [];
  resultat: boolean = false
  cours = [
    {id:1, nom:'JOUR'},
    {id:2, nom:'SOIR'}
  ]
  succes: boolean = false
  msgsucces!: string

  ngOnInit(): void {
    this.getFilieres()
    this.getSemestres()
    this.getAllAnnee()
    this.user = this.authService.getUserFromLocalStorage()
    // Initialisation du formulaire principal
    this.myFormGroup = this.fb.group({
      annee: [null],
      filiere: [null],
      cours: [null],
      semestre: [null],
      matiere: [null]
    });

    // Initialisation du formulaire pour les notes des étudiants
    this.myFormNote = this.fb.group({});
  }
  constructor(
    private fb: FormBuilder,
    private noteService: NoteService, 
    private filiereService: FiliereService,
    private semestreService: SemestreService,
    private matieresupService: MatieresupService, 
    private authService: AuthService,
    private anneeService: AnneeuvService, 
    private cdRef: ChangeDetectorRef
  ){  this.myFormNote = new FormGroup({});   }

  trackById(index: number, item: any): number {
    return item.etudiant.id;
  }
  
  getAllAnnee(){
    this.anneeService.getAllAnnee().subscribe({
      next: (data) => {this.annees = data}
    })
  }
  getFilieres(){
    this.filiereService.getAllFilieres().subscribe(data =>{
      this.filieres = data
    })
  }

  getSemestres(){
    this.semestreService.getAllSemestre().subscribe(data =>{
      this.semestres = data
    })
  }

  RechercheMatiere(){
    const donnees = this.myFormGroup.value
    this.donnee[0] = donnees.semestre
    this.donnee[1] = donnees.filiere
    this.matieresupService.ListeMFS(this.donnee).subscribe((data: any) =>{
      this.matieres = data
    })   
  }

  Rechercher(){
    this.controles = []; // Réinitialisation des résultats
    const donnees = this.myFormGroup.value    
    // Initialisation du tableau this.donnee correctement
    this.donnee = [
      donnees.annee,
      donnees.filiere,
      donnees.cours,
      donnees.semestre,
      donnees.matiere,
      this.user.administrateur.site.id
    ];
     // Vérifier si le formulaire est valide avant d'envoyer la requête
    if (this.myFormGroup.invalid) {
      console.warn("Formulaire invalide !");
      return;
    }

    this.noteService.getControleParClasse(this.donnee).subscribe((data: any) =>{
      this.controles = data
      this.resultat = true

      this.controles.sort((a, b) => {
        return a.etudiant.nom.localeCompare(b.etudiant.nom);
      });
      
      this.controles.forEach(controle => {
        const etudiantId = controle.etudiant.id.toString();
        this.myFormNote.addControl('noteclasse' + etudiantId, new FormControl(controle.noteclasse));
        this.myFormNote.addControl('noteexamen' + etudiantId, new FormControl(controle.noteexamen));
      });
      
    })

  }
  Modifier(etudiant: number,controle: string){
    //console.log(etudiant+" etudiant cc")
    const donnees = this.myFormGroup.value

    const infos = [ 
      controle,
      donnees.annee,
      etudiant,
      donnees.filiere,
      donnees.matiere,
      donnees.semestre,
      this.myFormNote.get('noteclasse'+etudiant)?.value,
      this.myFormNote.get('noteexamen'+etudiant)?.value
    ]
    this.succes = true
    this.noteService.updateNoteEtudiant(infos).subscribe({
      next: (responce) =>{        
        if(responce.status = "true")
        this.msgsucces = responce.message
        this.Rechercher();
      },
      error: (error) =>{
        this.msgsucces = "Erreur !!!"+error
      }
    });
    // Faire disparaître le message après 3 secondes (3000ms)
    setTimeout(() => {
      this.succes = false;
    }, 3000);
  }
  
}
