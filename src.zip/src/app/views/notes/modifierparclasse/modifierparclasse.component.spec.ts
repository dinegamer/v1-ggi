import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ModifierparclasseComponent } from './modifierparclasse.component';

describe('ModifierparclasseComponent', () => {
  let component: ModifierparclasseComponent;
  let fixture: ComponentFixture<ModifierparclasseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ModifierparclasseComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ModifierparclasseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
