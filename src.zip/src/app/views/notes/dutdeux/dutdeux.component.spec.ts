import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DutdeuxComponent } from './dutdeux.component';

describe('DutdeuxComponent', () => {
  let component: DutdeuxComponent;
  let fixture: ComponentFixture<DutdeuxComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DutdeuxComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DutdeuxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
