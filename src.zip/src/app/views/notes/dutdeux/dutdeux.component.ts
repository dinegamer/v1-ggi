import { Component, OnInit } from '@angular/core';
import { NoteService } from '../../../service/note.service';
import { FiliereService } from '../../../service/filiere.service';
import { AnneeuvService } from '../../../service/anneeuv.service';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Anneeuv } from '../../../model/anneeuv.model';
import { Filiere } from '../../../model/filiere.model';
import { CommonModule } from '@angular/common';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { NgSelectModule } from '@ng-select/ng-select';
import { Notedutdeux } from '../../../donnees/notedutdeux';
import { jsPDF } from "jspdf";
import { AuthService } from '../../../service/auth.service';
import { User } from '../../../model/user.model';
import { Etudiant } from '../../../model/etudiant.model';

@Component({
  selector: 'app-dutdeux',
  standalone: true,
  imports: [
    CommonModule,
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent, 
    ColComponent,
    RowComponent,
    ReactiveFormsModule,
    NgSelectModule,
    FormsModule
  ],
  templateUrl: './dutdeux.component.html',
  styleUrl: './dutdeux.component.scss'
})
export class DutdeuxComponent implements OnInit{
  donnee: any[] = [];
  filieres: Filiere[] = [];
  
  annees: Anneeuv[] = [];
  notedutdeuxs: Notedutdeux[] = [];
  filteredData: any[] = []; // Données filtrées
  searchText: string = '';
  currentPage: number = 1;
  itemsPerPage: number = 10;
  totalItems: number = 0;
  cours = [
    {id:1, nom:'JOUR'}, 
    {id:2, nom:'SOIR'}
  ]
  resultat: boolean = false
  user!: User
  isLoading: boolean = false;
  currentSortColumn: string = '';
  sortDirection: 'asc' | 'desc' = 'asc';

  readonly myFormGroup = new FormGroup({
    annee: new FormControl(""),
    cours: new FormControl(""),
    filiere: new FormControl(""),
    site: new FormControl("")
  });

  constructor(
    private anneeuvService: AnneeuvService, 
    private filiereService: FiliereService, 
    private noteService: NoteService,
    private authService: AuthService,
  ){}
  generatePDF(etudiant: Etudiant, mentionE: string) {
    let mention: string;

    if (mentionE === 'Admis') {
        mention = "Assez Bien";
    }

    const donnees = this.myFormGroup.value;
    const selectedFiliere = this.filieres.find(f => f.id === Number(donnees.filiere));
    const selectedAnne = this.annees.find(a => a.id === Number(donnees.annee));

    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();

    // Créer un nouvel objet Image
    const imgTop = new Image();
    const imgBottom = new Image();
    const imgLeft = new Image();
    const imgRight = new Image();
    const imgData = new Image();

    imgTop.src = 'assets/images/border.png';
    imgBottom.src = 'assets/images/border.png';

    imgLeft.src = 'assets/images/bordergd.png';
    imgRight.src = 'assets/images/bordergd.png';

    imgData.src = 'assets/images/logo.png';

    // Ajouter les images seulement après qu'elles soient toutes chargées
    imgData.onload = () => {
        // Les images peuvent être ajoutées seulement après leur chargement
        doc.addImage(imgTop, 'PNG', 8, 13, pageWidth - 20, 7);
        doc.addImage(imgBottom, 'PNG', 8, pageHeight - 20, pageWidth - 20, 7);
        doc.addImage(imgLeft, 'PNG', 10, 20, 5, pageHeight - 40);
        doc.addImage(imgRight, 'PNG', pageWidth - 19, 20, 5, pageHeight - 40);

        doc.setFont('Times', 'normal');
        doc.setFontSize(12);

        doc.text("MINISTERE DE L'ENSEIGNEMENT SUPERIEUR", 20, 25);
        doc.text("ET DE LA RECHERCHE SCIENTIFIQUE", 23, 30);
        doc.text("************************", 25, 35);
        doc.text("REPUBLIQUE DU MALI", 137, 25);
        doc.text("Un Peuple - Un But - Une Foi", 135, 30);
        doc.text("*********************", 137, 35);

        doc.addImage(imgData, 'PNG', 25, 37, 25, 25);
        doc.addImage(imgData, 'PNG', 155, 37, 25, 25);

        doc.setTextColor(0, 0, 255);
        doc.setFont('Times', 'normal');
        doc.setFontSize(12);
        doc.text("INSTITUT SUPERIEUR DES TECHNIQUE ECONOMIQUES", 47, 42);
        doc.text("COMPTABLES ET COMMERCIALES - INTEC SUP", 52, 47);
        
        doc.setTextColor(0, 0, 0)
        doc.setFont('Times', 'bold');
        doc.setFontSize(12);
        doc.text("Etablissement Supérieur d'Enseignement Professionnel", 52, 55);

        doc.setFont('Times', 'normal');
        doc.setFontSize(6);
        doc.text(this.user.administrateur.site.adresse, 25, 65);

        doc.setLineWidth(0.5);
        doc.line(15, 67, 190, 67);

        doc.setTextColor(0, 0, 255);
        doc.setFont('Times', 'bold');
        doc.setFontSize(20);
        doc.text("ATTESTATION DE DIPLÔME", 50, 80);

        doc.setTextColor(0, 0, 0)
        doc.setFont('Times', 'normal');
        doc.setFontSize(12);
        //les donnees
        const donnees = this.myFormGroup.value
        //debut du text
        const debut = 20
        const interligne = 12
        const initial = 85
        doc.text("Je soussigné, Monsieur " + this.user.administrateur.prenom + " " + this.user.administrateur.nom + ", " + this.user.administrateur.role.description, debut, initial+interligne);
        doc.text("de l'Institut Supérieur des Techniques Economiques, Comptables et Commerciales (INTEC SUP), ", debut, initial+(interligne*2));
        doc.text("atteste par la présente que :  ", debut, initial+(interligne*3));
        doc.text("Mll/Mme " + etudiant.prenom + " " + etudiant.nom + " né(e) le " + etudiant.naissance, debut, initial+(interligne*4));
        doc.text(" a validé les modules du DUT ", debut, initial+(interligne*5));
        
        doc.text("en " +selectedFiliere?.departement.nom, debut, initial+(interligne*6));
        

        doc.text("Filière : " + selectedFiliere?.description, debut, initial+(interligne*7));
        doc.text("Au titre de l'année universitaire " + selectedAnne?.nom + "      Mention : " + mention, debut, initial+(interligne*8));
        doc.text("Cette attestion lui est délivrée pour servir et valoir ce que de droit.", debut, initial+(interligne*9));

        const today = new Date();
        const day = today.getDate().toString().padStart(2, '0');
        const month = (today.getMonth() + 1).toString().padStart(2, '0');
        const year = today.getFullYear();
        const formattedDate = `${day}/${month}/${year}`;
        doc.text("Fait à Bamako, le " + formattedDate, 120, 210);

        doc.setFont('Times', 'bold');
        doc.text(this.user.administrateur.role.description, 130, 215);
        doc.text("M. " + this.user.administrateur.prenom + " " + this.user.administrateur.nom, 120, 235);

        doc.text("NB : il n'est délivré qu'un seul exemplaire de cette attestion.", debut, 250);
        
        doc.setFont('Times', 'normal');
        doc.setFontSize(6);
        doc.text(this.user.administrateur.site.adresse, debut, 270);

        const blob = doc.output('blob');
        const blobUrl = URL.createObjectURL(blob);
        window.open(blobUrl, '_blank');
    };

    // En cas d'échec du chargement de l'image
    imgData.onerror = (error) => {
        console.error('Erreur de chargement de l\'image:', error);
    };
}



  ngOnInit(): void {
    this.getAnneeuv()
    this.getFiliereParCycle()
    this.user = this.authService.getUserFromLocalStorage()
    this.filteredData = [...this.notedutdeuxs];
    this.totalItems = this.filteredData.length;
  }
 
  applyFilter() {
    if (!this.searchText) {
      this.filteredData = [...this.notedutdeuxs];
    } else {
      const searchLower = this.searchText.toLowerCase();
      this.filteredData = this.notedutdeuxs.filter(notedutdeux => 
        notedutdeux.etudiant.nom.toLowerCase().includes(searchLower) ||
        notedutdeux.etudiant.prenom.toLowerCase().includes(searchLower) ||
        notedutdeux.mention.toLowerCase().includes(searchLower)
      );
    }
    this.currentPage = 1;
    this.totalItems = this.filteredData.length;
  }

  changeItemsPerPage(number: number) {
    this.itemsPerPage = number;
    this.currentPage = 1;
  }

  getTotalPages(): number {
    return Math.ceil(this.filteredData.length / this.itemsPerPage);
  }

  getPages(): number[] {
    const totalPages = this.getTotalPages();
    return Array.from({length: totalPages}, (_, i) => i + 1);
  }

  previousPage() {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }

  nextPage() {
    if (this.currentPage < this.getTotalPages()) {
      this.currentPage++;
    }
  }

  goToPage(page: number) {
    this.currentPage = page;
  }


  getFiliereParCycle(){
    this.filiereService.getFiliereParCycle(5).subscribe((data: any) =>{
      this.filieres = data
    })
  }

  getAnneeuv(){
    this.anneeuvService.getAllAnnee().subscribe(data =>{
      this.annees = data
    })
  }
  RechercheControles(){
    this.isLoading = true;
    this.resultat = false;

    const donnees = this.myFormGroup.value
    this.donnee[0] = donnees.annee
    this.donnee[1] = donnees.filiere
    this.donnee[2] = donnees.cours
    this.donnee[3] = 3
    this.donnee[4] = 5
    this.donnee[5] = this.user.administrateur.site.id
    //retrouver la filiere
   

    this.noteService.getControleDutDeux(this.donnee).subscribe({
      next: (data: Notedutdeux[]) => {
      this.notedutdeuxs = data;
      this.filteredData = [...data]; // Initialise les données filtrées
      this.resultat = true;
      
      // Optionnel: Trie par nom par défaut
      this.sortData('nom');
      },
      error: (err) => {
        console.error('Erreur lors de la récupération des notes:', err);
        this.resultat = false;
        this.notedutdeuxs = [];
        this.filteredData = [];
      },
      complete: () => {
        this.isLoading = false; 
        console.log('Récupération des notes terminée');
      }
    })

  }
  sortData(column: keyof Notedutdeux['etudiant'] | keyof Notedutdeux): void {
    this.filteredData.sort((a, b) => {
      if (column === 'nom' || column === 'prenom') {
        return a.etudiant[column].localeCompare(b.etudiant[column]);
      } else if (typeof a[column] === 'number') {
        return (a[column] as number) - (b[column] as number);
      }
      return 0;
    });
  }
  // Méthode de tri
  sortTable(column: string) {
    if (this.currentSortColumn === column) {
      // Inverse le sens si on clique sur la même colonne
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      // Nouvelle colonne, tri ascendant par défaut
      this.currentSortColumn = column;
      this.sortDirection = 'asc';
    }

    this.filteredData.sort((a, b) => {
      let valueA, valueB;

      // Gestion spéciale pour Nom & Prénom
      if (column === 'nomPrenom') {
        valueA = `${a.etudiant.prenom} ${a.etudiant.nom}`.toLowerCase();
        valueB = `${b.etudiant.prenom} ${b.etudiant.nom}`.toLowerCase();
      } else {
        valueA = this.getSortValue(a, column);
        valueB = this.getSortValue(b, column);
      }

      // Comparaison
      if (valueA < valueB) return this.sortDirection === 'asc' ? -1 : 1;
      if (valueA > valueB) return this.sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
  }

  // Helper pour extraire les valeurs de tri
  private getSortValue(item: any, column: string): any {
    const columnMapping: {[key: string]: string} = {
      'moyenneS3': 'mgsun',
      'moyenneS4': 'mgsdeux',
      'moyenneAnnuelle': 'mannuel',
      'dut': 'mdut',
      'moyenneGenerale': 'mannuel', // Supposé identique à moyenneAnnuelle
      'mention': 'mention',
      'credits': 'credit',
      'appreciation': 'appreciation'
    };

    return item[columnMapping[column] || column];
  }

  // Icône de tri
  getSortIcon(column: string): string {
    if (this.currentSortColumn !== column) return 'bi bi-arrow-down-up';
    return this.sortDirection === 'asc' ? 'bi bi-arrow-up' : 'bi bi-arrow-down';
  }
}
