import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    data: {
      title: 'Notes'
    },
    children: [ 
      {
        path: '',
        redirectTo: 'notes',
        pathMatch: 'full'
      },
      {
        path: 'notes',
        loadComponent: () => import('./notes.component').then(m => m.NotesComponent),
        data: {
          title: 'Notes'
        }
      },
      {
        path: 'ajoutparetudiant',
        loadComponent: () => import('./ajoutparetudiant/ajoutparetudiant.component').then(m => m.AjoutparetudiantComponent),
        data: {
          title: 'Ajout par etudiant'
        }
      },
      {
        path: 'ajoutparclasse',
        loadComponent: () => import('./ajoutparclasse/ajoutparclasse.component').then(m => m.AjoutparclasseComponent),
        data: {
          title: 'Ajout par classe'
        }
      },
      {
        path: 'fichedenote',
        loadComponent: () => import('./fichedenote/fichedenote.component').then(m => m.FichedenoteComponent),
        data: {
          title: 'Fiche de Note'
        }
      },
      {
        path: 'modifierparetudiant',
        loadComponent: () => import('./modifierparetudiant/modifierparetudiant.component').then(m => m.ModifierparetudiantComponent),
        data: {
          title: 'Modifier par Etudiant'
        }
      },
      {
        path: 'modifierparclasse',
        loadComponent: () => import('./modifierparclasse/modifierparclasse.component').then(m => m.ModifierparclasseComponent),
        data: {
          title: 'Modifier par Classe'
        }
      },
      {
        path: 'resultatparclasse',
        loadComponent: () => import('./resultatparclasse/resultatparclasse.component').then(m => m.ResultatparclasseComponent),
        data: {
          title: 'Resultat par classe'
        }
      },
      {
        path: 'releveretudiant',
        loadComponent: () => import('./releveretudiant/releveretudiant.component').then(m => m.ReleveretudiantComponent),
        data: {
          title: 'Relever etudiant'
        }
      },
      {
        path: 'noteparmatiere',
        loadComponent: () => import('./noteparmatiere/noteparmatiere.component').then(m => m.NoteparmatiereComponent),
        data: {
          title: 'Note Par Matière'
        }
      },
      {
        path: 'modifierparclasse',
        loadComponent: () => import('./modifierparclasse/modifierparclasse.component').then(m => m.ModifierparclasseComponent),
        data: {
          title: 'Modifier les notes pour un classe'
        }
      },
      {
        path: 'modifierparetudiant',
        loadComponent: () => import('./modifierparetudiant/modifierparetudiant.component').then(m => m.ModifierparetudiantComponent),
        data: {
          title: 'Modifier les notes pour un étudiant'
        }
      },
      {
        path: 'dutun',
        loadComponent: () => import('./dutun/dutun.component').then(m => m.DutunComponent),
        data: {
          title: 'Statistique DUT 1'
        }
      },
      {
        path: 'dutdeux',
        loadComponent: () => import('./dutdeux/dutdeux.component').then(m => m.DutdeuxComponent),
        data: {
          title: 'Statistique DUT 2'
        }
      },
      {
        path: 'lun',
        loadComponent: () => import('./lun/lun.component').then(m => m.LunComponent),
        data: {
          title: 'Statistique Licence 1'
        }
      },
      {
        path: 'ldeux',
        loadComponent: () => import('./ldeux/ldeux.component').then(m => m.LdeuxComponent),
        data: {
          title: 'Statistique Licence 2'
        }
      },
      {
        path: 'ltrois',
        loadComponent: () => import('./ltrois/ltrois.component').then(m => m.LtroisComponent),
        data: {
          title: 'Statistique Licence 3'
        }
      },
      {
        path: 'mun',
        loadComponent: () => import('./mun/mun.component').then(m => m.MunComponent),
        data: {
          title: 'Statistique Master 1'
        }
      },
      {
        path: 'mdeux',
        loadComponent: () => import('./mdeux/mdeux.component').then(m => m.MdeuxComponent),
        data: {
          title: 'Statistique Master 2'
        }
      },
      {
        path: 'statistiques',
        loadComponent: () => import('./statistiques/statistiques.component').then(m => m.StatistiquesComponent),
        data: {
          title: 'Statistiques'
        }
      }
    ]
  }
];
