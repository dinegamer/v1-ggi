import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { NgSelectModule } from '@ng-select/ng-select';
import { Filiere } from '../../../model/filiere.model';
import { Matieresup } from '../../../model/matieresup.model';
import { Semestre } from '../../../model/semestre.model';
import { FiliereService } from '../../../service/filiere.service';
import { MatieresupService } from '../../../service/matieresup.service';
import { SemestreService } from '../../../service/semestre.service';
import { Etudiant } from '../../../model/etudiant.model';
import { NoteService } from '../../../service/note.service';
import { AuthService } from '../../../service/auth.service';
import { User } from '../../../model/user.model';
import { NoteModel } from '../../../model/note.model';
import { Anneeuv } from '../../../model/anneeuv.model';
import { AnneeuvService } from '../../../service/anneeuv.service';
import $ from 'jquery';
import 'datatables.net';

@Component({
  selector: 'app-ajoutparclasse',
  standalone: true,
  imports: [    
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent, 
    ColComponent,
    RowComponent,
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    NgSelectModule  
  ],
  templateUrl: './ajoutparclasse.component.html',
  styleUrl: './ajoutparclasse.component.scss'
})
export class AjoutparclasseComponent implements OnInit{
  user!: User
  filieres: Filiere[] = [];
  semestres: Semestre[] = [];
  matieres: Matieresup[] = [];
  donnee: any[] = [];
  inscrires: Etudiant[] = [];
  resultat: boolean = false;
  cours = [
    {id:1, nom:'JOUR'},
    {id:2, nom:'SOIR'}
  ];
  controles: NoteModel[] = []
  annees: Anneeuv[] = []

  readonly myFormGroup = new FormGroup({
    annee: new FormControl(""),
    cours: new FormControl(""),
    filiere: new FormControl(""),
    semestre: new FormControl(""),
    matiere: new FormControl(""),
    site: new FormControl(""),    
  });
  myFormNote: FormGroup;

  ngOnInit(): void {
    this.getFilieres()
    this.getSemestres()
    this.getAnnee()
    this.user = this.authService.getUserFromLocalStorage();   
    
  }
  constructor(
    private noteService: NoteService, 
    private filiereService: FiliereService,
    private semestreService: SemestreService,
    private matieresupService: MatieresupService, 
    private authService: AuthService,
    private anneeService: AnneeuvService
  ){   this.myFormNote = new FormGroup({});  }
  getAnnee(){
    this.anneeService.getAllAnnee().subscribe({
      next: (data) => {
        this.annees = data
      },
      error: (error) => {
        console.log("Erreur de connexion a la base "+error)
      }
    })
  }
  getFilieres(){
    this.filiereService.getAllFilieres().subscribe(data =>{
      this.filieres = data
    })
  }

  getSemestres(){
    this.semestreService.getAllSemestre().subscribe(data =>{
      this.semestres = data
    })
  }

  RechercheMatiere(){
    const donnees = this.myFormGroup.value
    this.donnee[0] = donnees.semestre
    this.donnee[1] = donnees.filiere
    this.matieresupService.ListeMFS(this.donnee).subscribe((data: any) =>{
      this.matieres = data
    })   
  }
  Rechercher(){
    const donnees = this.myFormGroup.value
    this.donnee[0] = donnees.annee
    this.donnee[1] = donnees.filiere
    this.donnee[2] = donnees.cours
    this.donnee[3] = donnees.semestre
    this.donnee[4] = donnees.matiere
    this.donnee[5] = this.user.administrateur.site.id
   
    this.noteService.getControleParClasse(this.donnee).subscribe((data: any) =>{
      this.controles = data
      this.resultat = true
      this.controles.sort((a, b) => {
        return a.etudiant.nom.localeCompare(b.etudiant.nom);
      });
      this.controles.forEach(controle => {
        const etudiantId = controle.etudiant.id.toString();
        this.myFormNote.addControl('noteclasse' + etudiantId, new FormControl(controle.noteclasse));
        this.myFormNote.addControl('noteexamen' + etudiantId, new FormControl(controle.noteexamen));
      });
    })
    
    
  }
  Enregistre(etudiant: any){
    //console.log(etudiant+" etudiant cc") 
    const donnees = this.myFormGroup.value

    const infos = [
      this.user.parametre.anneepardefaut.id,
      etudiant, 
      donnees.filiere,
      donnees.matiere,
      donnees.semestre,
      this.myFormNote.get('noteclasse'+etudiant)?.value,
      this.myFormNote.get('noteexamen'+etudiant)?.value
    ]
    this.noteService.saveNoteEtudiant(infos).subscribe({
      next: (responce) =>{
        console.log(responce.message+" mdt !!")
        this.Rechercher();
      },
      error: (error) =>{
        console.log("Erreur !!!")
      }
    });
  }
  
}
