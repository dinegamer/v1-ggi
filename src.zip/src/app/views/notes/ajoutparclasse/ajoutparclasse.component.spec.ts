import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AjoutparclasseComponent } from './ajoutparclasse.component';

describe('AjoutparclasseComponent', () => {
  let component: AjoutparclasseComponent;
  let fixture: ComponentFixture<AjoutparclasseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AjoutparclasseComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AjoutparclasseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
