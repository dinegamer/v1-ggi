import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FichedenoteComponent } from './fichedenote.component';

describe('FichedenoteComponent', () => {
  let component: FichedenoteComponent;
  let fixture: ComponentFixture<FichedenoteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FichedenoteComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(FichedenoteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
