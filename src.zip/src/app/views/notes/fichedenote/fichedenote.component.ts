import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { NgSelectModule } from '@ng-select/ng-select';
import { Semestre } from '../../../model/semestre.model';
import { SemestreService } from '../../../service/semestre.service';
import { Filiere } from '../../../model/filiere.model';
import { FiliereService } from '../../../service/filiere.service';
import { Matieresup } from '../../../model/matieresup.model';
import { MatieresupService } from '../../../service/matieresup.service';
import { Etudiant } from '../../../model/etudiant.model';
import { InscriptionService } from '../../../service/inscription.service';
import { User } from '../../../model/user.model';
import { AuthService } from '../../../service/auth.service';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { Anneeuv } from '../../../model/anneeuv.model';
import { AnneeuvService } from '../../../service/anneeuv.service';
import { jsPDF } from 'jspdf';

@Component({
  selector: 'app-fichedenote',
  standalone: true,
  imports: [
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent, 
    ColComponent,
    RowComponent,
    RouterModule,
    NgSelectModule,
    ReactiveFormsModule,
    CommonModule
  ],
  templateUrl: './fichedenote.component.html',
  styleUrl: './fichedenote.component.scss'
})
export class FichedenoteComponent implements OnInit{
  user!: User
  cours = [
    {id:1, nom:'JOUR'},
    {id:2, nom:'SOIR'}
  ]
  semestres: Semestre[] = []
  filieres: Filiere[] = []
  matieres: Matieresup[] = []
  etudiants: Etudiant[] = []
  annees: Anneeuv[] = []
  demande: boolean = false
  typesession: string = ""
  semestre!: string
  filiere!: string
  matiereSelect!: Matieresup
  filiereSelect!: Filiere
  semestreSelect!: Semestre

  ngOnInit(): void {
    this.getAllSemestre()
    this.getAllFiliere()
    this.getAllAnnee()
    this.user = this.authService.getUserFromLocalStorage()
  }

  constructor(
    private semestreService: SemestreService,
    private filiereService: FiliereService,
    private matieresupService: MatieresupService,
    private inscrireService: InscriptionService,
    private authService: AuthService,
    private anneeService: AnneeuvService
  ){}
  readonly myFormGroup = new FormGroup({
    annee: new FormControl(""),
    cours: new FormControl(""),
    filiere: new FormControl(""),
    semestre: new FormControl(""),
    etudiant: new FormControl(""),
    matiere: new FormControl(""),
    site: new FormControl(""),
    typesession: new FormControl("")
  });

  onSelectionChange(event: any) {
    this.matiereSelect = event;  // L'événement contient l'objet sélectionné
  }
  SelectSemestre(event: any){
    this.semestreSelect = event;
  }
  Afficher(){
    this.demande = true
    const donnees = this.myFormGroup.value
    let donnee = [
      donnees.annee,
      donnees.cours,
      donnees.filiere,
      this.user.administrateur.site.id
    ]
    this.inscrireService.getListeParClasse(donnee).subscribe(data =>{
      this.etudiants = data.sort((a, b) => a.nom.localeCompare(b.nom));
    })
    if(donnees.typesession != null){
      this.typesession = donnees.typesession
    }
    
    
  }
 // Fonction pour imprimer une section spécifique
 printContent() {
    const imageUrl = 'assets/images/logo-v.png';
    const img = new Image();
    img.src = imageUrl;
    
    const pdf = new jsPDF('p', 'pt', 'a4');
    pdf.addImage(img,'PNG', 20, 20, 70, 70);
    // Titre et en-tête
    pdf.setFont("Times","bold")
    pdf.setFontSize(16);
    pdf.text("INSTITUT SUPERIEUR DES TECHNIQUES", 355, 30, { align: 'center' });
    pdf.text("ECONOMIQUES COMPTABLES ET COMMERCIALES", 355, 50, { align: 'center' });
    pdf.text("DUT - LICENCE - MASTER", 355, 70, { align: 'center' });
    
    // Logo (optionnel - vous pouvez garder la version image si besoin)
    // pdf.addImage(logoData, 'PNG', 40, 20, 60, 60);
    
    // Section Note d'examen
   
    pdf.setFontSize(14);
    pdf.text("NOTE D'EXAMEN", 300, 120, { align: 'center' });

    pdf.setFont("Times","normal")
    pdf.setFontSize(12);
    pdf.text(`DATE : départ ....... /....... /....... et Arrivée ....... /....... /.......`, 40, 150);
    pdf.text(`Examen du ${this.semestreSelect.libelle} : ${this.typesession}`, 40, 170);
    pdf.text(`Classe : ${this.filiereSelect.description}`, 40, 190);
    pdf.text(`Matière : ${this.matiereSelect.nom}`, 40, 210);
    
    // En-tête du tableau
    pdf.setFontSize(10);
    const headers = ["N°", "Matricule", "Nom", "Prénom", "DEVOIR", "EXAMEN"];
    const columnPositions = [40, 80, 150, 250, 350, 420];
    
    // Configuration des styles
    pdf.setDrawColor(0); // Couleur noire pour les bordures
    pdf.setLineWidth(0.3); // Épaisseur des traits
    const rowHeight = 20;
    const headerY = 230;
    const cellPadding = 5;
    const fontFamily = 'Times'; // Police de caractères

    // Dessiner les en-têtes
    headers.forEach((header, i) => {
      const colWidth = i === headers.length - 1 
        ? pdf.internal.pageSize.width - columnPositions[i] - 40 
        : columnPositions[i+1] - columnPositions[i];
      
      // Rectangle avec bordure seulement (mode 'D')
      pdf.rect(columnPositions[i], headerY, colWidth, rowHeight, 'D');
      
      // Style du texte d'en-tête
      pdf.setTextColor(0); // Noir
      pdf.setFont(fontFamily, 'bold');
      pdf.text(header, columnPositions[i] + cellPadding, headerY + rowHeight/2 + 3);
    });

    // Dessiner les lignes des étudiants
    let y = 260; // Position Y de départ
    this.etudiants.forEach((etudiant, index) => {
      // Dessiner chaque cellule de la ligne
      headers.forEach((_, i) => {
        const colWidth = i === headers.length - 1 
          ? pdf.internal.pageSize.width - columnPositions[i] - 40 
          : columnPositions[i+1] - columnPositions[i];
        
        // Rectangle avec bordure seulement
        pdf.rect(columnPositions[i], y - rowHeight/2, colWidth, rowHeight, 'D');
        
        // Contenu des cellules
        let text = '';
        if (i === 0) text = (index + 1).toString();
        else if (i === 1) text = etudiant.matricule;
        else if (i === 2) text = etudiant.nom;
        else if (i === 3) text = etudiant.prenom;
        
        pdf.setTextColor(0);
        pdf.setFont(fontFamily, 'normal');
        pdf.text(text, columnPositions[i] + cellPadding, y + 3);
      });
      
      y += rowHeight; // Passage à la ligne suivante
      
      // Gestion des sauts de page
      if (y > pdf.internal.pageSize.height - 30) {
        pdf.addPage();
        y = 40 + rowHeight/2; // Réinitialiser la position Y
      }
    });

    // Optionnel: Ajouter une ligne de séparation finale
    pdf.setLineWidth(0.5);
    pdf.line(40, y - rowHeight/2 + 1, pdf.internal.pageSize.width - 40, y - rowHeight/2 + 1);

    // Ligne de séparation finale
    pdf.setDrawColor(0);
    pdf.setLineWidth(0.5);
    pdf.line(40, y - rowHeight/2 + 1, pdf.internal.pageSize.width - 40, y - rowHeight/2 + 1);
    // Au lieu de pdf.save(), on utilise:
    const pdfBlob = pdf.output('blob');
    const pdfUrl = URL.createObjectURL(pdfBlob);
    
    // Ouvrir dans une nouvelle fenêtre
    window.open(pdfUrl, '_blank');
    
    // Libérer la mémoire après un délai
    setTimeout(() => {
      URL.revokeObjectURL(pdfUrl);
    }, 100);
  }
  RechercheMatiere(event: any){
    const donnees = this.myFormGroup.value    
    let donnee = [donnees.semestre,donnees.filiere]
    if(donnees.semestre == ""){
      alert("Choisir le semestre ?")
      return
    }    
    console.log(" ** "+donnee+" ** ")
    this.matieresupService.ListeMFS(donnee).subscribe((data: any) =>{
      this.matieres = data
    })
    this.filiereSelect = event
  }
  getAllAnnee(){
    this.anneeService.getAllAnnee().subscribe({
      next: (data) => { this.annees = data},
      error: (error) => {console.log(" ** "+error)}
    })
  }
  
  getAllSemestre(){
    this.semestreService.getAllSemestre().subscribe((res: any) =>{
      this.semestres = res
    })
  }

  getAllFiliere(){
    this.filiereService.getAllFilieres().subscribe(data => {
       this.filieres = data
    });
  }
  getAllMatiere(){
   this.matieresupService.getAllMatieresup().subscribe(data =>{
    this.matieres = data
   })
  }
  exportToExcel(): void {
    const table = document.getElementById('monTableau') as HTMLTableElement;
    
    if (!table) {
      console.error("Tableau non trouvé !");
      return;
    }

    const worksheet: XLSX.WorkSheet = XLSX.utils.table_to_sheet(table);
    const workbook: XLSX.WorkBook = { Sheets: { 'Feuille1': worksheet }, SheetNames: ['Feuille1'] };
    const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });

    const data: Blob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });

    saveAs(data, 'export.xlsx');    
  }
}
