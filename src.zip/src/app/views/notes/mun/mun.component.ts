import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { Anneeuv } from '../../../model/anneeuv.model';
import { Filiere } from '../../../model/filiere.model';
import { AnneeuvService } from '../../../service/anneeuv.service';
import { FiliereService } from '../../../service/filiere.service';
import { NgSelectModule } from '@ng-select/ng-select';
import { User } from '../../../model/user.model';
import { AuthService } from '../../../service/auth.service';
import { Notedutun } from '../../../donnees/notedutun';
import { NoteService } from '../../../service/note.service';
import { AttestationPdfService } from './../../../service/attestation-pdf.service';
import { Etudiant } from './../../../model/etudiant.model';
@Component({
  selector: 'app-mun',
  standalone: true,
  imports: [
    CommonModule,
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent,
    ColComponent,
    RowComponent,
    ReactiveFormsModule,
    NgSelectModule
  ],
  templateUrl: './mun.component.html',
  styleUrl: './mun.component.scss'
})
export class MunComponent implements OnInit{
  donnee: any[] = [];
  filieres: Filiere[] = [];
  annees: Anneeuv[] = [];
  notemasteruns: Notedutun[] = [];
  cours = [
    {id:1, nom:'JOUR'},
    {id:2, nom:'SOIR'}
  ]
  user!: User
  resultat: boolean = false

  readonly myFormGroup = new FormGroup({
    annee: new FormControl(""),
    cours: new FormControl(""),
    filiere: new FormControl(""),
  });

  constructor(
    private anneeuvService: AnneeuvService,
    private filiereService: FiliereService,
    private noteService: NoteService,
    private pdfService: AttestationPdfService,
    private authService: AuthService
  ){}
generatePDF(etudiant: Etudiant, appreciation: string) {
    const formData = this.myFormGroup.value;
    const filiere = this.filieres.find(f => f.id === Number(formData.filiere));
    const annee = this.annees.find(a => a.id === Number(formData.annee));


    if (filiere && annee && this.user) {
      this.pdfService.generatePDF(etudiant, appreciation, this.user, filiere, annee);
    }
  }
  ngOnInit(): void {
    this.getAnneeuv()
    this.getFiliereParCycle()
    this.user = this.authService.getUserFromLocalStorage()
  }

  getFiliereParCycle(){
    this.filiereService.getFiliereParCycle(8).subscribe((data: any) =>{
      this.filieres = data
    })
  }

  getAnneeuv(){
    this.anneeuvService.getAllAnnee().subscribe(data =>{
      this.annees = data
    })
  }
  RechercheControles(){
    const donnees = this.myFormGroup.value
    this.donnee[0] = donnees.annee
    this.donnee[1] = donnees.filiere
    this.donnee[2] = donnees.cours
    this.donnee[3] = 1
    this.donnee[4] = 2
    this.donnee[5] = this.user.administrateur.site.id
    this.noteService.getControleDutUn(this.donnee).subscribe((data: any) =>{
      this.resultat = true
      this.notemasteruns = data
    })

  }
}
