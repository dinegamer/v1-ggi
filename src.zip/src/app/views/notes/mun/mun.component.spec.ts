import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MunComponent } from './mun.component';

describe('MunComponent', () => {
  let component: MunComponent;
  let fixture: ComponentFixture<MunComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MunComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(MunComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
