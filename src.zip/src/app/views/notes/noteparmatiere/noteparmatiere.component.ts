import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { NgSelectModule } from '@ng-select/ng-select';
import { Filiere } from '../../../model/filiere.model';
import { Matieresup } from '../../../model/matieresup.model';
import { Semestre } from '../../../model/semestre.model';
import { FiliereService } from '../../../service/filiere.service';
import { MatieresupService } from '../../../service/matieresup.service';
import { SemestreService } from '../../../service/semestre.service';
import { Etudiant } from '../../../model/etudiant.model';
import { NoteService } from '../../../service/note.service';
import { AuthService } from '../../../service/auth.service';
import { User } from '../../../model/user.model';
import { NoteModel } from '../../../model/note.model';
import { Anneeuv } from '../../../model/anneeuv.model';
import { AnneeuvService } from '../../../service/anneeuv.service';
import { NgxPaginationModule } from 'ngx-pagination';
import { OrderModule } from 'ngx-order-pipe';

@Component({
  selector: 'app-noteparmatiere',
  standalone: true,
  imports: [
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent, 
    ColComponent,
    RowComponent,
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    NgSelectModule,
    FormsModule,
    NgxPaginationModule,
    OrderModule
  ],
  templateUrl: './noteparmatiere.component.html',
  styleUrl: './noteparmatiere.component.scss'
})
export class NoteparmatiereComponent implements OnInit{
  user!: User
  filieres: Filiere[] = [];
  semestres: Semestre[] = [];
  matieres: Matieresup[] = [];
  donnee: any[] = [];
  inscrires: Etudiant[] = [];
  resultat: boolean = false;
  anneeuvs: Anneeuv[] = [];
  cours = [
    {id:1, nom:'JOUR'},
    {id:2, nom:'SOIR'}
  ];
  controles: NoteModel[] = []

  page: number = 1;
  searchText: string = '';
  sortColumn: string = '';
  sortDirection: string = 'asc';
  itemsPerPage: number = 10; // Valeur par défaut
  currentPage: number = 1; // Page courante

  readonly myFormGroup = new FormGroup({
    annee: new FormControl(""),
    cours: new FormControl(""),
    filiere: new FormControl(""),
    semestre: new FormControl(""),
    matiere: new FormControl(""),
    site: new FormControl(""),    
  });
  

  ngOnInit(): void {
    this.getFilieres()
    this.getSemestres()
    this.user = this.authService.getUserFromLocalStorage();   
    this.getAllAnnee()
  }
  constructor(
    private noteService: NoteService, 
    private filiereService: FiliereService,
    private semestreService: SemestreService,
    private matieresupService: MatieresupService, 
    private anneeuvService: AnneeuvService,
    private authService: AuthService
  ){    }
  changeItemsPerPage(){}
  sort(column: string) {
    if (this.sortColumn === column) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumn = column;
      this.sortDirection = 'asc';
    }
  }
  getSortIcon(column: string): string {
    if (this.sortColumn !== column) {
      return '⇅'; // Icône neutre
    }
    return this.sortDirection === 'asc' ? '↑' : '↓';
  }

  getAllAnnee(){
    this.anneeuvService.getAllAnnee().subscribe(data =>{
      this.anneeuvs = data 
    })
  }
  getFilieres(){
    this.filiereService.getAllFilieres().subscribe(data =>{
      this.filieres = data
    })
  }

  getSemestres(){
    this.semestreService.getAllSemestre().subscribe(data =>{
      this.semestres = data
    })
  }

  RechercheMatiere(){
    const donnees = this.myFormGroup.value
    this.donnee[0] = donnees.semestre
    this.donnee[1] = donnees.filiere
    this.matieresupService.ListeMFS(this.donnee).subscribe((data: any) =>{
      this.matieres = data
    })   
  }
  Rechercher(){
    const donnees = this.myFormGroup.value
    this.donnee[0] = donnees.annee
    this.donnee[1] = donnees.filiere
    this.donnee[2] = donnees.cours
    this.donnee[3] = donnees.semestre
    this.donnee[4] = donnees.matiere
    this.donnee[5] = this.user.administrateur.site.id
    
    this.noteService.getNotes(this.donnee).subscribe((data: any) =>{
      this.controles = data
      this.resultat = true      
    })
  }
  Supprimer(controleId: string){
    if (confirm('Voulez-vous vraiment supprimer la note ?')) {
      this.noteService.deleteControleById(controleId).subscribe({
        next: (response) => {
          alert('note supprimé avec succès !'+response);
          this.Rechercher()
        },
        error: (error) =>{console.log("Erreur !!!"+error)}
      });
    }
  }
  SupprimerEnsemble(){
    if (confirm("Voulez-vous vraiment supprimer l'ensemble des notes ?")) {
      this.noteService.deleteAllControles(this.donnee).subscribe({
        next: (response) => {
          alert(response.message);
          this.Rechercher();  // Rechercher les nouvelles données après suppression
        },
        error: (error) => {
          console.log('Erreur lors de la suppression des notes');
        }
      });
    }
  }
}
