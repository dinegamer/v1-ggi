import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NoteparmatiereComponent } from './noteparmatiere.component';

describe('NoteparmatiereComponent', () => {
  let component: NoteparmatiereComponent;
  let fixture: ComponentFixture<NoteparmatiereComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [NoteparmatiereComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(NoteparmatiereComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
