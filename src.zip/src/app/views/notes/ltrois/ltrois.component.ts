import { CommonModule } from '@angular/common';
import { Component, OnInit, Pipe, PipeTransform } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { Anneeuv } from '../../../model/anneeuv.model';
import { Filiere } from '../../../model/filiere.model';
import { AnneeuvService } from '../../../service/anneeuv.service';
import { FiliereService } from '../../../service/filiere.service';
import { NgSelectModule } from '@ng-select/ng-select';
import { User } from '../../../model/user.model';
import { Notedutun } from '../../../donnees/notedutun';
import { AuthService } from '../../../service/auth.service';
import { NoteService } from '../../../service/note.service';
import { jsPDF } from 'jspdf';
import { AttestationPdfService } from './../../../service/attestation-pdf.service';
import { Etudiant } from './../../../model/etudiant.model';

@Component({
  selector: 'app-ltrois',
  standalone: true,
  imports: [
    CommonModule,
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent,
    ColComponent,
    RowComponent,
    ReactiveFormsModule,
    NgSelectModule,
    FormsModule
  ],
  templateUrl: './ltrois.component.html',
  styleUrl: './ltrois.component.scss'
})

export class LtroisComponent implements OnInit{
  donnee: any[] = [];
  filieres: Filiere[] = [];
  annees: Anneeuv[] = [];
  notelicencetrois: Notedutun[] = [];
  cours = [
    {id:1, nom:'JOUR'},
    {id:2, nom:'SOIR'}
  ];
  user!: User;
  resultat: boolean = false;

  // Pagination et recherche
  filteredNotelicencetrois: Notedutun[] = [];
  pagedNotelicencetrois: Notedutun[] = [];
  searchText: string = '';
  currentPage: number = 1;
  itemsPerPage: number = 10;
  totalPages: number = 1;
  pages: number[] = [];
  firstItemOnPage: number = 0;
  lastItemOnPage: number = 0;

  readonly myFormGroup = new FormGroup({
    annee: new FormControl(""),
    cours: new FormControl(""),
    filiere: new FormControl(""),
  });

  constructor(
    private anneeuvService: AnneeuvService,
    private filiereService: FiliereService,
    private noteService: NoteService,
    private pdfService: AttestationPdfService,
    private authService: AuthService
  ) {}
generatePDF(etudiant: Etudiant, appreciation: string) {
    const formData = this.myFormGroup.value;
    const filiere = this.filieres.find(f => f.id === Number(formData.filiere));
    const annee = this.annees.find(a => a.id === Number(formData.annee));

    if (filiere && annee && this.user) {
      this.pdfService.generatePDF(etudiant, appreciation, this.user, filiere, annee);
    }
  }
  ngOnInit(): void {
    this.getAnneeuv();
    this.getFiliereParCycle();
    this.user = this.authService.getUserFromLocalStorage();
    this.initializePagination();
  }

  initializePagination(): void {
    this.filteredNotelicencetrois = [...this.notelicencetrois];
    this.setPage(1);
  }

  filterNotelicencetrois(): void {
    if (!this.searchText.trim()) {
      this.filteredNotelicencetrois = [...this.notelicencetrois];
    } else {
      const searchLower = this.searchText.toLowerCase();
      this.filteredNotelicencetrois = this.notelicencetrois.filter(notelicencetroi =>
        (notelicencetroi.etudiant?.nom?.toLowerCase().includes(searchLower)) ||
        (notelicencetroi.etudiant?.prenom?.toLowerCase().includes(searchLower)) ||
        (notelicencetroi.mention?.toLowerCase().includes(searchLower)) ||
        (notelicencetroi.appreciation?.toLowerCase().includes(searchLower))
      );
    }
    this.setPage(1);
  }

  setPage(page: number): void {
    if (page < 1 || page > this.totalPages) return;

    this.currentPage = page;
    this.totalPages = Math.ceil(this.filteredNotelicencetrois.length / this.itemsPerPage) || 1;

    this.firstItemOnPage = (this.currentPage - 1) * this.itemsPerPage + 1;
    this.lastItemOnPage = Math.min(this.currentPage * this.itemsPerPage, this.filteredNotelicencetrois.length);

    this.pagedNotelicencetrois = this.filteredNotelicencetrois.slice(
      this.firstItemOnPage - 1,
      this.lastItemOnPage
    );

    this.generatePageNumbers();
  }

  generatePageNumbers(): void {
    const maxPagesToShow = 5;
    this.pages = [];

    let startPage = Math.max(1, this.currentPage - Math.floor(maxPagesToShow / 2));
    let endPage = startPage + maxPagesToShow - 1;

    if (endPage > this.totalPages) {
      endPage = this.totalPages;
      startPage = Math.max(1, endPage - maxPagesToShow + 1);
    }

    for (let i = startPage; i <= endPage; i++) {
      this.pages.push(i);
    }
  }

  getFiliereParCycle(): void {
    this.filiereService.getFiliereParCycle(11).subscribe({
      next: (data: Filiere[]) => {
        this.filieres = data;
      }
    });
  }

  getAnneeuv(): void {
    this.anneeuvService.getAllAnnee().subscribe((data: Anneeuv[]) => {
      this.annees = data;
    });
  }

  RechercheControles(): void {
    const donnees = this.myFormGroup.value;
    this.donnee[0] = donnees.annee;
    this.donnee[1] = donnees.filiere;
    this.donnee[2] = donnees.cours;
    this.donnee[3] = 6;
    this.donnee[4] = 7;
    this.donnee[5] = this.user.administrateur.site.id;

    this.noteService.getControleDutUn(this.donnee).subscribe({
      next: (data) => {
        this.resultat = true;
        this.notelicencetrois = data;
        this.filteredNotelicencetrois = [...this.notelicencetrois];
        this.setPage(1);
      }
    });
  }

}
