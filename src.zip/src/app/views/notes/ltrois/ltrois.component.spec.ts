import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LtroisComponent } from './ltrois.component';

describe('LtroisComponent', () => {
  let component: LtroisComponent;
  let fixture: ComponentFixture<LtroisComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LtroisComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(LtroisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
