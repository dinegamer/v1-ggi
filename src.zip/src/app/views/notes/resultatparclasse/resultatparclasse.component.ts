import { Component, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { NgSelectModule } from '@ng-select/ng-select';
import { Semestre } from '../../../model/semestre.model';
import { SemestreService } from '../../../service/semestre.service';
import { Filiere } from '../../../model/filiere.model';
import { FiliereService } from '../../../service/filiere.service';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NoteService } from '../../../service/note.service';
import { User } from '../../../model/user.model';
import { AuthService } from '../../../service/auth.service';
import { TypeUEDTO } from '../../../dto/typeue.dto';
import { EtudiantDTO } from '../../../dto/etudiant.dto';
import { MatiereDTO } from '../../../dto/matiere.dto';
import { NoteDTO } from '../../../dto/note.dto';
import { Anneeuv } from '../../../model/anneeuv.model';
import { AnneeuvService } from '../../../service/anneeuv.service';
import $ from 'jquery';
import 'datatables.net';

@Component({
  selector: 'app-resultatparclasse',
  standalone: true,
  imports: [
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent, 
    ColComponent,
    RowComponent,
    RouterModule,
    NgSelectModule,
    ReactiveFormsModule,
    CommonModule
  ],
  templateUrl: './resultatparclasse.component.html',
  styleUrl: './resultatparclasse.component.scss'
})
export class ResultatparclasseComponent implements OnInit {
  user!: User
  cours = [
    {id:1, nom:'JOUR'},
    {id:2, nom:'SOIR'}
  ]
  semestres: Semestre[] = []
  filieres: Filiere[] = []
  resultat: boolean = false
  releve: TypeUEDTO[] = []
  listeEtudiants: EtudiantDTO[] = []
  annees: Anneeuv[] = []

  ngOnInit(): void {
    //this.getAllSite()
    this.getAllSemestre()
    this.getAllAnnee()
    this.getAllFiliere()
    this.user = this.authService.getUserFromLocalStorage()
  }

  constructor(
    private semestreService: SemestreService,
    private filiereService: FiliereService,
    private noteService: NoteService,
    private authService: AuthService,
    private anneeuvService: AnneeuvService
  ){}
 //total credit de l'etudiant
 getTotalCredits(etudiantId: number): number {
  let totalNoteCredit = 0;

   // Parcours du tableau de TypeUEDTO[]
   this.releve.forEach(typeUE => {
    typeUE.matieres.forEach(matiere => {
      matiere.notes.forEach(note => {
        if (note.etudiantId === etudiantId) {
          totalNoteCredit += note.noteCredit; // Ajoute noteCredit à la somme
        }
      });
    });
  });

  return totalNoteCredit;
}

  
  //form
  readonly myFormGroup = new FormGroup({    
    cours: new FormControl(""),
    filiere: new FormControl(""),
    semestre: new FormControl(""),
    annee: new FormControl("")
  });
  getAllAnnee(){
    this.anneeuvService.getAllAnnee().subscribe({
      next: (response) =>{
        this.annees = response
      }
    })
  }
  
  Rechercher(){
    this.resultat = true
    const donnees = this.myFormGroup.value
    const donnee = [
      donnees.cours,
      donnees.filiere,
      donnees.semestre,
      this.user.administrateur.site.id,
      donnees.annee
    ]
    this.noteService.getReleveParClasse(donnee).subscribe({
      next: (response) =>{
        //console.log(response+" recherche credit")
        this.releve = response 
        const allEtudiants = response.flatMap(typeUE => typeUE.etudiants)
        // Supprime les doublons en se basant sur l'id
        this.listeEtudiants = allEtudiants.filter(
          (etudiant, index, self) =>
            index === self.findIndex(e => e.id === etudiant.id)
        );
        //console.log(response+" 123")
        setTimeout(() => {
          let table = $('#donnees').DataTable();
          if ($.fn.DataTable.isDataTable("#donnees")) {
            table.destroy();  // Détruit l'ancienne instance
          }
          ($('#donnees') as any).DataTable({
            paging: true,
            searching: true,
            ordering: true,
            info: true,
            lengthMenu: [
                [10, 20, 50, -1], // Ajout de -1 pour "Tout"
                [10, 20, 50, "Tout"] // Labels correspondants
            ],
            pageLength: 10,        // Nombre de lignes par défaut
            language: {
              search: "🔍 Rechercher :",
              lengthMenu: "Afficher _MENU_ entrées",
              info: "Affichage de _START_ à _END_ sur _TOTAL_ entrées",
              paginate: {
                first: "⏪",
                last: "⏩",
                next: "▶",
                previous: "◀" 
              }}
          }); // Initialise DataTables après le rendu
        }, 100);
        
      },
      error: (error) =>{console.log("Erreur !!!")},
      complete: () =>{console.log("fin !!!")}
    });
  } 
  getNoteForStudent(matiere: MatiereDTO, etudiantId: number): NoteDTO | null {
    return matiere.notes.find(n => n.etudiantId === etudiantId) || null;
  }
  //moyenne de l'etudiant
  getValidationForStudent(etudiantId: number): string {
    let totalMoyenne = 0;
  
    for (let typeue of this.releve) {
      for (let matiere of typeue.matieres) {
        const note = this.getNoteForStudent(matiere, etudiantId);
        if (note) {
          totalMoyenne += note.moyenne;
        }
      }
    }
  
    return totalMoyenne < 5 ? 'NV' : 'V';
  }
  //moyenne general
  getMoyenneGenerale(etudiantId: number): number {
    let totalMoyenne = 0;
    let nombreMatieres = 0;
  
    for (let typeue of this.releve) {
      for (let matiere of typeue.matieres) {
        const note = this.getNoteForStudent(matiere, etudiantId);
        if (note) {
          totalMoyenne += note.moyenne;
          nombreMatieres++;
        }
      }
    }
  
    return nombreMatieres > 0 ? (totalMoyenne / nombreMatieres) : 0;
  }

  getAllSemestre(){
    this.semestreService.getAllSemestre().subscribe((res: any) =>{
      this.semestres = res
      //console.log(res+" mdt test !")
    })
  }
  
  getAllFiliere(){
    this.filiereService.getAllFilieres().subscribe(data => {
       this.filieres = data
    });
  }
}
