import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResultatparclasseComponent } from './resultatparclasse.component';

describe('ResultatparclasseComponent', () => {
  let component: ResultatparclasseComponent;
  let fixture: ComponentFixture<ResultatparclasseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ResultatparclasseComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ResultatparclasseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
