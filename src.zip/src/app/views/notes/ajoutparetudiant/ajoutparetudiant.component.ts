import { Component, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { NgSelectModule } from '@ng-select/ng-select';
import { Semestre } from '../../../model/semestre.model';
import { SemestreService } from '../../../service/semestre.service';
import { Filiere } from '../../../model/filiere.model';
import { FiliereService } from '../../../service/filiere.service';
import { Matieresup } from '../../../model/matieresup.model';
import { Etudiant } from '../../../model/etudiant.model';
import { EtudiantService } from '../../../service/etudiant.service';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { InscriptionService } from '../../../service/inscription.service';
import { CommonModule } from '@angular/common';
import { NoteService } from '../../../service/note.service';
import { MatieresupService } from '../../../service/matieresup.service';
import { User } from '../../../model/user.model';
import { AuthService } from '../../../service/auth.service';
import { Anneeuv } from '../../../model/anneeuv.model';
import { AnneeuvService } from '../../../service/anneeuv.service';

@Component({
  selector: 'app-ajoutparetudiant',
  standalone: true,
  imports: [
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent, 
    ColComponent,
    RowComponent,
    RouterModule,
    NgSelectModule,
    ReactiveFormsModule,
    CommonModule
  ],
  templateUrl: './ajoutparetudiant.component.html',
  styleUrl: './ajoutparetudiant.component.scss'
})
export class AjoutparetudiantComponent implements OnInit {
  user!: User
  cours = [
    {id:1, nom:'JOUR'},
    {id:2, nom:'SOIR'}
  ]
  semestres: Semestre[] = []
  filieres: Filiere[] = []
  matieres: Matieresup[] = []
  etudiants: Etudiant[] = []
  ajoutnote: boolean = false
  confirme: boolean = false
  confirmemsg: string = ""
  donnee: string[] = []
  annees: Anneeuv[] = []
  
  //form
   readonly myFormGroup = new FormGroup({
      annee: new FormControl(""),
      cours: new FormControl(""),
      filiere: new FormControl(""),
      semestre: new FormControl(""),
      etudiant: new FormControl(""),
      matiere: new FormControl(""),
      site: new FormControl("")
    });
  readonly FormulaireDAjout = new FormGroup({
    noteclasse: new FormControl(""),
    noteexamen: new FormControl("")
  });
  //constructeur
  constructor(
    private semestreService: SemestreService,
    private filiereService: FiliereService,
    private matieresupService: MatieresupService,
    private etudiantService: EtudiantService,
    private inscrireService: InscriptionService,
    private anneeuvService: AnneeuvService,
    private noteService: NoteService,
    private authService: AuthService
  ){}
  //initialement
  ngOnInit(): void {
    //this.getAllSite()
    this.getAllSemestre()
    this.getAllAnnee()
    this.getAllFiliere()
    this.user = this.authService.getUserFromLocalStorage()
  }
  Enregistre(){
    const informations = this.myFormGroup.value 
    const donnees = this.FormulaireDAjout.value 
    //construction des données
    const infos = [
      this.user.parametre.anneepardefaut.id,
      informations.etudiant,
      informations.filiere,
      informations.matiere,
      informations.semestre,
      donnees.noteclasse,
      donnees.noteexamen]
    //console.log(" mdt "+infos+" mdt ")
    this.noteService.saveNoteEtudiant(infos).subscribe({
      next: (response) =>{
        this.confirme = true
        this.confirmemsg = response.message
        this.ajoutnote = false
        }, 
      error:  (error) =>{
          this.confirme = true
          this.confirmemsg = "Erreur lors du traitement !."+error
          this.ajoutnote = false
        },
      complete: () => {console.log('complete !!')}
      })
  }
  AjoutNote(){
    const donnees = this.myFormGroup.value 
    this.donnee[0] = donnees.filiere || ''
    this.donnee[1] = donnees.annee || ''
    this.donnee[2] = donnees.etudiant || ''
    this.donnee[3] = donnees.matiere || ''
    this.donnee[4] = donnees.semestre || ''

    this.noteService.getverifiernotedunetudiant(this.donnee).subscribe({
      next: (response) => {
        if(response.status == "false"){
          this.ajoutnote = true
          this.confirme = false
          this.confirmemsg = response.message
        }else{
          this.confirme = true
          this.ajoutnote = false
          this.confirmemsg = "Une note existe déjà pour l'étudiant pour la même matière et pour l'année, Merci de procéder à la modification !!"
        }
        console.log(response.message)
      },
      error: (error) => {console.log("Erreur !!!") },
      complete: () => {console.log("complete !!!")}
    })
    
  }
  RechercheEtudiant(){
    const donnees = this.myFormGroup.value    
    let donnee = [
      donnees.annee,
      donnees.cours,
      donnees.filiere,
      this.user.administrateur.site.id
    ]
    if(donnees.cours == ""){
      alert("Choisir un cours ?")
      return
    }
    
    //console.log(" ** "+donnee+" ** ")
    this.inscrireService.getListeParClasse(donnee).subscribe(data =>{
      this.etudiants = data
    })
    this.RechercheMatiere()
  }
  RechercheMatiere(){
    const donnees = this.myFormGroup.value    
    let donnee = [donnees.semestre,donnees.filiere]
    if(donnees.semestre == ""){
      alert("Choisir le semestre ?")
      return
    }    
    //console.log(" ** "+donnee+" ** ")
    this.matieresupService.ListeMFS(donnee).subscribe((data: any) =>{
      this.matieres = data
    })
  }
  getAllAnnee(){
    this.anneeuvService.getAllAnnee().subscribe({
      next: (data) =>{
        this.annees = data
      }
    })
  }
  getAllSemestre(){
    this.semestreService.getAllSemestre().subscribe((res: any) =>{
      this.semestres = res
      //console.log(res+" mdt test !")
    })
  }
  
  getAllFiliere(){
    this.filiereService.getAllFilieres().subscribe(data => {
       this.filieres = data
    });
  }
  getAllMatiere(){
   this.matieresupService.getAllMatieresup().subscribe(data =>{
    this.matieres = data
   })
  }
  getAllEtudiant(){
    this.etudiantService.getEtudiants().subscribe(data =>{
          this.etudiants = data
    })
  }
}
