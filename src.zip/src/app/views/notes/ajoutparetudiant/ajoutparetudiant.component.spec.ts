import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AjoutparetudiantComponent } from './ajoutparetudiant.component';

describe('AjoutparetudiantComponent', () => {
  let component: AjoutparetudiantComponent;
  let fixture: ComponentFixture<AjoutparetudiantComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AjoutparetudiantComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AjoutparetudiantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
