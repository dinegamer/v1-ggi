import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { Anneeuv } from '../../../model/anneeuv.model';
import { Filiere } from '../../../model/filiere.model';
import { AnneeuvService } from '../../../service/anneeuv.service';
import { FiliereService } from '../../../service/filiere.service';
import { NgSelectModule } from '@ng-select/ng-select';
import { Notedutun } from '../../../donnees/notedutun';
import { NoteService } from '../../../service/note.service';
import { AuthService } from '../../../service/auth.service';
import { User } from '../../../model/user.model';
import { AttestationPdfService } from './../../../service/attestation-pdf.service';
import { Etudiant } from './../../../model/etudiant.model';


@Component({
  selector: 'app-dutun',
  standalone: true,
  imports: [
    CommonModule,
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent,
    ColComponent,
    RowComponent,
    ReactiveFormsModule,
    NgSelectModule,
    FormsModule
  ],
  templateUrl: './dutun.component.html',
  styleUrl: './dutun.component.scss'
})
export class DutunComponent implements OnInit{
  donnee: any[] = [];
  filieres: Filiere[] = [];
  annees: Anneeuv[] = [];
  notedutuns: Notedutun[] = [];
  cours = [
    {id:1, nom:'JOUR'},
    {id:2, nom:'SOIR'}
  ]
  resultat: boolean = false
  user!:User
  // Données originales et filtrées
  filteredData: any[] = [];
  // Pagination
  currentPage = 1;
  itemsPerPage = 10;
  itemsPerPageOptions = [10, 50, 100, -1]; // -1 pour "Tout"
  // Recherche
  searchTerm = '';
  isLoading: boolean = false;
  sortColumn: string = '';
  sortDirection: 'asc' | 'desc' = 'asc';

  readonly myFormGroup = new FormGroup({
    annee: new FormControl(""),
    cours: new FormControl(""),
    filiere: new FormControl(""),
    site: new FormControl("")
  });

  constructor(
    private anneeuvService: AnneeuvService,
    private filiereService: FiliereService,
    private noteService: NoteService,
    private pdfService: AttestationPdfService,
    private authService: AuthService
  ){}

  generatePDF(etudiant: Etudiant, appreciation: string) {
    const formData = this.myFormGroup.value;
    const filiere = this.filieres.find(f => f.id === Number(formData.filiere));
    const annee = this.annees.find(a => a.id === Number(formData.annee));

    if (filiere && annee && this.user) {
      this.pdfService.generatePDF(etudiant, appreciation, this.user, filiere, annee);
    }
  }


  ngOnInit(): void {
    this.getAnneeuv()
    this.getFiliereParCycle()
    this.user = this.authService.getUserFromLocalStorage()
    this.filterData();
  }
  // Filtrage des données
  filterData() {
    this.filteredData = this.notedutuns.filter(etudiant =>
      etudiant.etudiant.nom.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      etudiant.etudiant.prenom.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
    this.currentPage = 1; // Réinitialiser à la première page après filtrage
  }

  // Pagination
  get paginatedData() {
    // Si "Tout afficher" est sélectionné (-1)
    if (this.itemsPerPage === -1) {
      return this.filteredData; // Retourne toutes les données sans pagination
    }
    // Pagination normale
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    return this.filteredData.slice(startIndex, startIndex + this.itemsPerPage);
  }

  get totalPages() {
    return this.itemsPerPage === -1
      ? 1
      : Math.ceil(this.filteredData.length / this.itemsPerPage);
  }

  changePage(page: number) {
    this.currentPage = page;
  }

  changeItemsPerPage(value: number) {
    this.itemsPerPage = value;
    this.currentPage = 1;
  }

  getFiliereParCycle(){
    this.filiereService.getFiliereParCycle(4).subscribe((data: any) =>{
      this.filieres = data
    })
  }

  getAnneeuv(){
    this.anneeuvService.getAllAnnee().subscribe(data =>{
      this.annees = data
    })
  }
  RechercheControles(){
    this.isLoading = true; // Active le chargement
    const donnees = this.myFormGroup.value
    this.donnee[0] = donnees.annee
    this.donnee[1] = donnees.filiere
    this.donnee[2] = donnees.cours
    this.donnee[3] = 1
    this.donnee[4] = 2
    this.donnee[5] = this.user.administrateur.site.id
    this.noteService.getControleDutUn(this.donnee).subscribe({
      next: (data: any) => {
        this.resultat = true;
        this.notedutuns = data;
        this.filteredData = [...this.notedutuns];

      },
      error: (err) => {
        console.error('Erreur lors de la recherche:', err);
      },
      complete: () => {
      this.isLoading = false; // Désactive le chargement
    }
    })
  }
  // Méthode de tri
  sortData(column: string) {
    if (this.sortColumn === column) {
      // Inverse le sens si on clique sur la même colonne
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      // Nouvelle colonne, tri ascendant par défaut
      this.sortColumn = column;
      this.sortDirection = 'asc';
    }

    this.filteredData.sort((a, b) => {
      let valueA, valueB;

      // Sélection des valeurs à comparer selon la colonne
      switch (column) {
        case 'nom':
          valueA = a.etudiant.nom.toLowerCase();
          valueB = b.etudiant.nom.toLowerCase();
          break;
        case 'prenom':
          valueA = a.etudiant.prenom.toLowerCase();
          valueB = b.etudiant.prenom.toLowerCase();
          break;
        case 'mgsun':
          valueA = +a.mgsun; // Le + convertit en nombre
          valueB = +b.mgsun;
          break;
        case 'mgsdeux':
          valueA = +a.mgsdeux;
          valueB = +b.mgsdeux;
          break;
        case 'mannuel':
          valueA = +a.mannuel;
          valueB = +b.mannuel;
          break;
        case 'mention':
          valueA = a.mention;
          valueB = b.mention;
          break;
        case 'credit':
          valueA = +a.credit;
          valueB = +b.credit;
          break;
        case 'appreciation':
          valueA = a.appreciation;
          valueB = b.appreciation;
          break;
        default:
          return 0;
      }

      // Comparaison
      if (valueA < valueB) {
        return this.sortDirection === 'asc' ? -1 : 1;
      }
      if (valueA > valueB) {
        return this.sortDirection === 'asc' ? 1 : -1;
      }
      return 0;
    });

    this.currentPage = 1; // Retour à la première page après tri
  }

  // Méthode pour obtenir l'icône de tri
  getSortIcon(column: string): string {
    if (this.sortColumn !== column) return 'bi bi-arrow-down-up'; // Icône neutre
    return this.sortDirection === 'asc'
      ? 'bi bi-sort-down'
      : 'bi bi-sort-up';
  }
}
