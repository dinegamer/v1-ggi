import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DutunComponent } from './dutun.component';

describe('DutunComponent', () => {
  let component: DutunComponent;
  let fixture: ComponentFixture<DutunComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DutunComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DutunComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
