import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { Anneeuv } from '../../../model/anneeuv.model';
import { Filiere } from '../../../model/filiere.model';
import { User } from '../../../model/user.model';
import { AnneeuvService } from '../../../service/anneeuv.service';
import { FiliereService } from '../../../service/filiere.service';
import { AuthService } from '../../../service/auth.service';
import { NgSelectModule } from '@ng-select/ng-select';
import { Notedutun } from '../../../donnees/notedutun';
import { NoteService } from '../../../service/note.service';
import { AttestationPdfService } from './../../../service/attestation-pdf.service';
import { Etudiant } from './../../../model/etudiant.model';
import { Cycle } from './../../../model/cycle.model';


@Component({
  selector: 'app-lun',
  standalone: true,
  imports: [
    CommonModule,
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent,
    ColComponent,
    RowComponent,
    ReactiveFormsModule,
    NgSelectModule,
    FormsModule
  ],
  templateUrl: './lun.component.html',
  styleUrl: './lun.component.scss'
})
export class LunComponent implements OnInit{

  donnee: any[] = [];
  filieres: Filiere[] = [];
  annees: Anneeuv[] = [];
  cycles: Cycle[] = [];
  notelicenceuns: Notedutun[] = [];
  filteredData: any[] = []; // Données filtrées
  searchText: string = '';
  currentPage: number = 1;
  itemsPerPage: number = 10;
  totalItems: number = 0;

  cours = [
    {id:1, nom:'JOUR'},
    {id:2, nom:'SOIR'}
  ]
  user!: User
  resultat: boolean = false
  isLoading: boolean = false;

  readonly myFormGroup = new FormGroup({
    annee: new FormControl(""),
    cours: new FormControl(""),
    filiere: new FormControl(""),
  });

  constructor(
    private anneeuvService: AnneeuvService,
    private filiereService: FiliereService,
    private noteService: NoteService,
    private pdfService: AttestationPdfService,
    private authService: AuthService
  ){}
  generatePDF(etudiant: Etudiant, appreciation: string) {
    const formData = this.myFormGroup.value;
    const filiere = this.filieres.find(f => f.id === Number(formData.filiere));
    const annee = this.annees.find(a => a.id === Number(formData.annee));


    if (filiere && annee && this.user) {
      this.pdfService.generatePDF(etudiant, appreciation, this.user, filiere, annee);
    }
  }
  ngOnInit(): void {
    this.getAnneeuv()
    this.getFiliereParCycle()
    this.user = this.authService.getUserFromLocalStorage()
    this.filteredData = [...this.notelicenceuns];
    this.totalItems = this.filteredData.length;
  }


  getFiliereParCycle(){
    this.filiereService.getFiliereParCycle(6).subscribe((data: any) =>{
      this.filieres = data
    })
  }

  getAnneeuv(){
    this.anneeuvService.getAllAnnee().subscribe(data =>{
      this.annees = data
    })
  }
  RechercheControles(){
    this.isLoading = true;
    this.resultat = false;

    const donnees = this.myFormGroup.value
    this.donnee[0] = donnees.annee
    this.donnee[1] = donnees.filiere
    this.donnee[2] = donnees.cours
    this.donnee[3] = 1
    this.donnee[4] = 2
    this.donnee[5] = this.user.administrateur.site.id
    this.noteService.getControleDutUn(this.donnee).subscribe({
      next:(data: any) =>{
        this.resultat = true
        this.notelicenceuns = data
        this.filteredData = [...data]; // Initialise les données filtrées
      },
      error:(err) => {
        console.error('Erreur lors de la récupération des notes:', err);
        this.resultat = false;
      },
      complete:() => {
        this.isLoading = false;
        console.log('Récupération des notes terminée');
      }
    })

  }
  nextPage() {
    if (this.currentPage < this.getTotalPages()) {
      this.currentPage++;
    }
  }
  getTotalPages(): number {
    return Math.ceil(this.filteredData.length / this.itemsPerPage);
  }
  goToPage(page: number) {
    this.currentPage = page;
  }
  getPages(): number[] {
    const totalPages = this.getTotalPages();
    return Array.from({length: totalPages}, (_, i) => i + 1);
  }
  previousPage() {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }
  changeItemsPerPage(number: number) {
    this.itemsPerPage = number;
    this.currentPage = 1;
  }
  applyFilter() {
    if (!this.searchText) {
      this.filteredData = [...this.notelicenceuns];
    } else {
      const searchLower = this.searchText.toLowerCase();
      this.filteredData = this.notelicenceuns.filter(notedutdeux =>
        notedutdeux.etudiant.nom.toLowerCase().includes(searchLower) ||
        notedutdeux.etudiant.prenom.toLowerCase().includes(searchLower) ||
        notedutdeux.mention.toLowerCase().includes(searchLower)
      );
    }
    this.currentPage = 1;
    this.totalItems = this.filteredData.length;
  }
}
