import { Component, OnInit } from '@angular/core';
import { Anneeuv } from '../../model/anneeuv.model';
import { Semestre } from '../../model/semestre.model';
import { Filiere } from '../../model/filiere.model';
import { Matieresup } from '../../model/matieresup.model';
import { NgSelectModule } from '@ng-select/ng-select';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { NoteService } from '../../service/note.service';
import { AnneeuvService } from '../../service/anneeuv.service';
import { FiliereService } from '../../service/filiere.service';
import { SemestreService } from '../../service/semestre.service';
import { User } from '../../model/user.model';
import { AuthService } from '../../service/auth.service';
import { MatieresupService } from '../../service/matieresup.service';
import { NoteModel } from '../../model/note.model';
import $ from 'jquery';
import 'datatables.net';

@Component({
  selector: 'app-notes',
  standalone: true,
  imports: [
    NgSelectModule,
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent, 
    ColComponent,
    RowComponent,
    CommonModule,
    RouterModule,
    ReactiveFormsModule
  ],
  templateUrl: './notes.component.html',
  styleUrl: './notes.component.scss'
})
export class NotesComponent implements OnInit {
  user!: User
  annees: Anneeuv[] = []
  donnee: any[] = []
  roleActuel!: string
  cours = [
    {id:1, nom:'JOUR'},
    {id:2, nom:'SOIR'}
  ]
  semestres: Semestre[] = []
  filieres: Filiere[] = []
  matieres: Matieresup[] = []
  controles: NoteModel[] = []
  resultat: boolean = false
  isLoading = false; // Variable pour le loader
  isLoadingMatieres = false; // Variable pour afficher le loader

  ngOnInit(): void {
    this.getFilieres()
    this.getSemestres()
    this.user = this.authService.getUserFromLocalStorage();   
    this.getAllAnnee()
    this.roleActuel = this.user.administrateur.role.nom
  }

  constructor(
    private noteService: NoteService,
    private anneeuvService: AnneeuvService,
    private filiereService: FiliereService,
    private semestreService: SemestreService,
    private authService: AuthService,
    private matieresupService: MatieresupService
  ){}

  readonly myFormGroup = new FormGroup({
    annee: new FormControl(""),
    cours: new FormControl(""),
    filiere: new FormControl(""),
    semestre: new FormControl(""),
    matiere: new FormControl(""),
    site: new FormControl(""),    
  });
  getAllAnnee(){
    this.anneeuvService.getAllAnnee().subscribe(data =>{
      this.annees = data 
    })
  }
  getFilieres(){
    this.filiereService.getAllFilieres().subscribe(data =>{
      this.filieres = data
    })
  }
  getSemestres(){
    this.semestreService.getAllSemestre().subscribe(data =>{
      this.semestres = data
    })
  }
  RechercheMatiere(){
    // Vider la liste avant le nouveau chargement
    this.matieres = []; 
    this.isLoadingMatieres = true; // Afficher le loader

    const donnees = this.myFormGroup.value
    this.donnee[0] = donnees.semestre
    this.donnee[1] = donnees.filiere
    this.matieresupService.ListeMFS(this.donnee).subscribe({
      next: (data: any) =>{
        this.matieres = data      
        this.isLoadingMatieres = false; 
      },
      error: (error) =>{
        console.log("Erreur !!"+error)
      }
    }) 
  }
  onSubmit(){
    this.controles = []
    this.donnee = []
    this.Rechercher()
  }
  Rechercher() {
    const donnees = this.myFormGroup.value;
    this.donnee = [
        donnees.annee,
        donnees.filiere,
        donnees.cours,
        donnees.semestre,
        donnees.matiere,
        this.user.administrateur.site.id
    ];
    this.noteService.getNotes(this.donnee).subscribe({
      next: (data) => {
        this.controles = data;
        this.resultat = true; 
        this.InitialiserTableau()               
      },
      error: (error) => {
        console.error("Erreur lors du chargement des notes :", error);
        this.isLoading = false; // Désactiver le loader en cas d'erreur
      }
    });
  } 
  InitialiserTableau(){
    // Détruire l'instance de DataTable avant le chargement
    if ($.fn.DataTable.isDataTable("#donnees")) {
      $('#donnees').DataTable().destroy();
    }
    setTimeout(() => {     
      ($('#donnees') as any).DataTable({
        paging: true,
        searching: true,
        ordering: true,
        info: true,
        lengthMenu: [
            [10, 20, 50, -1], 
            [10, 20, 50, "Tout"] 
        ],
        pageLength: 10, 
        language: {
          search: "🔍 Rechercher :",
          lengthMenu: "Afficher _MENU_ entrées",
          info: "Affichage de _START_ à _END_ sur _TOTAL_ entrées",
          paginate: {
            first: "⏪",
            last: "⏩",
            next: "▶",
            previous: "◀"
          }
        },
        responsive: true 
      });
    }, 100);
  }
  Supprimer(controleId: string){
    if (confirm('Voulez-vous vraiment supprimer la note ?')) {
      this.noteService.deleteControleById(controleId).subscribe({
        next: (response) => {
          alert('note supprimé avec succès !'+response);
          this.Rechercher()
        },
        error: (error) =>{console.log("Erreur !!!"+error)}
      });
    }
  }
  SupprimerEnsemble(){
    if (confirm("Voulez-vous vraiment supprimer l'ensemble des notes ?")) {
      this.noteService.deleteAllControles(this.donnee).subscribe({
        next: (response) => {
          alert(response.message);
          this.Rechercher();  // Rechercher les nouvelles données après suppression
        },
        error: (error) => {
          console.log('Erreur lors de la suppression des notes'+error);
        }
      });
    }
  }

}
