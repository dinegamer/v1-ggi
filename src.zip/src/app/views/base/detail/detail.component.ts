import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { EtudiantService } from '../../../service/etudiant.service';
import { Etudiant } from '../../../model/etudiant.model';
@Component({
  selector: 'app-detail',
  standalone: true,
  imports: [
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent,
    ColComponent,
    RowComponent,
  ],
  templateUrl: './detail.component.html',
  styleUrl: './detail.component.scss'
})
export class DetailComponent implements OnInit{
  etudiantId!: number
  etudiant!: Etudiant

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private etudiantService: EtudiantService
  ){}

  ngOnInit(): void {
    // ✅ Récupérer l'ID de l'URL
    this.etudiantId = Number(this.route.snapshot.paramMap.get('id'));
    console.log('ID récupéré :', this.etudiantId);
    // ✅ Vérifier si l'ID est valide
    this.etudiantService.getEtudiantById(this.etudiantId).subscribe(
      data => {
        this.etudiant = data;
      },
      error => {
        console.error('Étudiant introuvable');
        this.router.navigate(['/']); // 🔄 Rediriger si l’ID est invalide
      }
    );
  }

}
