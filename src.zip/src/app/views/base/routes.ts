import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    data: {
      title: 'Gestion Pédagogie'
    },
    children: [
      {
        path: '',
        redirectTo: 'cards',
        pathMatch: 'full'
      },
      {
        path: 'liste',
        loadComponent: () => import('./liste/liste.component').then(m => m.ListeComponent),
        data: {
          title: 'Liste Par Classe'
        }
      },
      {
        path: 'detail/:id',
        loadComponent: () => import('./detail/detail.component').then(m => m.DetailComponent),
        data: {
          title: 'Detail Etudiant'
        }
      },
      {
        path: 'carte',
        loadComponent: () => import('./carte/carte.component').then(m => m.CarteComponent),
        data: {
          title: 'Cartes Etudiant'
        }
      },
      {
        path: 'attestationtinscription',
        loadComponent: () => import('./attestationtinscription/attestationtinscription.component').then(m => m.AttestationtinscriptionComponent),
        data: {
          title: 'Attestation Inscription'
        }
      },
      
      {
        path: 'reinscription',
        loadComponent: () => import('./reinscription/reinscription.component').then(m => m.ReinscriptionComponent),
        data: {
          title: 'Reinscription'
        }
      },
      {
        path: 'transfereEntreClasse',
        loadComponent: () => import('./transfere-entre-classe/transfere-entre-classe.component').then(m => m.TransfereEntreClasseComponent),
        data: {
          title: 'Transfere entre classe'
        }
      }/*,
      {
        path: 'compte-etudiant',
        loadComponent: () => import('./compte-etudiant/compte-etudiant.component').then(m => m.CompteEtudiantComponent),
        data: {
          title: 'Compte Etudiant'
        }
      }*/,
      {
        path: 'transfereEntreSite',
        loadComponent: () => import('./transfere-entre-site/transfere-entre-site.component').then(m => m.TransfereEntreSiteComponent),
        data: {
          title: 'Transfere Entre SIte'
        }
      },
      {
        path: 'professeurs',
        loadComponent: () => import('./professeurs/professeurs.component').then(m => m.ProfesseursComponent),
        data: {
          title: 'Professeurs'
        }
      },
      {
        path: 'salles',
        loadComponent: () => import('./salles/salles.component').then(m => m.SallesComponent),
        data: {
          title: 'Salles'
        }
      },{
        path: 'groupes',
        loadComponent: () => import('./groupes/groupes.component').then(m => m.GroupesComponent),
        data:{
          title: 'Groupes'
        }
      },
      {
        path: 'emargements',
        loadComponent: () => import('./emargements/emargements.component').then(m => m.EmargementsComponent),
        data: {
          title: 'Emargements'
        }
      },
      {
        path: 'progressions',
        loadComponent: () => import('./progressions/progressions.component').then(m => m.ProgressionsComponent),
        data: {
          title: 'Progressions'
        }
      },
      {
        path: 'tooltips',
        loadComponent: () => import('./tooltips/tooltips.component').then(m => m.TooltipsComponent),
        data: {
          title: 'Tooltips'
        }
      }
    ]
  }
];


