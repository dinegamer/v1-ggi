import { Component, OnInit } from '@angular/core';
import { ButtonDirective, CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, FormControlDirective, FormDirective, FormLabelDirective, FormModule, RowComponent, TextColorDirective } from '@coreui/angular';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NgSelectModule } from '@ng-select/ng-select';
import { User } from '../../../model/user.model';
import { InscriptionService } from '../../../service/inscription.service';
import { Etudiant } from '../../../model/etudiant.model';
import { Filiere } from '../../../model/filiere.model';
import { FiliereService } from '../../../service/filiere.service';
import { AuthService } from '../../../service/auth.service';
import { Anneeuv } from '../../../model/anneeuv.model';
import { AnneeuvService } from '../../../service/anneeuv.service';
@Component({
  selector: 'app-attestationtinscription',
  standalone: true,
  imports: [
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent,
    ColComponent,
    RowComponent,
    TextColorDirective, 
    CardComponent, 
    CardHeaderComponent, 
    CardBodyComponent, 
    ReactiveFormsModule, 
    FormsModule, 
    FormDirective,  
    CommonModule,
    ReactiveFormsModule,
    NgSelectModule
  ],
  templateUrl: './attestationtinscription.component.html',
  styleUrl: './attestationtinscription.component.scss'
})
export class AttestationtinscriptionComponent {

  filieres: Filiere[] = [];
  cours = [
     {id:1, nom:'JOUR'},
     {id:2, nom:'SOIR'}
  ]
  user!: User;
  datevalidite!: string;
  site!: string;
  filiere!: Filiere;
  etudiants: Etudiant[] = []
  annees: Anneeuv[] = []
  attestation: boolean = false
  etudiant: Etudiant | undefined | null
  annee: Anneeuv | undefined | null

  ngOnInit(): void {
    this.getAllFiliere();
    this.getAllAnnee();
    this.user = this.authService.getUserFromLocalStorage();
    //trouver la date de validite
    const dateActuelle = new Date(); // Date actuelle
    const dansUnAn = new Date(dateActuelle); // Copie de la date actuelle
    dansUnAn.setFullYear(dateActuelle.getFullYear() + 1); // Ajouter 1 an

    // Options pour le format en français
    const options: Intl.DateTimeFormatOptions = {
      //weekday: "long", // Jour complet (ex. dimanche)
      year: "numeric", // Année (ex. 2026)
      month: "long",   // Mois complet (ex. janvier)
      day: "numeric",  // Jour du mois (ex. 18)
    };
    this.datevalidite = dansUnAn.toLocaleDateString("fr-FR", options);
  }

  constructor(
  private inscriptionService: InscriptionService, 
  private filiereService: FiliereService,
  private authService: AuthService,
  private anneeService: AnneeuvService
  ){}

  readonly mesRecherches = new FormGroup({   
    cours: new FormControl(""),
    filiere: new FormControl(""),
    annee: new FormControl(""),
    etudiant: new FormControl("")
  });

  getAllFiliere(){
    this.filiereService.getAllFilieres().subscribe(data =>{
      this.filieres = data
    })
  }
 getAllAnnee(){
  this.anneeService.getAllAnnee().subscribe({
    next: (data) => {this.annees = data}
  })
 }
  RechercheEtudiant(event: any){
    //recupere la filier choisi
    this.filiere = event
    //recu
    const donnees = this.mesRecherches.value
    let donnee = [
      donnees.annee,
      donnees.cours,
      donnees.filiere,
      this.user.administrateur.site.id
    ]
    this.site = this.user.administrateur.site.nom
   
    this.inscriptionService.getListeParClasse(donnee).subscribe(data =>{
      this.etudiants = data
    })
   
  }
  AttestationInscription(){
    const donnees = this.mesRecherches.value
    this.etudiant = this.etudiants.find(etu => etu.id === Number(donnees.etudiant))
    this.annee = this.annees.find(an => an.id === Number(donnees.annee))
    this.attestation = true
  }
  printCardBody() {
    const printContents = document.querySelector('.c-card-body')?.innerHTML;
    const originalContents = document.body.innerHTML;

    if (printContents) {
      // Remplace le contenu du body par ce que vous voulez imprimer
      document.body.innerHTML = printContents;
      window.print();
      // Réinitialise le contenu original
      document.body.innerHTML = originalContents;
      location.reload(); // Recharge la page pour réinitialiser les comportements Angular
    } else {
      console.error('Élément avec la classe .c-card-body introuvable');
    }
  }
}
