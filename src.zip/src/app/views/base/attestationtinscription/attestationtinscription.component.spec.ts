import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AttestationtinscriptionComponent } from './attestationtinscription.component';

describe('AttestationtinscriptionComponent', () => {
  let component: AttestationtinscriptionComponent;
  let fixture: ComponentFixture<AttestationtinscriptionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AttestationtinscriptionComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AttestationtinscriptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
