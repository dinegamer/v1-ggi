import { Component, OnInit } from '@angular/core';
import { ButtonDirective, CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, FormControlDirective, FormDirective, FormLabelDirective, FormModule, RowComponent, TextColorDirective } from '@coreui/angular';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NgSelectModule } from '@ng-select/ng-select';
import { User } from '../../../model/user.model';
import { InscriptionService } from '../../../service/inscription.service';
import { Etudiant } from '../../../model/etudiant.model';
import { Filiere } from '../../../model/filiere.model';
import { FiliereService } from '../../../service/filiere.service';
import { AuthService } from '../../../service/auth.service';
import { RouterModule } from '@angular/router';
import { Anneeuv } from '../../../model/anneeuv.model';
import { AnneeuvService } from '../../../service/anneeuv.service';

@Component({
  selector: 'app-liste',
  standalone: true,
  imports: [
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent,
    ColComponent,
    RowComponent,
    ButtonDirective,
    RowComponent, 
    ColComponent, 
    TextColorDirective,    
    ReactiveFormsModule, 
    FormsModule, 
    FormDirective,  
    ButtonDirective, 
    CommonModule,
    ReactiveFormsModule,
    NgSelectModule,
    RouterModule
  ],
  templateUrl: './liste.component.html',
  styleUrl: './liste.component.scss'
})
export class ListeComponent implements OnInit{
  
  inscrires: Etudiant[] = [];
  filieres: Filiere[] = [];
  annees: Anneeuv[] = [];
  cours = [
     {id:1, nom:'JOUR'},
     {id:2, nom:'SOIR'}
  ]
  user!: User;
  resultat: boolean = false

  ngOnInit(): void {
    this.getAllFiliere();
    this.getAllAnnee();
    this.user = this.authService.getUserFromLocalStorage();
  }

  constructor(
  private inscriptionService: InscriptionService, 
  private filiereService: FiliereService,
  private authService: AuthService,
  private anneeuvService: AnneeuvService
  ){}

  readonly mesRecherches = new FormGroup({   
    cours: new FormControl(""),
    filiere: new FormControl(""),
    annee: new FormControl("")
  });

  getAllAnnee(){
    this.anneeuvService.getAllAnnee().subscribe({
      next: (data) => {
        this.annees = data
      },
      error: (error) => {
        console.log("Erreur de connexion a la base de donnée"+error)
      }
    })
  }

  getAllFiliere(){
    this.filiereService.getAllFilieres().subscribe(data =>{
      this.filieres = data
    })
  }

  RechercheEtudiant(){
    const donnees = this.mesRecherches.value
    let donnee = [
      donnees.annee,
      donnees.cours,
      donnees.filiere,
      this.user.administrateur.site.id
    ]
    
    this.inscriptionService.getListeParClasse(donnee).subscribe(data =>{
      this.inscrires = data
      this.resultat = true
    })
    //console.log(this.inscrires+" mft ++")
  }
  lienDetail(id: number): string{
    return `/base/detail/${id}`;
  }

}
