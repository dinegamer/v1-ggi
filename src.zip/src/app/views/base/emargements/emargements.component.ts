import { Component } from '@angular/core';

@Component({
  selector: 'app-emargements',
  standalone: true,
  imports: [],
  templateUrl: './emargements.component.html',
  styleUrl: './emargements.component.scss'
})
export class EmargementsComponent {

}
