import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { Filiere } from '../../../model/filiere.model';
import { NgSelectModule } from '@ng-select/ng-select';
import { Etudiant } from '../../../model/etudiant.model';
import { FiliereService } from '../../../service/filiere.service';
import { User } from '../../../model/user.model';
import { InscriptionService } from '../../../service/inscription.service';
import { AuthService } from '../../../service/auth.service';
import { EtudiantService } from '../../../service/etudiant.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-transfere-entre-classe',
  standalone: true,
  imports: [
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent,
    ColComponent,
    RowComponent,
    ReactiveFormsModule,
    NgSelectModule,
    CommonModule
  ],
  templateUrl: './transfere-entre-classe.component.html',
  styleUrl: './transfere-entre-classe.component.scss'
})
export class TransfereEntreClasseComponent implements OnInit {
  
  ngOnInit(): void {
    this.getAllFiliere()
    this.user = this.authService.getUserFromLocalStorage();
  }

  constructor(
    private filiereService: FiliereService,
    private inscrireService: InscriptionService,
    private etudiantService: EtudiantService,
    private authService: AuthService
  ){}

  cours = [
    {id:1, nom:'JOUR'},
    {id:2, nom:'SOIR'}
  ]

  filieres: Filiere[] = []
  etudiants: Etudiant[] = []
  donnee: any[] = [];
  user!: User;
  etudiantDetails: any;

  readonly myFormGroup = new FormGroup({
    annee: new FormControl(""),
    cours: new FormControl(""),
    filiere: new FormControl(""),
    semestre: new FormControl(""),
    etudiant: new FormControl(""),
  });
  readonly leTransfere =  new FormGroup({
    cours: new FormControl(""),
    filiere: new FormControl(""),
  })

  AfficherEtudiants(){
    const donnees = this.myFormGroup.value
    this.donnee[0] = this.user.parametre.anneepardefaut.id
    this.donnee[1] = donnees.cours
    this.donnee[2] = donnees.filiere
    this.donnee[3] = this.user.administrateur.site.id
    //console.log("test test *- ***")
    this.inscrireService.getListeParClasse(this.donnee).subscribe((data: any) =>{
      this.etudiants = data
      //console.log(data+"test test *- ***")
    })
  }
  AfficherDetail(){
    const donnees = this.myFormGroup.value
    const etudiantId = donnees.etudiant;
    const an = this.user.parametre.anneepardefaut.id
    this.etudiantService.getEtudiantDetails(etudiantId, an).subscribe(data => {
      this.etudiantDetails = data;
    });
  }
  Transfere(){
    const donneess = this.myFormGroup.value
    const donnees = this.leTransfere.value
    this.donnee[0] = donnees.cours
    this.donnee[1] = donnees.filiere
    this.donnee[2] = this.user.parametre.anneepardefaut.id
    this.donnee[3] = this.user.administrateur.site.id
    this.donnee[4] = donneess.etudiant
    
    this.etudiantService.TransfereEtudiantEntreClasse(this.donnee).subscribe(response =>{
      console.log("mdt ++ "+response)
    })
  }

  getAllFiliere(){
    this.filiereService.getAllFilieres().subscribe(data => {
      this.filieres = data
    });
  }
  
  

}
