import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TransfereEntreClasseComponent } from './transfere-entre-classe.component';

describe('TransfereEntreClasseComponent', () => {
  let component: TransfereEntreClasseComponent;
  let fixture: ComponentFixture<TransfereEntreClasseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TransfereEntreClasseComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(TransfereEntreClasseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
