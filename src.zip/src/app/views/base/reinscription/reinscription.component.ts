import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ButtonDirective, CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, FormDirective, RowComponent, TextColorDirective } from '@coreui/angular';
import { NgSelectModule } from '@ng-select/ng-select';
import { InscriptionService } from '../../../service/inscription.service';
import { FiliereService } from '../../../service/filiere.service';
import { AuthService } from '../../../service/auth.service';
import { User } from '../../../model/user.model';
import { Etudiant } from '../../../model/etudiant.model';
import { Filiere } from '../../../model/filiere.model';
import { Anneeuv } from '../../../model/anneeuv.model';
import { AnneeuvService } from '../../../service/anneeuv.service';
import { Inscrire } from 'src/app/model/inscription.model';
@Component({
  selector: 'app-reinscription',
  standalone: true,
  imports: [
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent,
    ColComponent,
    RowComponent,
    ButtonDirective,
    RowComponent,     
    TextColorDirective, 
    ReactiveFormsModule, 
    FormsModule, 
    FormDirective,  
    CommonModule,
    NgSelectModule,
    RouterModule
  ],
  templateUrl: './reinscription.component.html',
  styleUrl: './reinscription.component.scss'
})
export class ReinscriptionComponent implements OnInit { 

  inscrires: Etudiant[] = [];
  filieres: Filiere[] = [];
  annees: Anneeuv[] = [];
  cours = [
     {id:1, nom:'JOUR'},
     {id:2, nom:'SOIR'}
  ]
  user!: User;
  resultat: boolean = false

  ngOnInit(): void {
    this.getAllFiliere()
    this.getAnnee()
    this.user = this.authService.getUserFromLocalStorage()
  }

  constructor(
  private inscriptionService: InscriptionService, 
  private filiereService: FiliereService,
  private anneeuvService: AnneeuvService,
  private authService: AuthService
  ){}

  readonly mesRecherches = new FormGroup({   
    cours: new FormControl(""),
    filiere: new FormControl("")
  });

  getAllFiliere(){
    this.filiereService.getAllFilieres().subscribe(data =>{
      this.filieres = data
    })
  }
  getAnnee(){
    this.anneeuvService.getAllAnnee().subscribe({
      next: (response) =>{ this.annees = response}
    })
  }

  RechercheEtudiant(){
    const donnees = this.mesRecherches.value
    let donnee = [
      this.user.parametre.anneepardefaut.id,
      donnees.cours,
      donnees.filiere,
      this.user.administrateur.site.id
    ]
    
    this.inscriptionService.getListeParClasse(donnee).subscribe(data =>{
      this.inscrires = data
      this.resultat = true
    })
    //console.log(this.inscrires+" mft ++")
  }
  Reinscription(index: number){    

    let donnee = [
      this.user.administrateur.site.id,
      (document.getElementById(`cours-${index}`) as HTMLSelectElement).value, 
      (document.getElementById(`filiere-${index}`) as HTMLSelectElement).value,  
      (document.getElementById(`annee-${index}`) as HTMLSelectElement).value,
      (document.getElementById(`etudiant-${index}`) as HTMLSelectElement).value,
      new Date().toISOString().split('T')[0], // Date actuelle
      new Date().toISOString().split('T')[1].split('.')[0], // Heure actuelle
      (document.getElementById(`observation-${index}`) as HTMLSelectElement).value
    ]
  
    this.inscriptionService.inscrireEtudiant(donnee).subscribe({
      next: (response) => { 
        //console.log(response+" mdt ") 
        alert("Réinscription effectue avec succes, Merci !")
      },
      error: (err) => {console.log("Erreur serve")}
    })
    //alert("test++")
  }
  

}
