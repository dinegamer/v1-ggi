import { Component } from '@angular/core';

@Component({
  selector: 'app-progressions',
  standalone: true,
  imports: [],
  templateUrl: './progressions.component.html',
  styleUrl: './progressions.component.scss'
})
export class ProgressionsComponent {

}
