import { Component } from '@angular/core';

@Component({
  selector: 'app-salles',
  standalone: true,
  imports: [],
  templateUrl: './salles.component.html',
  styleUrl: './salles.component.scss'
})
export class SallesComponent {

}
