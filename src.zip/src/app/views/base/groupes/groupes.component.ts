import { Component } from '@angular/core';

@Component({
  selector: 'app-groupes',
  standalone: true,
  imports: [],
  templateUrl: './groupes.component.html',
  styleUrl: './groupes.component.scss'
})
export class GroupesComponent {

}
