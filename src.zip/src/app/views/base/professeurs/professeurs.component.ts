import { Component } from '@angular/core';

@Component({
  selector: 'app-professeurs',
  standalone: true,
  imports: [],
  templateUrl: './professeurs.component.html',
  styleUrl: './professeurs.component.scss'
})
export class ProfesseursComponent {

}
