import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TransfereEntreSiteComponent } from './transfere-entre-site.component';

describe('TransfereEntreSiteComponent', () => {
  let component: TransfereEntreSiteComponent;
  let fixture: ComponentFixture<TransfereEntreSiteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TransfereEntreSiteComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(TransfereEntreSiteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
