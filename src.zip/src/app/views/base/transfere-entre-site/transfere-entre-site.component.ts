import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { NgSelectModule } from '@ng-select/ng-select';
import { SiteService } from '../../../service/site.service';
import { FiliereService } from '../../../service/filiere.service';
import { InscriptionService } from '../../../service/inscription.service';
import { EtudiantService } from '../../../service/etudiant.service';
import { AuthService } from '../../../service/auth.service';

import { Site } from '../../../model/site.model';
import { Filiere } from '../../../model/filiere.model';
import { Etudiant } from '../../../model/etudiant.model';
import { User } from '../../../model/user.model';

@Component({
  selector: 'app-transfere-entre-site',
  standalone: true,
  imports: [
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent,
    ColComponent,
    RowComponent,
    ReactiveFormsModule,
    NgSelectModule,
    CommonModule
  ],
  templateUrl: './transfere-entre-site.component.html',
  styleUrl: './transfere-entre-site.component.scss'
})
export class TransfereEntreSiteComponent implements OnInit{
  cours = [
    {id:1, nom:'JOUR'},
    {id:2, nom:'SOIR'}
  ]
  sites: Site[] = []
  filieres: Filiere[] = []
  etudiants: Etudiant[] = []
  donnee: any[] = [];
  user!: User;
  etudiantDetails: any;

  ngOnInit(): void {
    this.getAllFiliere()
    this.getAllSite()
    this.user = this.authService.getUserFromLocalStorage();
  }

  constructor(
    private filiereService: FiliereService,
    private inscrireService: InscriptionService,
    private etudiantService: EtudiantService,
    private siteService: SiteService,
    private authService: AuthService
  ){}

 getAllSite(){
  this.siteService.getAllSite().subscribe({
    next: (response) => {this.sites = response},
    error: (err) => {console.log('Erreur')}
  })
 }

  readonly myFormGroup = new FormGroup({
    annee: new FormControl(""),
    cours: new FormControl(""),
    filiere: new FormControl(""),
    semestre: new FormControl(""),
    etudiant: new FormControl(""),
  });
  readonly leTransfere =  new FormGroup({
    cours: new FormControl(""),
    filiere: new FormControl(""),
    site: new FormControl("")
  })

  AfficherEtudiants(){
    const donnees = this.myFormGroup.value
    this.donnee[0] = this.user.parametre.anneepardefaut.id
    this.donnee[1] = donnees.cours
    this.donnee[2] = donnees.filiere
    this.donnee[3] = this.user.administrateur.site.id
    //console.log("test test *- ***")
    this.inscrireService.getListeParClasse(this.donnee).subscribe((data: any) =>{
      this.etudiants = data
      //console.log(data+"test test *- ***")
    })
  }
  AfficherDetail(){
    const donnees = this.myFormGroup.value
    const etudiantId = donnees.etudiant;
    const an = this.user.parametre.anneepardefaut.id
    this.etudiantService.getEtudiantDetails(etudiantId, an).subscribe(data => {
      this.etudiantDetails = data;
    });
  }
  Transfere(){
    const donneess = this.myFormGroup.value
    const donnees = this.leTransfere.value
    this.donnee[0] = donnees.cours
    this.donnee[1] = donnees.filiere
    this.donnee[2] = this.user.parametre.anneepardefaut.id
    this.donnee[3] = this.user.administrateur.site.id
    this.donnee[4] = donneess.etudiant
    this.donnee[5] = donnees.site
    
    this.etudiantService.TransfereEtudiantEntreClasse(this.donnee).subscribe(response =>{
      console.log("mdt ++ "+response)
    })
  }

  getAllFiliere(){
    this.filiereService.getAllFilieres().subscribe(data => {
      this.filieres = data
    });
  }
}
