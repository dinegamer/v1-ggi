import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { EtudiantService } from '../../../service/etudiant.service';
import { data } from 'jquery';

@Component({
  selector: 'app-recherche',
  standalone: true,
  imports: [
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent, 
    ColComponent,
    RowComponent,
    CommonModule,
    RouterModule,
    ReactiveFormsModule
  ],
  templateUrl: './recherche.component.html',
  styleUrl: './recherche.component.scss'
})
export class RechercheComponent {
  searchForm: FormGroup;
  message: string = '';
  etudiants: any[] = [];

  constructor(
    private fb: FormBuilder,
    private etudiantService: EtudiantService) {
      this.searchForm = this.fb.group({
        nomEtudiant: [''],
        prenomEtudiant: [''],
        numeroTuteur: [''],
        telephoneEtudiant: ['']
      });
  }

  onSubmit() {
    const filters = this.searchForm.value;
    
    // Filtrer les valeurs vides pour ne pas envoyer des paramètres inutiles
    Object.keys(filters).forEach(key => {
      if (!filters[key]) delete filters[key];
    });

    this.etudiantService.rechercherEtudiants(filters).subscribe({
      next: (data) => {
        this.etudiants = data;
      },
      error: (error) => {
        console.error('Erreur lors de la recherche des étudiants', error);
      }
    });
  }

}
