import { Component, OnInit } from '@angular/core';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent, TextColorDirective } from '@coreui/angular';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NgSelectModule } from '@ng-select/ng-select';
import { User } from '../../../model/user.model';
import { Etudiant } from '../../../model/etudiant.model';
import { Filiere } from '../../../model/filiere.model';
import { AuthService } from '../../../service/auth.service';
import { jsPDF } from 'jspdf';
import { ActivatedRoute } from '@angular/router';
import { InscriptionService } from '../../../service/inscription.service';
import { Inscrire } from '../../../model/inscription.model';
import { Administrateur } from '../../../model/administrateur.model';
import { AdminService } from '../../../service/admin.service';

@Component({
  selector: 'app-demandedestage',
  standalone: true,
  imports: [
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent,
    ColComponent,
    RowComponent,
    TextColorDirective,
    ReactiveFormsModule,
    FormsModule,
    CommonModule,
    NgSelectModule
  ],
  templateUrl: './demandedestage.component.html',
  styleUrls: ['./demandedestage.component.scss']
})
export class DemandedestageComponent implements OnInit {

  currentDate = new Date();
  formattedDate = this.currentDate.toLocaleDateString('fr-FR');

  id!: number;
  anneeId!: number;
  monsieurs = [
    { nom: 'Monsieur' },
    { nom: 'Madame' }
  ];
  user!: User;
  datevalidite!: string;
  site!: string;
  attestation: boolean = false;
  etudiant!: Etudiant;
  filiere!: Filiere;
  civilite!: string;
  destinateur!: string;
  structure!: string;
  inscrires: Inscrire[] = [];
  inscrire!: Inscrire;
  administrateurs: Administrateur[] = [];
  nomSignateur: string = '';
  roleSignateur: string = '';

  ngOnInit(): void {
    this.user = this.authService.getUserFromLocalStorage();
    if (this.user && this.user.administrateur.site.id) {
      this.signateur();
    } else {
      alert('Utilisateur ou site manquant au chargement');
    }
    // Calcul de la date de validité (un an à partir de la date actuelle)
    const dateActuelle = new Date();
    const dansUnAn = new Date(dateActuelle);
    dansUnAn.setFullYear(dateActuelle.getFullYear() + 1);

    // Formatage de la date
    const options: Intl.DateTimeFormatOptions = {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    };
    this.datevalidite = dansUnAn.toLocaleDateString('fr-FR', options);
    this.id = Number(this.route.snapshot.paramMap.get('id'));
    this.anneeId = Number(this.route.snapshot.paramMap.get('annee'));
    this.getAllInscrireEtudiant();
  }

  constructor(
    private route: ActivatedRoute,
    private inscrireService: InscriptionService,
    private authService: AuthService
  ) { }

  readonly mesRecherches = new FormGroup({
    structure: new FormControl(""),
    destinateur: new FormControl(""),
    civilite: new FormControl("")
  });

  signateur(){
    if (!this.user || !this.user.administrateur.site.id) {
      console.warn('Utilisateur ou site non défini');
      return;
    }

    switch (this.user.administrateur.site.id) {
      case 1:
        this.nomSignateur = 'Docteur Khalid DEMBELE';
        this.roleSignateur = 'Secrétaire Général';
        break;
      case 2:
        this.nomSignateur = 'Monsieur Salif COULIBALY';
        this.roleSignateur = 'Directeur des Etudes';
        break;
      case 3:
        this.nomSignateur = 'Monsieur Daouda DIAKITE';
        this.roleSignateur = 'Directeur des Etudes';
        break;
      default:
        this.nomSignateur = 'Inconnu';
        this.roleSignateur = 'Rôle non défini';
        break;
    }
  }

  // Fonction pour récupérer les inscriptions des étudiants
  getAllInscrireEtudiant() {
    this.inscrireService.getAllInscrireEtudiant(this.id).subscribe({
      next: (data) => {
        this.inscrires = data;
        this.inscrire = this.inscrires.find(ins => ins.anneeuv && ins.anneeuv.id === this.anneeId)!;
      }
    });
  }

  // Fonction pour afficher l'attestation d'inscription
  AttestationInscription() {
    this.attestation = true;
    const donnee = this.mesRecherches.value;
    this.civilite = donnee.civilite || '';
    this.destinateur = donnee.destinateur || '';
    this.structure = donnee.structure || '';
  }
  // Fonction pour imprimer le document PDF
  imprimer() {
    const imageUrl = 'assets/images/logo-v.png';
    const img = new Image();
    img.src = imageUrl;

    img.onload = () => {
        const doc = new jsPDF();
        doc.addImage(img, 'PNG', 10, 10, 30, 30);

        const pageWidth = doc.internal.pageSize.getWidth();
        let y = 15;
        const lineHeight = 8;
        const lineHeightCorpsTexte = 9;
        const lineHeightEspacementSupplementaire = 2;

        // En-tête
        doc.setFont("Times", "bold");
        doc.setFontSize(14);
        doc.text('INSTITUT SUPÉRIEUR DES TECHNIQUES', pageWidth / 2 + 10, y, { align: 'center' });
        y += lineHeight;
        doc.text('ÉCONOMIQUES COMPTABLES ET COMMERCIALES', pageWidth / 2 + 10, y, { align: 'center' });
        y += lineHeight;
        doc.text('DUT – LICENCE – MASTER', pageWidth / 2 + 10, y, { align: 'center' });

        // Date et titre
        y += lineHeight * 3;
        doc.setFont("Times", "normal");
        doc.setFontSize(14);
        doc.text(`Bamako, le ${this.formattedDate}`, pageWidth - 80, y);
        y += lineHeight;

        // Générer un code aléatoire de 5 chiffres
        const genererCode5Chiffres = (): string => {
            const min = 10000;
            const max = 99999;
            return Math.floor(min + Math.random() * (max - min + 1)).toString();
        };

        const codeStage: string = genererCode5Chiffres();
        doc.text(`DEMANDE DE STAGE N° ${codeStage} /INTEC SUP/${this.formattedDate}`, pageWidth - 120, y, { align: 'center' });

        // Destinataire
        y += lineHeight * 2;
        doc.text(`À ${this.civilite}, le ${this.destinateur} de`, pageWidth / 2, y, { align: 'center' });
        y += lineHeight;
        doc.text(this.structure, pageWidth / 2, y, { align: 'center' });

        // Corps du texte
        y += lineHeight * 2;
        doc.setFont("Times", "normal");
        doc.text("Monsieur,", 20, y);
        y += lineHeight * 2;

        const paragraph1 = `Dans le dessein de contribuer au renforcement des capacités intellectuelles en ralliant les cours théoriques à la pratique professionnelle, l'INTEC SUP vous adresse cette demande de bien vouloir accueillir notre étudiant(e) :`;
        const textSplit1 = doc.splitTextToSize(paragraph1, pageWidth - 40);
        textSplit1.forEach((line: string) => {
            doc.text(line, 20, y);
            y += lineHeightCorpsTexte + lineHeightEspacementSupplementaire;
        });

        // Partie en gras (Nom de l'étudiant)
        doc.setFont("Times", "bold");
        const nomComplet = `${this.inscrire.etudiant.prenom} ${this.inscrire.etudiant.nom}`;
        doc.text(nomComplet, 20, y);

        const nomWidth = doc.getTextWidth(nomComplet);
        doc.setFont("Times", "normal");
        const texteSuite1 = ` en ${this.inscrire.filiere.nom}, spécialité :`;
        doc.text(texteSuite1, 20 + nomWidth + 2, y);

        const suite1Width = doc.getTextWidth(texteSuite1);
        doc.setFont("Times", "bold");

        // Gérer la description sur plusieurs lignes si nécessaire
        const descriptionSplit = doc.splitTextToSize(this.inscrire.filiere.description, pageWidth - (20 + nomWidth + suite1Width + 4) - 20);

        doc.text(descriptionSplit[0], 20 + nomWidth + suite1Width + 4, y);

        // Si la description est longue, elle passe à la ligne
        if (descriptionSplit.length > 1) {
            y += lineHeightCorpsTexte;
            for (let i = 1; i < descriptionSplit.length; i++) {
                doc.text(descriptionSplit[i], 20, y);
                y += lineHeightCorpsTexte;
            }
        } else {
            y += lineHeightCorpsTexte + lineHeightEspacementSupplementaire;
        }

        doc.setFont("Times", "normal");
        doc.text("dans le cadre d'un stage d'initiation de trois (3) mois.", 20, y);
        y += lineHeightCorpsTexte + lineHeightEspacementSupplementaire;

        // Suite du texte
        const suite2 = `Le stage doit permettre à l'étudiant(e) de confronter ses connaissances aux réalités du terrain ; il fait partie d'une démarche pédagogique au cours de laquelle, l'étudiant(e) prend personnellement contact avec le milieu professionnel dans lequel il désire évoluer. \n En espérant que cette présente sera le point de départ d'un partenariat bénéfique et enrichissant, nous vous prions de croire, Monsieur le ${this.destinateur}, en notre franche et sincère considération.`;
        const textSplit2 = doc.splitTextToSize(suite2, pageWidth - 40);
        textSplit2.forEach((line: string) => {
            doc.text(line, 20, y);
            y += lineHeightCorpsTexte;
        });

        // Signature
        y += lineHeight;
        doc.text('Fait à Bamako, le .........', 130, y);
        y += lineHeight;
        doc.text(this.roleSignateur, 135, y);
        y += lineHeight * 2;
        doc.text(this.nomSignateur, 130, y);

        // Pied de page
        doc.setFontSize(7);
        doc.text(this.user.administrateur.site.adresse, 10, 285);

        // Générer le blob
        const blob = doc.output('blob');
        const blobUrl = URL.createObjectURL(blob);
        window.open(blobUrl, '_blank');
    };
}

}
