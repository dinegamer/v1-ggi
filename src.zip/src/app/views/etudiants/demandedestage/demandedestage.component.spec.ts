import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DemandedestageComponent } from './demandedestage.component';

describe('DemandedestageComponent', () => {
  let component: DemandedestageComponent;
  let fixture: ComponentFixture<DemandedestageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DemandedestageComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DemandedestageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
