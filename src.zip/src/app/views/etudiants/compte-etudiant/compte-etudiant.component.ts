import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, FormDirective, RowComponent } from '@coreui/angular';
import { AuthService } from '../../../service/auth.service';
import { User } from '../../../model/user.model';
import { Filiere } from '../../../model/filiere.model';
import { FiliereService } from '../../../service/filiere.service';
import { CommonModule } from '@angular/common';
import { NgSelectModule } from '@ng-select/ng-select';
import { InscriptionService } from '../../../service/inscription.service';
import { Etudiant } from '../../../model/etudiant.model';
import { EtudiantService } from '../../../service/etudiant.service';
import { Anneeuv } from '../../../model/anneeuv.model';
import { AnneeuvService } from '../../../service/anneeuv.service';

@Component({
  selector: 'app-compte-etudiant',
  standalone: true,
  imports: [
    FormsModule,
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent,
    ColComponent,
    RowComponent,
    CommonModule,
    NgSelectModule,
    FormsModule,
    FormDirective,
    ReactiveFormsModule
  ],
  templateUrl: './compte-etudiant.component.html',
  styleUrl: './compte-etudiant.component.scss'
})
export class CompteEtudiantComponent implements OnInit {
  comptes: Etudiant[] = [];
  compteForm!: Etudiant;
  user!: User;
  annees: Anneeuv[] = []
  resultat: boolean = false
  cours = [
    {id:1, nom:'JOUR'},
    {id:2, nom:'SOIR'}
  ]
  filieres: Filiere[] = [];

  readonly mesRecherches = new FormGroup({   
      cours: new FormControl(""),
      filiere: new FormControl("")
    });

  constructor(
    private inscrireService: InscriptionService,
    private filiereService: FiliereService,
    private authService: AuthService,
    private etudiantService: EtudiantService,
    private anneeService: AnneeuvService
) {}

  ngOnInit(): void {
    this.getAllAnnee();
    this.user = this.authService.getUserFromLocalStorage();
    this.getAllFiliere();
  }
  getAllAnnee(){
    this.anneeService.getAllAnnee().subscribe({
      next: (data) =>{this.annees = data}
    })
  }
  getAllFiliere(){
    this.filiereService.getAllFilieres().subscribe(data =>{
      this.filieres = data
    })
  }
  RechercheEtudiant(){
    const donnees = this.mesRecherches.value
    let donnee = [
      this.user.parametre.anneepardefaut.id,
      donnees.cours,
      donnees.filiere,
      this.user.administrateur.site.id
    ]
    
    this.inscrireService.getListeParClasse(donnee).subscribe({
      next:(response) =>{
        this.comptes = response
        this.resultat = true
      },
      error:(err) =>{
        console.error('Erreur lors de la récupération des posts', err);
      },
      complete: () => {
        console.log('Requête terminée');
      }
    })
    //console.log(this.inscrires+" mft ++")
  }
  activerCompte(id: number, compte: Etudiant) {
   this.etudiantService.update(id, compte).subscribe({
    next: (data) =>{
      this.RechercheEtudiant()
    },
    error: (erreur) => {console.log(erreur+" *** test")}
   })
  }

  deleteCompte(compte: Etudiant) {
    if (confirm('Voulez-vous vraiment supprimer ce compte ?')) {
      //this.compteService.deleteCompte(id).subscribe(/*() => this.loadComptes()*/);
    }
  }

}
