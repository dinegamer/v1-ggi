import { Component, OnInit } from '@angular/core';
import { Filiere } from '../../../model/filiere.model';
import { User } from '../../../model/user.model';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { FiliereService } from '../../../service/filiere.service';
import { EtudiantService } from '../../../service/etudiant.service';
import { AuthService } from '../../../service/auth.service';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { NgSelectModule } from '@ng-select/ng-select';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-nouveau',
  standalone: true,
  imports: [
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent,
    ColComponent,
    RowComponent,
    ReactiveFormsModule,
    NgSelectModule,
    CommonModule
  ],
  templateUrl: './nouveau.component.html',
  styleUrl: './nouveau.component.scss'
})
export class NouveauComponent implements OnInit{ 
  filieres: Filiere[] = [];
  errer: boolean = false
  errermsg!: string
  isButtonDisabled: boolean = true; // Initialement désactivé
  isLoading: boolean = false
  cours = [
    {id:1, nom:'JOUR'},
    {id:2, nom:'SOIR'}
  ]
  user!: User;
  msg: boolean = false
  message!: string
  donnee: string[] = []

  readonly inscrptionForm = new FormGroup({
    matricule: new FormControl(""),
    site: new FormControl(""),
    nom: new FormControl(""),
    prenom: new FormControl(""),
    genre: new FormControl(""),
    nationalite: new FormControl(""),
    telephone: new FormControl(""),
    adresse: new FormControl(""),
    email: new FormControl(""),
    naissance: new FormControl(""),
    teltuteur: new FormControl(""),
    prenompere: new FormControl(""),
    prenommere: new FormControl(""),
    nommere: new FormControl(""),
    cours: new FormControl(""),
    filiere: new FormControl(null),
    annee: new FormControl(""), 
    observation: new FormControl("")   
  });
 
  ngOnInit(): void {
    this.getAllFiliere()
    this.user = this.authService.getUserFromLocalStorage();
  }

  constructor(    
    private filiereService: FiliereService,
    private etudiantService: EtudiantService,
    private authService: AuthService    
  ){}  
  Inscription(){
    this.isLoading = true
    const now = new Date();
    const dateStr = now.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' });
    const timeStr = now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

    const donnees = this.inscrptionForm.value
    //etudiant
    this.donnee[0] = donnees.matricule || ''
    this.donnee[1] = donnees.nom || ''
    this.donnee[2] = donnees.genre || ''
    this.donnee[3] = donnees.nationalite || ''
    this.donnee[4] = donnees.telephone || ''
    this.donnee[5] = donnees.adresse || ''
    this.donnee[6] = donnees.email || ''
    this.donnee[7] = donnees.naissance || ''
    this.donnee[8] = donnees.teltuteur || ''
    this.donnee[9] = donnees.prenompere || ''
    this.donnee[10] = donnees.prenommere || ''
    this.donnee[11] = donnees.nommere || ''
    this.donnee[12] = dateStr
    this.donnee[13] = timeStr
    this.donnee[14] = donnees.prenom || ''
    //etudiant
    this.donnee[15] = ''+this.user.administrateur.site.id
    this.donnee[16] = donnees.cours || ''
    this.donnee[17] = donnees.observation || ''
    this.donnee[18] = donnees.filiere || ''
    this.donnee[19] = ''+this.user.parametre.anneepardefaut.id 
    
    //console.log(donnees+"****++mdt++")
    this.etudiantService.saveEtudiant(this.donnee).subscribe({
      next: (response) => {
        this.msg = false
        this.message = response.message; // ✅ Assurez-vous d'accéder à response.message
        this.isLoading = false
        this.resetForm() 
      }, 
      error: (errer) => {
        this.msg = true
        this.isLoading = false
        this.message = "Une erreur est survenue lors de l'inscription.";
      }
    });
  }
  verification(){
    const donnee = this.inscrptionForm.value
    let matricule = donnee.matricule
    this.etudiantService.getEtudiantParMatricule(matricule).subscribe(response =>{
      console.log(response.message+" 444")
     if(response.message !== undefined){
        this.errer = true;
        this.errermsg = response.message        
        this.isButtonDisabled = true;
      }else{
        this.errer = false;
        this.isButtonDisabled = false
      }
      
      }
    )
  }
  
  getAllFiliere(){
    this.filiereService.getAllFilieres().subscribe(data =>{
      this.filieres = data
    })
  }
  resetForm(){
    // 🔄 Recharger la page après succès
    setTimeout(() => {
      window.location.reload();
    }, 2000); // Petite pause pour afficher le message
  }
  
}
