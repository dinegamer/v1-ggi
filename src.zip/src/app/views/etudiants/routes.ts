import { Routes } from '@angular/router';

export const routes: Routes = [
    {
      path: '',
      data: {
        title: 'Etudiants'
      },
      children: [
        {
          path: '',
          redirectTo: 'etudiants',
          pathMatch: 'full'
        },{
          path: 'etudiants',
          loadComponent: () => import('./etudiants.component').then(m => m.EtudiantsComponent),
          data: {
            title: 'Etudiants'
          }
        },
        {
          path: 'nouveau',
          loadComponent: () => import('./nouveau/nouveau.component').then(m => m.NouveauComponent),
          data: { title: 'Nouveau' }
        },
        {
          path: 'compte-etudiant',
          loadComponent: () => import('./compte-etudiant/compte-etudiant.component').then(m => m.CompteEtudiantComponent),
          data: { title: 'Compte Etudiant' }
        },
        {
          path: 'detail/:id/:annee',
          loadComponent: () => import('./detail/detail.component').then(m => m.DetailComponent),
          data:{ title: 'Detail' }
        },
        {
          path: 'recherche',
          loadComponent: () => import('./recherche/recherche.component').then(m => m.RechercheComponent),
          data:{ title: 'Recherche'}
        },
        {
          path: 'attestation/:id',
          loadComponent: () => import('./attestation/attestation.component').then(m => m.AttestationComponent),
          data:{ title: 'Attestation'}
        },
        {
          path: 'demandedestage/:id/:annee',
          loadComponent: () => import('./demandedestage/demandedestage.component').then(m => m.DemandedestageComponent),
          data: {
            title: 'Demande de stage'
          }
        },
        {
          path: 'ensemble',
          loadComponent: () => import('./ensemble/ensemble.component').then(m => m.EnsembleComponent),
          data: {
            title: 'Tout les étudiants'
          }
        },
        {
          path: 'plusdetail/:id',
          loadComponent: () => import('./plusdetail/plusdetail.component').then(m => m.PlusdetailComponent),
          data: {
            title: 'Détail étudiant'
          }
        },
        {
          path: 'affecter/:id',
          loadComponent: () => import('./affecter/affecter.component').then(m => m.AffecterComponent),
          data: {
            title: 'Affecter étudiant'
          }
        },
        {
          path: 'presence',
          loadComponent: () => import('./presence/presence.component').then(m => m.PresenceComponent),
          data: {
            title: 'Presence'
          }
        },
        {
          path: 'nombreetudiantparcycle',
          loadComponent: () => import('../etudiants/nombreetudiantparcycle/nombreetudiantparcycle.component').then(m => m.NombreetudiantparcycleComponent),
          data: {
            title: 'Nombre etudiant par cycle'
          }
        },
        {
          path: 'nombreetudiantparfiliere',
          loadComponent: () => import('../etudiants/nombreetudiantparfiliere/nombreetudiantparfiliere.component').then(m => m.NombreetudiantparfiliereComponent),
          data: {
            title: 'Nombre etudiant par Filière'
          }
        },
        {
          path: 'soutenable',
          loadComponent: () => import('../etudiants/soutenable/soutenable.component').then(m => m.SoutenableComponent),
          data: {
            title: 'Etudiant Soutenable'
          }
        }
      ]
    }
];
