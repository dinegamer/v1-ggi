import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SoutenableComponent } from './soutenable.component';

describe('SoutenableComponent', () => {
  let component: SoutenableComponent;
  let fixture: ComponentFixture<SoutenableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SoutenableComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SoutenableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
