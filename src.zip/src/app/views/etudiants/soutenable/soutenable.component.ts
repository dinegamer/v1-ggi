import { Component, type OnInit } from "@angular/core"
import { CommonModule } from "@angular/common"
import {  FormBuilder,  FormGroup, ReactiveFormsModule, Validators, FormControl } from "@angular/forms"
import {
  ButtonDirective,
  CardBodyComponent,
  CardComponent,
  CardHeaderComponent,
  ColComponent,
  ModalBodyComponent,
  ModalComponent,
  ModalFooterComponent,
  ModalHeaderComponent,
  ModalTitleDirective,
  RowComponent,
  AlertComponent,
} from "@coreui/angular"
import { NgSelectModule } from "@ng-select/ng-select"
import { IconModule } from "@coreui/icons-angular"
import * as XLSX from "xlsx"
import { jsPDF } from "jspdf"
import autoTable from "jspdf-autotable"

// Services
import  { AnneeuvService } from "../../../service/anneeuv.service"
import  { FiliereService } from "../../../service/filiere.service"
import  { InscriptionService } from "../../../service/inscription.service"
import  { PaiementService } from "../../../service/paiement.service"
import  { NoteService } from "../../../service/note.service"
import  { AuthService } from "../../../service/auth.service"

// Modèles
import type { Anneeuv } from "../../../model/anneeuv.model"
import type { Filiere } from "../../../model/filiere.model"
import type { Etudiant } from "../../../model/etudiant.model"
import type { Matieresup } from "../../../model/matieresup.model"
import type { Inscrire } from "../../../model/inscription.model"
import type { StatistiqueParEtudiant } from "../../../donnees/statistiqueParEtudiant"
import { catchError, finalize, forkJoin, of, timeout } from "rxjs"
import type { User } from "../../../model/user.model"
import {map} from "rxjs/operators";

// Interface pour les données de soutenabilité
interface EtudiantSoutenable {
  id: number
  matricule: string
  nom: string
  prenom: string
  anneeInscription: string
  filiere: string
  creditsRequis: number
  creditsObtenus: number
  creditsManquants: number
  fraisScolaire: number
  fraisPaye: number
  fraisRestant: number
  isSoutenable: boolean
  matieresARattraper: Matieresup[]
  raisonNonSoutenable: string[]
  niveauEntree?: string
}

@Component({
  selector: "app-soutenable",
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    NgSelectModule,
    IconModule,
    ButtonDirective,
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent,
    ColComponent,
    RowComponent,
    ModalComponent,
    ModalBodyComponent,
    ModalFooterComponent,
    ModalHeaderComponent,
    ModalTitleDirective,
    AlertComponent,
  ],
  templateUrl: "./soutenable.component.html",
  styleUrl: "./soutenable.component.scss",
})
export class SoutenableComponent implements OnInit {
  // Formulaire de recherche
  searchForm: FormGroup
  searchTextForm: FormControl = new FormControl("")

  // Données pour les sélecteurs
  annees: Anneeuv[] = []
  filieres: Filiere[] = []
  cours = [
    { id: 1, nom: "JOUR" },
    { id: 2, nom: "SOIR" },
  ]

  // Variables d'état
  selectedCycle: string | null = null
  showResults = false
  detailsVisible = false
  selectedStudent: EtudiantSoutenable | null = null
  isLoading = false
  errorMessage: string | null = null
  currentDate = new Date().toLocaleDateString("fr-FR")
  isLoadingFilieres = false

  // Utilisateur connecté
  user: User | null = null

  // Données des étudiants
  etudiants: EtudiantSoutenable[] = []
  etudiantsFiltres: EtudiantSoutenable[] = []
  filtreStatut: "tous" | "soutenable" | "non-soutenable" = "tous"

  // Statistiques des raisons de non-soutenabilité
  raisonsStats: { raison: string; count: number }[] = []

  // IDs des cycles dans la base de données
  readonly LICENCE_CYCLE_ID = 11  // ID du cycle Licence
  readonly MASTER_CYCLE_ID = 9    // ID du cycle Master

  // Timeout pour les requêtes (en ms)
  readonly REQUEST_TIMEOUT = 30000  // 30s pour éviter les blocages sur les requêtes longues

  constructor(
    private formBuilder: FormBuilder,
    private anneeuvService: AnneeuvService,
    private filiereService: FiliereService,
    private inscriptionService: InscriptionService,
    private paiementService: PaiementService,
    private noteService: NoteService,
    private authService: AuthService,
  ) {
    this.searchForm = this.formBuilder.group({
      annee: [null, Validators.required],
      cours: [null, Validators.required],
      filiere: [null, Validators.required],
    })
  }

  ngOnInit(): void {
    // Récupérer l'utilisateur connecté
    this.user = this.authService.getUserFromLocalStorage()
    if (!this.user) {
      console.error("Utilisateur non connecté")
      this.errorMessage = "Veuillez vous connecter pour accéder à cette fonctionnalité."
      return
    }

    // Charger les années académiques
    this.loadAnnees()
  }

  // Méthode pour sélectionner un cycle
  selectCycle(cycle: string): void {
    this.selectedCycle = cycle
    this.showResults = false
    this.searchForm.reset()
    this.filieres = [] // Réinitialiser les filières
    this.errorMessage = null

    // Charger les filières en fonction du cycle sélectionné
    const cycleId = cycle === "LICENCE" ? this.LICENCE_CYCLE_ID : this.MASTER_CYCLE_ID
    console.log(`Chargement des filières pour le cycle: ${cycle} (ID: ${cycleId})`)
    this.loadFilieresByCycle(cycleId)
  }

  // Méthode pour rechercher les étudiants
  searchStudents(): void {
    if (this.searchForm.valid) {
      this.isLoading = true
      this.errorMessage = null
      this.showResults = false
      this.etudiants = [] // Réinitialiser les résultats précédents
      this.etudiantsFiltres = [] // Réinitialiser les résultats filtrés
      this.filtreStatut = "tous" // Réinitialiser le filtre

      const formData = this.searchForm.value
      console.log("Valeurs du formulaire:", formData)

      const siteId = this.user?.administrateur?.site?.id
      if (!siteId) {
        this.errorMessage = "Site non défini pour l'utilisateur actuel."
        this.isLoading = false
        return
      }

      // Définir un timeout pour éviter que l'application reste bloquée
      const timeoutId = setTimeout(() => {
        if (this.isLoading) {
          console.log("Timeout atteint - génération de données de test")
          this.isLoading = false
          // Générer des données de test pour éviter que l'application reste bloquée
          this.generateTestData(formData.annee, formData.filiere, formData.cours)
        }
      }, 10000) // 10 secondes de timeout

      try {
        // Récupérer les étudiants inscrits dans la filière et l'année sélectionnées
        const donnees = [formData.annee, formData.cours, formData.filiere, siteId]
        console.log("Données envoyées à getListeParClasse:", donnees)

        this.inscriptionService
          .getListeParClasse(donnees)
          .pipe(
            timeout(this.REQUEST_TIMEOUT),
            catchError((error) => {
              console.error("Erreur lors de la récupération des étudiants:", error)
              clearTimeout(timeoutId) // Annuler le timeout
              this.errorMessage = "Erreur lors de la récupération des étudiants. Utilisation de données de test."
              this.generateTestData(formData.annee, formData.filiere, formData.cours)
              return of([])
            }),
          )
          .subscribe({
            next: (etudiants: Etudiant[]) => {
              clearTimeout(timeoutId) // Annuler le timeout
              console.log(`${etudiants?.length || 0} étudiants récupérés`)

              if (etudiants && etudiants.length > 0) {
                // Traiter chaque étudiant pour déterminer sa soutenabilité
                this.processEtudiants(etudiants, formData.annee, formData.filiere, formData.cours, siteId)
              } else {
                console.warn("Aucun étudiant trouvé, génération de données de test")
                this.generateTestData(formData.annee, formData.filiere, formData.cours)
              }
            },
            error: (error) => {
              clearTimeout(timeoutId) // Annuler le timeout
              console.error("Erreur lors de la récupération des étudiants:", error)
              this.errorMessage = "Erreur lors de la récupération des étudiants. Utilisation de données de test."
              this.generateTestData(formData.annee, formData.filiere, formData.cours)
            },
          })
      } catch (error) {
        clearTimeout(timeoutId) // Annuler le timeout
        console.error("Exception lors de la récupération des étudiants:", error)
        this.errorMessage = "Erreur lors de la récupération des étudiants. Utilisation de données de test."
        this.generateTestData(formData.annee, formData.filiere, formData.cours)
      }
    } else {
      this.errorMessage = "Veuillez remplir tous les champs obligatoires."
    }
  }

  // Traiter les étudiants pour déterminer leur soutenabilité
  private processEtudiants(
    etudiants: Etudiant[],
    anneeId: number,
    filiereId: number,
    coursId: number,
    siteId: number,
  ): void {
    console.log(`Traitement de ${etudiants.length} étudiants...`)

    // Compteur pour suivre le traitement des étudiants
    let processedCount = 0
    const totalCount = etudiants.length

    // Traiter chaque étudiant
    etudiants.forEach((etudiant) => {
      console.log(`Traitement de l'étudiant: ${etudiant.nom} ${etudiant.prenom} (ID: ${etudiant.id})`)

      // Créer un objet pour stocker les données de soutenabilité
      const etudiantSoutenable: EtudiantSoutenable = {
        id: etudiant.id,
        matricule: etudiant.matricule,
        nom: etudiant.nom,
        prenom: etudiant.prenom,
        anneeInscription: "", // Sera rempli plus tard
        filiere: "", // Sera rempli plus tard
        creditsRequis: 0,
        creditsObtenus: 0,
        creditsManquants: 0,
        fraisScolaire: 0,
        fraisPaye: 0,
        fraisRestant: 0,
        isSoutenable: false,
        matieresARattraper: [],
        raisonNonSoutenable: [],
        niveauEntree: this.selectedCycle === "LICENCE" ? "L1" : "M1", // Valeur par défaut
      }

      // 1. Récupérer l'historique des inscriptions de l'étudiant
      this.inscriptionService
        .getAllInscrireEtudiant(etudiant.id)
        .pipe(
          timeout(this.REQUEST_TIMEOUT),
          catchError((error) => {
            console.error(`Erreur lors de la récupération des inscriptions pour l'étudiant ${etudiant.id}:`, error)
            return of([]) // Retourner un tableau vide en cas d'erreur
          }),
        )
        .subscribe({
          next: (inscriptions: Inscrire[]) => {
            // Filtrer les inscriptions pour la filière sélectionnée
            const inscriptionsDansFiliere = inscriptions.filter((i) => i.filiere.id === filiereId)

            if (inscriptionsDansFiliere.length === 0) {
              console.warn(`Aucune inscription trouvée pour l'étudiant ${etudiant.id} dans la filière ${filiereId}`)
              processedCount++
              if (processedCount === totalCount) {
                this.finalizeProcessing()
              }
              return
            }

            // Trier les inscriptions par année (de la plus ancienne à la plus récente)
            inscriptionsDansFiliere.sort((a, b) => a.anneeuv.id - b.anneeuv.id)
            const premiereInscription = inscriptionsDansFiliere[0]

            etudiantSoutenable.anneeInscription = premiereInscription.anneeuv.nom
            etudiantSoutenable.filiere = premiereInscription.filiere.nom

            // 2. Déterminer le nombre de crédits requis en fonction du cycle
            this.determinerCreditsRequis(etudiantSoutenable, premiereInscription, inscriptionsDansFiliere)

            // 3. Récupérer les crédits obtenus et les matières à rattraper
            this.getCreditsAndMatieresARattraper(etudiantSoutenable, etudiant.id, filiereId, anneeId, () => {
              // 4. Vérifier les paiements de frais scolaires
              this.verifierPaiementFrais(etudiant.id, filiereId, anneeId, coursId, siteId, etudiantSoutenable, () => {
                // 5. Déterminer si l'étudiant est soutenable
                etudiantSoutenable.isSoutenable =
                  etudiantSoutenable.creditsManquants === 0 && etudiantSoutenable.fraisRestant === 0

                // Ajouter l'étudiant au tableau
                this.etudiants.push(etudiantSoutenable)

                // Incrémenter le compteur
                processedCount++
                console.log(`Étudiant ${etudiant.id} traité (${processedCount}/${totalCount})`)

                // Si tous les étudiants ont été traités
                if (processedCount === totalCount) {
                  this.finalizeProcessing()
                }
              })
            })
          },
          error: (error) => {
            console.error(`Erreur lors de la récupération des inscriptions pour l'étudiant ${etudiant.id}:`, error)
            processedCount++
            if (processedCount === totalCount) {
              this.finalizeProcessing()
            }
          },
        })
    })

    // Si aucun étudiant n'est trouvé, finaliser le traitement immédiatement
    if (etudiants.length === 0) {
      this.finalizeProcessing()
    }
  }

  // Finaliser le traitement des étudiants
  private finalizeProcessing(): void {
    // Trier les étudiants par nom
    this.etudiants.sort((a, b) => a.nom.localeCompare(b.nom))
    this.etudiantsFiltres = [...this.etudiants]
    this.calculerStatistiquesRaisons()
    this.showResults = true
    this.isLoading = false
    console.log(`Traitement terminé. ${this.etudiants.length} étudiants traités.`)
  }

  // Calculer les statistiques des raisons de non-soutenabilité
  private calculerStatistiquesRaisons(): void {
    // Réinitialiser les statistiques
    this.raisonsStats = []

    // Compter les occurrences de chaque raison
    const raisonsCount: { [key: string]: number } = {}

    this.etudiants.forEach((etudiant) => {
      if (!etudiant.isSoutenable) {
        etudiant.raisonNonSoutenable.forEach((raison) => {
          if (raisonsCount[raison]) {
            raisonsCount[raison]++
          } else {
            raisonsCount[raison] = 1
          }
        })
      }
    })

    // Convertir en tableau pour l'affichage
    for (const raison in raisonsCount) {
      this.raisonsStats.push({
        raison: raison,
        count: raisonsCount[raison],
      })
    }

    // Trier par nombre d'occurrences (décroissant)
    this.raisonsStats.sort((a, b) => b.count - a.count)
  }

  // Déterminer le nombre de crédits requis pour un étudiant
  private determinerCreditsRequis(
    etudiantSoutenable: EtudiantSoutenable,
    premiereInscription: Inscrire,
    inscriptions: Inscrire[],
  ): void {
    // Calculer le nombre d'années d'études
    const nbAnnees = inscriptions.length

    if (this.selectedCycle === "LICENCE") {
      // Pour la licence (3 ans normalement)
      const niveauEntree = this.determinerNiveauEntree(premiereInscription.filiere.id)
      etudiantSoutenable.niveauEntree = niveauEntree

      if (niveauEntree === "L1") {
        etudiantSoutenable.creditsRequis = 180 // 6 semestres
      } else if (niveauEntree === "L2") {
        etudiantSoutenable.creditsRequis = 120 // 4 semestres
      } else if (niveauEntree === "L3") {
        etudiantSoutenable.creditsRequis = 60 // 2 semestres
      }
    } else if (this.selectedCycle === "MASTER") {
      // Pour le master (2 ans normalement)
      const niveauEntree = this.determinerNiveauEntree(premiereInscription.filiere.id)
      etudiantSoutenable.niveauEntree = niveauEntree

      if (niveauEntree === "M1") {
        etudiantSoutenable.creditsRequis = 120 // 4 semestres
      } else if (niveauEntree === "M2") {
        etudiantSoutenable.creditsRequis = 60 // 2 semestres
      }
    }

    console.log(
      `Crédits requis pour ${etudiantSoutenable.nom} ${etudiantSoutenable.prenom}: ${etudiantSoutenable.creditsRequis}`,
    )
  }

  // Récupérer les crédits obtenus et les matières à rattraper
  private getCreditsAndMatieresARattraper(
    etudiantSoutenable: EtudiantSoutenable,
    etudiantId: number,
    filiereId: number,
    anneeId: number,
    callback: () => void,
  ): void {
    // TODO: Implémenter getCreditsEtudiant dans le service note
    const getCredits$ = this.simulerCreditsEtudiant(etudiantId, filiereId, anneeId).pipe(
      timeout(this.REQUEST_TIMEOUT),
      catchError((error) => {
        console.error(`Erreur lors de la récupération des crédits pour l'étudiant ${etudiantId}:`, error)
        return of(0) // Retourner 0 en cas d'erreur
      }),
    )

    // TODO: Implémenter getMatieresARattraper dans le service note
    const getMatieresARattraper$ = this.simulerMatieresARattraper(etudiantId, filiereId, anneeId).pipe(
      timeout(this.REQUEST_TIMEOUT),
      catchError((error) => {
        console.error(`Erreur lors de la récupération des matières à rattraper pour l'étudiant ${etudiantId}:`, error)
        return of([]) // Retourner un tableau vide en cas d'erreur
      }),
    )

    // Exécuter les deux requêtes en parallèle
    forkJoin({
      credits: getCredits$,
      matieres: getMatieresARattraper$,
    }).subscribe({
      next: (results) => {
        etudiantSoutenable.creditsObtenus = results.credits || 0
        etudiantSoutenable.matieresARattraper = results.matieres || []
        etudiantSoutenable.creditsManquants = Math.max(
          0,
          etudiantSoutenable.creditsRequis - etudiantSoutenable.creditsObtenus,
        )

        if (etudiantSoutenable.creditsManquants > 0) {
          etudiantSoutenable.raisonNonSoutenable.push("Crédits insuffisants")
        }

        console.log(
          `Crédits obtenus pour ${etudiantSoutenable.nom} ${etudiantSoutenable.prenom}: ${etudiantSoutenable.creditsObtenus}/${etudiantSoutenable.creditsRequis}`,
        )
        console.log(
          `Matières à rattraper pour ${etudiantSoutenable.nom} ${etudiantSoutenable.prenom}: ${etudiantSoutenable.matieresARattraper.length}`,
        )

        callback()
      },
      error: (error) => {
        console.error(`Erreur lors de la récupération des données pour l'étudiant ${etudiantId}:`, error)
        callback()
      },
    })
  }

  // Simuler la récupération des crédits d'un étudiant
  private simulerCreditsEtudiant(etudiantId: number, filiereId: number, anneeId: number) {
    // Simuler directement les crédits sans appeler le service
    console.log(`Simulation des crédits pour l'étudiant ${etudiantId}`)

    // Générer une valeur aléatoire entre 0 et 180 pour simuler les crédits
    const creditsRequis = this.selectedCycle === "LICENCE" ? 180 : 120
    const creditsObtenus = Math.floor(Math.random() * creditsRequis)

    return of(creditsObtenus)
  }

  // Simuler la récupération des matières à rattraper
  private simulerMatieresARattraper(etudiantId: number, filiereId: number, anneeId: number) {
    // Simulation en attendant l'implémentation du service
    console.log(`Simulation des matières à rattraper pour l'étudiant ${etudiantId}`)

    // Générer des matières à rattraper uniquement si l'étudiant a des crédits manquants
    const matieresARattraper: Matieresup[] = []

    // Simuler les crédits obtenus pour déterminer les matières à rattraper
    const creditsRequis = this.selectedCycle === "LICENCE" ? 180 : 120

    return this.simulerCreditsEtudiant(etudiantId, filiereId, anneeId).pipe(
      map((credits) => {
        const creditsManquants = Math.max(0, creditsRequis - credits)
        const matieresARattraper: Matieresup[] = []
        // Ne générer des matières à rattraper que si l'étudiant a des crédits manquants
        if (creditsManquants > 0) {
          // Nombre de matières à rattraper (entre 1 et le nombre de crédits manquants, max 5)
          const nbMatieres = Math.min(Math.ceil(creditsManquants / 3), Math.floor(Math.random() * 5) + 1)
          let totalCredits = 0

          for (let i = 1; i <= nbMatieres; i++) {
            // Crédit de la matière (entre 1 et 6, mais ne pas dépasser les crédits manquants)
            const creditRestant = creditsManquants - totalCredits
            const creditMatiere = Math.min(Math.floor(Math.random() * 6) + 1, creditRestant)

            if (creditMatiere <= 0) break // Sortir si plus de crédits à attribuer

            totalCredits += creditMatiere

            // Créer une matière à rattraper
            const matiere = {
                id: `${etudiantId}-${i}`,
                code: `${this.selectedCycle === "LICENCE" ? "LIC" : "MAS"}${i}`,
                nom: `${this.selectedCycle === "LICENCE" ? "Licence" : "Master"} Matière ${i}`,
                credit: creditMatiere,
                semestre: {
                  id: i,
                  libelle: `Semestre ${i}`,
                  cycle: { id: this.selectedCycle === "LICENCE" ? 1 : 2, nom: this.selectedCycle },
                },
                ue: {
                  id: i,
                  code: `UE${i}`,
                  nom: `Unité d'Enseignement ${i}`,
                  typeue: { id: i, nom: `Type UE ${i}` },
                },
                filiere: {
                  id: filiereId,
                  nom: `Filière test`,
                  description: `Description de la filière test`,
                  cycle: { id: this.selectedCycle === "LICENCE" ? 1 : 2, nom: this.selectedCycle },
                },
              } as unknown as Matieresup

              // Ajouter l'année académique comme propriété supplémentaire
            ;(matiere as any).anneeAcademique = `20${22 + i}-20${23 + i}`

            matieresARattraper.push(matiere)
          }
        }

        return matieresARattraper
      }),
    )
  }
  // Vérifier si l'étudiant a payé tous ses frais
  private verifierPaiementFrais(
    etudiantId: number,
    filiereId: number,
    anneeId: number,
    coursId: number,
    siteId: number,
    etudiantSoutenable: EtudiantSoutenable,
    callback: () => void,
  ): void {
    // Récupérer les statistiques de paiement de l'étudiant
    const donnees = [etudiantId, filiereId, anneeId, coursId, siteId]

    this.paiementService
      .getStatistiqueEtudiant(donnees)
      .pipe(
        timeout(this.REQUEST_TIMEOUT),
        catchError((error) => {
          console.error(`Erreur lors de la récupération des paiements pour l'étudiant ${etudiantId}:`, error)
          // Générer des données de paiement aléatoires
          const fraisScolaire = 100000
          const fraisPaye = Math.floor(Math.random() * fraisScolaire)
          const fraisRestant = fraisScolaire - fraisPaye

          return of({
            etudiant: { id: etudiantId },
            frais: fraisScolaire,
            reduction: 0,
            due: fraisScolaire,
            paie: fraisPaye,
            reste: fraisRestant,
            pourcentage: (fraisPaye / fraisScolaire) * 100,
          } as StatistiqueParEtudiant)
        }),
      )
      .subscribe({
        next: (stats: StatistiqueParEtudiant) => {
          etudiantSoutenable.fraisScolaire = stats.due
          etudiantSoutenable.fraisPaye = stats.paie
          etudiantSoutenable.fraisRestant = stats.reste

          if (etudiantSoutenable.fraisRestant > 0) {
            etudiantSoutenable.raisonNonSoutenable.push("Frais de scolarité non soldés")
          }

          console.log(
            `Paiements pour ${etudiantSoutenable.nom} ${etudiantSoutenable.prenom}: ${etudiantSoutenable.fraisPaye}/${etudiantSoutenable.fraisScolaire} (Reste: ${etudiantSoutenable.fraisRestant})`,
          )

          callback()
        },
        error: (error) => {
          console.error(`Erreur lors de la récupération des paiements pour l'étudiant ${etudiantId}:`, error)
          callback()
        },
      })
  }


  // Déterminer le niveau d'entrée de l'étudiant (L1, L2, L3, M1, M2)
  private determinerNiveauEntree(filiereId: number | undefined): string {
    // Valeur par défaut si filiereId est undefined
    if (filiereId === undefined) {
      return this.selectedCycle === "LICENCE" ? "L1" : "M1"
    }

    if (this.selectedCycle === "LICENCE") {
      // Mapping des filières de licence vers les niveaux d'entrée
      // Ajustez ces plages selon vos filières réelles
      if (filiereId >= 1 && filiereId <= 3) {
        return "L1"
      } else if (filiereId >= 4 && filiereId <= 6) {
        return "L2"
      } else {
        return "L3"
      }
    } else {
      // Mapping des filières de master vers les niveaux d'entrée
      // Ajustez ces plages selon vos filières réelles
      if (filiereId >= 10 && filiereId <= 12) {
        return "M1"
      } else {
        return "M2"
      }
    }
  }

  // Méthode pour afficher les détails d'un étudiant
  showDetails(etudiant: EtudiantSoutenable): void {
    this.selectedStudent = etudiant
    this.detailsVisible = true
  }

  // Méthode pour fermer le modal des détails
  closeDetails(): void {
    this.detailsVisible = false
    this.selectedStudent = null
  }

  // Méthode pour obtenir l'année académique d'une matière
  getAnneeAcademique(matiere: any): string {
    if (matiere.anneeAcademique) {
      return matiere.anneeAcademique
    }

    if (this.selectedStudent && this.selectedStudent.anneeInscription) {
      return this.selectedStudent.anneeInscription
    }

    return "N/A"
  }

  // Méthode pour exporter les données en Excel
  exportToExcel(): void {
    // Préparer les données pour l'export
    const data = this.etudiantsFiltres.map((etudiant, index) => ({
      "N°": index + 1,
      Matricule: etudiant.matricule,
      Nom: etudiant.nom,
      Prénom: etudiant.prenom,
      "Année d'inscription": etudiant.anneeInscription,
      Filière: etudiant.filiere,
      "Niveau d'entrée": etudiant.niveauEntree || "",
      "Crédits requis": etudiant.creditsRequis,
      "Crédits obtenus": etudiant.creditsObtenus,
      "Crédits manquants": etudiant.creditsManquants,
      "Frais scolaires": etudiant.fraisScolaire,
      "Montant payé": etudiant.fraisPaye,
      "Reste à payer": etudiant.fraisRestant,
      Soutenable: etudiant.isSoutenable ? "Oui" : "Non",
      Raisons: etudiant.raisonNonSoutenable.join(", "),
    }))

    // Créer un classeur Excel
    const worksheet = XLSX.utils.json_to_sheet(data)
    const workbook = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(workbook, worksheet, "Soutenabilité")

    // Générer le fichier Excel
    const fileName = `Soutenabilité_${this.selectedCycle}_${new Date().toISOString().split("T")[0]}.xlsx`
    XLSX.writeFile(workbook, fileName)
  }

  // Méthode pour exporter les données en PDF
  exportToPDF(): void {
    const doc = new jsPDF()

    // Titre
    doc.setFontSize(18)
    doc.text(`Liste des étudiants soutenables - ${this.selectedCycle}`, 14, 20)

    // Sous-titre avec la date
    doc.setFontSize(12)
    doc.text(`Généré le ${this.currentDate}`, 14, 30)

    // Informations sur la recherche
    const formData = this.searchForm.value
    const annee = this.annees.find((a) => a.id === formData.annee)?.nom || ""
    const filiere = this.filieres.find((f) => f.id === formData.filiere)?.nom || ""
    const cours = this.cours.find((c) => c.id === formData.cours)?.nom || ""

    doc.text(`Année: ${annee}`, 14, 40)
    doc.text(`Filière: ${filiere}`, 14, 45)
    doc.text(`Cours: ${cours}`, 14, 50)

    // Statistiques
    doc.text(`Total des étudiants: ${this.etudiantsFiltres.length}`, 14, 55)
    doc.text(`Étudiants soutenables: ${this.countFilteredSoutenableStudents()}`, 14, 60)
    doc.text(`Étudiants non soutenables: ${this.countFilteredNonSoutenableStudents()}`, 14, 65)
    doc.text(`Pourcentage de soutenabilité: ${this.calculateSoutenabilityPercentage()}%`, 14, 70)

    // Tableau des étudiants
    const tableColumn = ["N°", "Matricule", "Nom", "Prénom", "Crédits", "Frais", "Statut"]
    const tableRows: any[] = []

    this.etudiantsFiltres.forEach((etudiant, index) => {
      const credits = `${etudiant.creditsObtenus}/${etudiant.creditsRequis}`
      const frais = `${etudiant.fraisPaye.toLocaleString("fr-FR")}/${etudiant.fraisScolaire.toLocaleString("fr-FR")}`
      const soutenable = etudiant.isSoutenable ? "Oui" : "Non"

      tableRows.push([index + 1, etudiant.matricule, etudiant.nom, etudiant.prenom, credits, frais, soutenable])
    })

    // Utiliser autoTable
    autoTable(doc, {
      head: [tableColumn],
      body: tableRows,
      startY: 80,
      theme: "grid",
      styles: { fontSize: 8 },
      headStyles: { fillColor: [220, 220, 220], textColor: 0 }, // Gris clair avec texte noir
      alternateRowStyles: { fillColor: [245, 245, 245] }, // Gris très clair
    })

    // Si des étudiants ne sont pas soutenables, ajouter une section détaillée
    const nonSoutenables = this.etudiantsFiltres.filter((e) => !e.isSoutenable)
    if (nonSoutenables.length > 0) {
      // Récupérer la position Y après le tableau
      const finalY = (doc as any).lastAutoTable.finalY || 150

      doc.setFontSize(14)
      doc.text("Détails des étudiants non soutenables", 14, finalY + 10)

      let currentY = finalY + 20

      nonSoutenables.forEach((etudiant, index) => {
        // Vérifier s'il faut ajouter une nouvelle page
        if (currentY > doc.internal.pageSize.height - 40) {
          doc.addPage()
          currentY = 20
        }

        doc.setFontSize(12)
        doc.text(`${index + 1}. ${etudiant.nom} ${etudiant.prenom} (${etudiant.matricule})`, 14, currentY)
        currentY += 5

        // Raisons
        doc.setFontSize(10)
        etudiant.raisonNonSoutenable.forEach((raison) => {
          doc.text(`   - ${raison}`, 14, currentY)
          currentY += 5
        })

        // Détails des crédits et frais
        if (etudiant.creditsManquants > 0) {
          doc.text(`   • Crédits manquants: ${etudiant.creditsManquants}`, 14, currentY)
          currentY += 5
        }

        if (etudiant.fraisRestant > 0) {
          doc.text(`   • Frais restants: ${etudiant.fraisRestant.toLocaleString("fr-FR")} FCFA`, 14, currentY)
          currentY += 5
        }

        // Matières à rattraper
        if (etudiant.matieresARattraper.length > 0) {
          doc.text(`   • Matières à rattraper (${etudiant.matieresARattraper.length}):`, 14, currentY)
          currentY += 5

          etudiant.matieresARattraper.slice(0, 3).forEach((matiere) => {
            const annee = (matiere as any).anneeAcademique || etudiant.anneeInscription || "N/A"
            doc.text(`     * ${matiere.code} - ${matiere.nom} (${matiere.credit} crédits) - ${annee}`, 14, currentY)
            currentY += 5
          })

          if (etudiant.matieresARattraper.length > 3) {
            doc.text(`     * ... et ${etudiant.matieresARattraper.length - 3} autres matières`, 14, currentY)
            currentY += 5
          }
        }

        currentY += 5 // Espace entre les étudiants
      })
    }

    // Pied de page
    const pageCount = (doc as any).internal.pages.length
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i)
      doc.setFontSize(8)
      doc.text(`Page ${i} sur ${pageCount}`, doc.internal.pageSize.width / 2, doc.internal.pageSize.height - 10, {
        align: "center",
      })
      doc.text(
        "INTEC SUP - Gestion de la soutenabilité",
        doc.internal.pageSize.width / 2,
        doc.internal.pageSize.height - 5,
        { align: "center" },
      )
    }

    // Générer le PDF
    const fileName = `Soutenabilité_${this.selectedCycle}_${new Date().toISOString().split("T")[0]}.pdf`
    doc.save(fileName)
  }

  // Imprimer les détails d'un étudiant en PDF
  printStudentDetails(): void {
    if (!this.selectedStudent) return

    const doc = new jsPDF()

    // En-tête
    doc.setFontSize(18)
    doc.text("Fiche de soutenabilité", 14, 20)

    // Informations de l'étudiant
    doc.setFontSize(14)
    doc.text(`${this.selectedStudent.nom} ${this.selectedStudent.prenom}`, 14, 30)

    doc.setFontSize(12)
    doc.text(`Matricule: ${this.selectedStudent.matricule}`, 14, 40)
    doc.text(`Filière: ${this.selectedStudent.filiere}`, 14, 45)
    doc.text(`Année d'inscription: ${this.selectedStudent.anneeInscription}`, 14, 50)
    doc.text(`Niveau d'entrée: ${this.selectedStudent.niveauEntree || "Non défini"}`, 14, 55)

    // Résumé des crédits
    doc.setFontSize(14)
    doc.text("Résumé des crédits", 14, 65)

    doc.setFontSize(12)
    doc.text(`Crédits requis: ${this.selectedStudent.creditsRequis}`, 14, 75)
    doc.text(`Crédits obtenus: ${this.selectedStudent.creditsObtenus}`, 14, 80)
    doc.text(`Crédits manquants: ${this.selectedStudent.creditsManquants}`, 14, 85)

    // Résumé des frais
    doc.setFontSize(14)
    doc.text("Résumé des frais", 14, 95)

    doc.setFontSize(12)
    doc.text(`Frais scolaires: ${this.selectedStudent.fraisScolaire.toLocaleString("fr-FR")} FCFA`, 14, 105)
    doc.text(`Montant payé: ${this.selectedStudent.fraisPaye.toLocaleString("fr-FR")} FCFA`, 14, 110)
    doc.text(`Reste à payer: ${this.selectedStudent.fraisRestant.toLocaleString("fr-FR")} FCFA`, 14, 115)

    // Statut de soutenabilité
    doc.setFontSize(16)
    if (this.selectedStudent.isSoutenable) {
      doc.setTextColor(0, 128, 0) // Vert
      doc.text("SOUTENABLE", 14, 130)
      doc.setTextColor(0, 0, 0) // Noir
      doc.setFontSize(12)
      doc.text("Cet étudiant a validé tous les crédits nécessaires et payé tous ses frais.", 14, 140)
    } else {
      doc.setTextColor(255, 0, 0) // Rouge
      doc.text("NON SOUTENABLE", 14, 130)
      doc.setTextColor(0, 0, 0) // Noir
      doc.setFontSize(12)
      doc.text("Raisons:", 14, 140)

      let y = 145
      this.selectedStudent.raisonNonSoutenable.forEach((raison) => {
        doc.text(`- ${raison}`, 20, y)
        y += 5
      })

      // Détails supplémentaires sur les raisons
      y += 5
      if (this.selectedStudent.creditsManquants > 0) {
        doc.text(`Détail des crédits manquants: ${this.selectedStudent.creditsManquants} crédits à valider`, 20, y)
        y += 5
      }

      if (this.selectedStudent.fraisRestant > 0) {
        doc.text(
          `Détail des frais restants: ${this.selectedStudent.fraisRestant.toLocaleString("fr-FR")} FCFA à payer`,
          20,
          y,
        )
        y += 5
      }
    }

    // Matières à rattraper (si nécessaire)
    if (this.selectedStudent.matieresARattraper.length > 0) {
      doc.setFontSize(14)
      doc.text("Matières à rattraper", 14, 160)

      const tableColumn = ["Code", "Matière", "Semestre", "Année", "Crédits"]
      const tableRows: any[] = []

      this.selectedStudent.matieresARattraper.forEach((matiere) => {
        // Récupérer l'année académique de la matière (si disponible)
        const annee = (matiere as any).anneeAcademique || this.selectedStudent?.anneeInscription || "N/A"

        tableRows.push([matiere.code, matiere.nom, matiere.semestre?.libelle || "N/A", annee, matiere.credit || "0"])
      })

      // Utiliser autoTable
      autoTable(doc, {
        head: [tableColumn],
        body: tableRows,
        startY: 165,
        theme: "grid",
        styles: { fontSize: 8 },
        headStyles: { fillColor: [220, 220, 220], textColor: 0 }, // Gris clair avec texte noir
        alternateRowStyles: { fillColor: [245, 245, 245] }, // Gris très clair
      })
    }

    // Pied de page
    doc.setFontSize(10)
    doc.text(`Généré le ${this.currentDate}`, 14, doc.internal.pageSize.height - 20)
    doc.text("INTEC SUP - Gestion de la soutenabilité", 14, doc.internal.pageSize.height - 15)

    // Générer le PDF
    const fileName = `Soutenabilité_${this.selectedStudent.nom}_${this.selectedStudent.prenom}_${new Date().toISOString().split("T")[0]}.pdf`
    doc.save(fileName)
  }

  // Méthodes de chargement des données
  private loadAnnees(): void {
    this.anneeuvService
      .getAllAnnee()
      .pipe(
        timeout(this.REQUEST_TIMEOUT),
        catchError((error) => {
          console.error("Erreur lors du chargement des années:", error)
          this.errorMessage = "Erreur lors du chargement des années. Veuillez réessayer."
          return of([])
        }),
      )
      .subscribe({
        next: (data: Anneeuv[]) => {
          this.annees = data
          console.log(`${this.annees.length} années chargées`)
        },
        error: (error) => {
          console.error("Erreur lors du chargement des années:", error)
          this.errorMessage = "Erreur lors du chargement des années. Veuillez réessayer."
        },
      })
  }

  // Charger les filières en fonction du cycle sélectionné
  private loadFilieresByCycle(cycleId: number): void {
    this.isLoadingFilieres = true

    this.filiereService
      .getFiliereParCycle(cycleId)
      .pipe(
        timeout(this.REQUEST_TIMEOUT),
        catchError((error) => {
          console.error(`Erreur lors de la récupération des filières pour le cycle ${cycleId}:`, error)
          this.errorMessage = "Erreur lors de la récupération des filières."
          return of([]) // Retourner un tableau vide en cas d'erreur au lieu de générer des données de test
        }),
      )
      .subscribe({
        next: (filieres) => {
          console.log(`${filieres.length} filières récupérées pour le cycle ${cycleId}`)
          this.filieres = filieres
          this.isLoadingFilieres = false

          // Si aucune filière n'est trouvée, afficher un message
          if (filieres.length === 0) {
            this.errorMessage = `Aucune filière trouvée pour le cycle ${this.selectedCycle}.`
          }
        },
        error: (error) => {
          console.error(`Erreur lors de la récupération des filières pour le cycle ${cycleId}:`, error)
          this.errorMessage = "Erreur lors de la récupération des filières."
          this.isLoadingFilieres = false
        },
      })
  }

  // Méthode pour générer des données de test
  private generateTestData(anneeId: number, filiereId: number, coursId: number): void {
    console.log("Génération de données de test...")

    // Générer 10 étudiants de test
    const etudiants: EtudiantSoutenable[] = []

    for (let i = 1; i <= 10; i++) {
      // Déterminer aléatoirement la raison de non-soutenabilité
      const raisonAleatoire = Math.floor(Math.random() * 3) // 0: soutenable, 1: crédits insuffisants, 2: frais non soldés

      // Crédits requis selon le cycle
      const creditsRequis = this.selectedCycle === "LICENCE" ? 180 : 120

      // Crédits obtenus et frais selon la raison
      let creditsObtenus = creditsRequis
      let fraisPaye = 500000
      const fraisScolaire = 500000

      // Raisons de non-soutenabilité
      const raisonNonSoutenable: string[] = []

      // Matières à rattraper
      const matieresARattraper: Matieresup[] = []

      // Configurer selon la raison
      if (raisonAleatoire === 1) {
        // Crédits insuffisants
        creditsObtenus = Math.floor(Math.random() * (creditsRequis - 10)) + 10
        raisonNonSoutenable.push("Crédits insuffisants")

        // Générer des modules à rattraper
        const nbModules = Math.min(5, Math.floor(Math.random() * 5) + 1)
        let totalCredits = 0
        const creditsManquants = creditsRequis - creditsObtenus

        for (let j = 1; j <= nbModules; j++) {
          const creditRestant = creditsManquants - totalCredits
          const creditModule = Math.min(Math.floor(Math.random() * 6) + 1, creditRestant)

          if (creditModule <= 0) break

          totalCredits += creditModule

          const module = {
              id: `${i}-${j}`,
              code: `${this.selectedCycle === "LICENCE" ? "LIC" : "MAS"}${j}`,
              nom: `${this.selectedCycle === "LICENCE" ? "Licence" : "Master"} Module ${j}`,
              credit: creditModule,
              semestre: {
                id: j,
                libelle: `Semestre ${j}`,
                cycle: { id: this.selectedCycle === "LICENCE" ? 1 : 2, nom: this.selectedCycle },
              },
              ue: {
                id: j,
                code: `UE${j}`,
                nom: `Unité d'Enseignement ${j}`,
                typeue: { id: j, nom: `Type UE ${j}` },
              },
              filiere: {
                id: filiereId,
                nom: `Filière test`,
                description: `Description de la filière test`,
                cycle: { id: this.selectedCycle === "LICENCE" ? 1 : 2, nom: this.selectedCycle },
              },
            } as unknown as Matieresup
          ;(module as any).anneeAcademique = `20${22 + j}-20${23 + j}`
          matieresARattraper.push(module)
        }
      } else if (raisonAleatoire === 2) {
        // Frais non soldés
        fraisPaye = Math.floor(Math.random() * fraisScolaire)
        raisonNonSoutenable.push("Frais de scolarité non soldés")
      }

      // Créer l'étudiant
      const etudiant: EtudiantSoutenable = {
        id: i,
        matricule: `MAT${2023}${i.toString().padStart(3, "0")}`,
        nom: `Nom${i}`,
        prenom: `Prenom${i}`,
        anneeInscription: "2022-2023",
        filiere: `Filière Test ${this.selectedCycle}`,
        creditsRequis: creditsRequis,
        creditsObtenus: creditsObtenus,
        creditsManquants: creditsRequis - creditsObtenus,
        fraisScolaire: fraisScolaire,
        fraisPaye: fraisPaye,
        fraisRestant: fraisScolaire - fraisPaye,
        isSoutenable: raisonAleatoire === 0, // Soutenable uniquement si raisonAleatoire est 0
        matieresARattraper: matieresARattraper,
        raisonNonSoutenable: raisonNonSoutenable,
        niveauEntree: this.selectedCycle === "LICENCE" ? "L1" : "M1",
      }

      etudiants.push(etudiant)
    }

    // Mettre à jour les données
    this.etudiants = etudiants
    this.etudiantsFiltres = [...etudiants]
    this.calculerStatistiquesRaisons()
    this.showResults = true
    this.isLoading = false

    console.log(`${etudiants.length} étudiants de test générés.`)
  }

// Méthodes pour les filtres
  filtrerParStatut(statut: "tous" | "soutenable" | "non-soutenable"): void {
    this.filtreStatut = statut

    if (statut === "tous") {
      this.etudiantsFiltres = [...this.etudiants]
    } else if (statut === "soutenable") {
      this.etudiantsFiltres = this.etudiants.filter((e) => e.isSoutenable)
    } else {
      this.etudiantsFiltres = this.etudiants.filter((e) => !e.isSoutenable)
    }
  }

  filtrerParTexte(event: Event): void {
    const searchText = (event.target as HTMLInputElement).value.toLowerCase()

    if (!searchText) {
      this.etudiantsFiltres = [...this.etudiants]
      return
    }

    this.etudiantsFiltres = this.etudiants.filter(
      (etudiant) =>
        etudiant.nom.toLowerCase().includes(searchText) ||
        etudiant.prenom.toLowerCase().includes(searchText) ||
        etudiant.matricule.toLowerCase().includes(searchText),
    )
  }

// Méthodes utilitaires pour les statistiques
  countFilteredSoutenableStudents(): number {
    return this.etudiantsFiltres.filter((etudiant) => etudiant.isSoutenable).length
  }

  countFilteredNonSoutenableStudents(): number {
    return this.etudiantsFiltres.filter((etudiant) => !etudiant.isSoutenable).length
  }

  calculateSoutenabilityPercentage(): number {
    if (this.etudiantsFiltres.length === 0) {
      return 0
    }
    return Math.round((this.countFilteredSoutenableStudents() / this.etudiantsFiltres.length) * 100)
  }

// Méthodes pour les statistiques globales
  countSoutenableStudents(): number {
    return this.etudiants.filter((e) => e.isSoutenable).length
  }

  countNonSoutenableStudents(): number {
    return this.etudiants.filter((e) => !e.isSoutenable).length
  }

  calculateRaisonPercentage(count: number): string {
    const nonSoutenables = this.countNonSoutenableStudents()
    if (nonSoutenables === 0) return "0"
    return ((count / nonSoutenables) * 100).toFixed(1)
  }
}
