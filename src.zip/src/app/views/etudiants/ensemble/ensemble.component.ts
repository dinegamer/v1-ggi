import { Component, OnInit } from '@angular/core';
import { EtudiantService } from '../../../service/etudiant.service';
import { Etudiant } from '../../../model/etudiant.model';
import { CommonModule } from '@angular/common';
import $ from 'jquery';
import 'datatables.net';
import { User } from '../../../model/user.model';
import { AuthService } from '../../../service/auth.service';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-ensemble',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule
  ],
  templateUrl: './ensemble.component.html',
  styleUrl: './ensemble.component.scss'
})
export class EnsembleComponent implements OnInit{
  etudiants: Etudiant[] = []
  isLoading: boolean = true;
  user!: User;

  constructor(
    private etudiantService: EtudiantService,    
    private authService: AuthService,
  ){}

  ngOnInit(): void {
     this.loadData();
     this.user = this.authService.getUserFromLocalStorage();
  }
  loadData(): void {
    this.isLoading = true;
    
    // Simulation de chargement (remplacez par votre vrai appel API)
    setTimeout(() => {
      this.etudiantService.getEtudiants().subscribe({
        next: (data) => {
          this.etudiants = data;
          this.isLoading = false;
          setTimeout(() => {
            let table = $('#donnees').DataTable();
    
            if ($.fn.DataTable.isDataTable("#donnees")) {
              table.destroy();  // Détruit l'ancienne instance
            }
            ($('#donnees') as any).DataTable({
              paging: true,
              searching: true,
              ordering: true,
              info: true,
              lengthMenu: [
                  [10, 20, 50, -1], // Ajout de -1 pour "Tout"
                  [10, 20, 50, "Tout"] // Labels correspondants
              ],
              pageLength: 10,        // Nombre de lignes par défaut
              language: {
                search: "🔍 Rechercher :",
                lengthMenu: "Afficher _MENU_ entrées",
                info: "Affichage de _START_ à _END_ sur _TOTAL_ entrées",
                paginate: {
                  first: "⏪",
                  last: "⏩",
                  next: "▶",
                  previous: "◀"
                }}
            }); // Initialise DataTables après le rendu
          }, 100);
        },
        error: (error) => {
          console.error('Erreur de chargement', error);
          this.isLoading = false;
          // Gérer l'erreur ici (affichage message, etc.)
        }
      });
    }, 1000); // Retard artificiel pour voir le loader
  }
  getStudentPhoto(photoName: string): string {
    // Si la photo existe et n'est pas vide
    if (photoName && photoName.trim() !== '') {
      return `assets/images/etudiants/${photoName}`;
    }
    // Sinon retourne le logo par défaut
    return 'assets/images/logo.png';
  }
  editEtudiant(etudiant: Etudiant): void {
    console.log('Édition de', etudiant);
    // Implémentez votre logique d'édition ici
  }
  deleteEtudiant(id: number): void {
    if (confirm('Voulez-vous vraiment supprimer cet étudiant ?')) {
      this.etudiants = this.etudiants.filter(e => e.id !== id);
    }
  }
}
