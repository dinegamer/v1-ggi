import { Component, OnInit } from '@angular/core';
import { ButtonDirective, CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, FormControlDirective, FormDirective, FormLabelDirective, FormModule, RowComponent, TextColorDirective } from '@coreui/angular';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NgSelectModule } from '@ng-select/ng-select';
import { User } from '../../../model/user.model';
import { InscriptionService } from '../../../service/inscription.service';
import { Etudiant } from '../../../model/etudiant.model';
import { Filiere } from '../../../model/filiere.model';
import { FiliereService } from '../../../service/filiere.service';
import { AuthService } from '../../../service/auth.service';
import { Anneeuv } from '../../../model/anneeuv.model';
import { AnneeuvService } from '../../../service/anneeuv.service';
import jsPDF from 'jspdf';

@Component({
  selector: 'app-presence',
  standalone: true,
  imports: [
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent,
    ColComponent,
    RowComponent,
    ButtonDirective,
    RowComponent, 
    ColComponent, 
    TextColorDirective, 
    CardComponent, 
    CardHeaderComponent, 
    CardBodyComponent, 
    ReactiveFormsModule, 
    FormsModule, 
    FormDirective,  
    ButtonDirective, 
    CommonModule,
    ReactiveFormsModule,
    NgSelectModule
  ],
  templateUrl: './presence.component.html',
  styleUrl: './presence.component.scss'
})
export class PresenceComponent implements OnInit{

  inscrires: Etudiant[] = [];
  filieres: Filiere[] = [];
  annees: Anneeuv[] = [];
  cours = [
     {id:1, nom:'JOUR'},
     {id:2, nom:'SOIR'}
  ]
  user!: User;
  resultat: boolean = false
  selectedAnnee: Anneeuv | undefined
  selectedFiliere: Filiere | undefined
  selectedCours: any
  selectedSite: string | null | undefined
  dateDuJour: string | null | undefined

  ngOnInit(): void {
    this.getAllFiliere();
    this.getAllAnnee();
    this.user = this.authService.getUserFromLocalStorage();
  }

  constructor(
  private inscriptionService: InscriptionService, 
  private filiereService: FiliereService,
  private authService: AuthService,
  private anneeService: AnneeuvService
  ){}

  readonly mesRecherches = new FormGroup({   
    cours: new FormControl(""),
    filiere: new FormControl(""),
    annee: new FormControl("")
  });
  getAllAnnee(){
    this.anneeService.getAllAnnee().subscribe({
      next: (data) => {
        this.annees = data
      },
      error: (error) => {
        console.log("Erreur de connexion "+error)
      }
    })
  }
  getAllFiliere(){
    this.filiereService.getAllFilieres().subscribe(data =>{
      this.filieres = data
    })
  }

  RechercheEtudiant(){
    const donnees = this.mesRecherches.value
    let donnee = [
      donnees.annee,
      donnees.cours,
      donnees.filiere,
      this.user.administrateur.site.id
    ]
   
    this.selectedAnnee = this.annees.find(annee => annee.id === Number(donnees.annee));
    this.selectedFiliere = this.filieres.find(filiere => filiere.id === Number(donnees.filiere))
    this.selectedCours = this.cours.find(cour => cour.id === Number(donnees.cours))
    this.selectedSite = this.user.administrateur.site.nom
    //date du jour
    const today = new Date();
    const jour = String(today.getDate()).padStart(2, '0');
    const mois = String(today.getMonth() + 1).padStart(2, '0');
    const annee = today.getFullYear();
    this.dateDuJour = `${jour}/${mois}/${annee}`;

    this.inscriptionService.getListeParClasse(donnee).subscribe(data =>{
      this.inscrires = data.sort((a, b) => a.nom.localeCompare(b.nom));
      this.resultat = true
    })
    //console.log(this.inscrires+" mft ++")
  }
  generatePDF(){
    const doc = new jsPDF({
      orientation: 'landscape', // Orientation paysage pour plus d'espace
      unit: 'mm'
    });
    // Logo et en-tête
    this.addHeader(doc);
    // Informations sur la liste
    this.addListInfo(doc);
    // Tableau des présences
    this.addPresenceTable(doc);
    // Générer le PDF dans une nouvelle fenêtre
    const pdfBlob = doc.output('blob');
    const pdfUrl = URL.createObjectURL(pdfBlob);
    window.open(pdfUrl, '_blank');
    // Libérer la mémoire après l'ouverture
    setTimeout(() => {
      URL.revokeObjectURL(pdfUrl);
    }, 1000);
  }
  private addHeader(doc: jsPDF): void {
    // 1. Configuration des dimensions
    const marginLeft = 10;
    const imageWidth = 30;
    const imageHeight = 30;
    const spaceAfterImage = 10;
    
    // 2. Ajout du logo
    const imageUrl = 'assets/images/logo-v.png';
    const img = new Image();
    img.src = imageUrl;
    const imageY = 10;
    doc.addImage(img, 'PNG', marginLeft, imageY, imageWidth, imageHeight);

    // 3. Configuration typographique
    doc.setFont('Times', 'bold');
    doc.setFontSize(20);
    
    // 4. Calcul des positions avec interligne ajusté
    const lineHeight = 10; // Augmentation de l'interligne (7 → 8)
    const textBlockHeight = 2 * lineHeight; // Pour 3 lignes : (3-1)*lineHeight
    
    // Centrage vertical précis
    const textYStart = imageY + (imageHeight / 2) - (textBlockHeight / 2) + 2;
    
    // Centrage horizontal
    const pageWidth = doc.internal.pageSize.width;
    const textCenterX = marginLeft + imageWidth + spaceAfterImage + 
                       ((pageWidth - 2 * marginLeft - imageWidth - spaceAfterImage) / 2);

    // 5. Affichage du texte avec interligne optimal
    doc.text('INSTITUT SUPERIEUR DES TECHNIQUES', textCenterX, textYStart, { 
        align: 'center',
        lineHeightFactor: 1.2 // Facteur d'interligne supplémentaire
    });
    
    doc.text('ECONOMIQUES COMPTABLES ET COMMERCIALES', textCenterX, textYStart + lineHeight, {
        align: 'center'
    });
    
    doc.text('DUT - LICENCE - MASTER', textCenterX, textYStart + 2 * lineHeight, {
        align: 'center'
    });

    // 6. Ligne de séparation avec marge améliorée
    const separatorY = Math.max(imageY + imageHeight, textYStart + textBlockHeight) + 5;
    doc.setDrawColor(0);
    doc.setLineWidth(0.3);
    doc.line(marginLeft, separatorY, pageWidth - marginLeft, separatorY);
  }

  private addListInfo(doc: jsPDF) {
    doc.setFontSize(12);
    doc.text(`Liste de présence du ${this.dateDuJour} Filière: ${this.selectedFiliere?.description} Cours du: ${this.selectedCours?.nom} Site: ${this.selectedSite} Année: ${this.selectedAnnee?.nom}`, 10, 50);
  }

  private addPresenceTable(doc: jsPDF): void {
    interface TableHeader {
      label: string;
      ratio: number;
      _x?: number;
      _width?: number;
    }
  
    let startX = 10;
    let startY = 60;
    let cellHeight = 10;
  
    const pageHeight = doc.internal.pageSize.getHeight();
    const pageWidth = doc.internal.pageSize.getWidth();
    const usableWidth = pageWidth - startX * 2;
    const bottomMargin = 20;
  
    const headers: TableHeader[] = [
      { label: 'N°', ratio: 1 },
      { label: 'Matricule', ratio: 2 },
      { label: 'Nom', ratio: 3 },
      { label: 'Prénom', ratio: 3 },
      { label: 'Lundi', ratio: 2 },
      { label: 'Mardi', ratio: 2 },
      { label: 'Mercredi', ratio: 2 },
      { label: 'Jeudi', ratio: 2 },
      { label: 'Vendredi', ratio: 2 },
      { label: 'Samedi', ratio: 2 }
    ];
  
    const totalRatio = headers.reduce((sum, h) => sum + h.ratio, 0);
  
    const drawHeaders = (y: number) => {
      doc.setFont('Times', 'normal');
      doc.setFontSize(10);
      let currentX = startX;
      headers.forEach(header => {
        const colWidth = (header.ratio / totalRatio) * usableWidth;
        doc.rect(currentX, y, colWidth, cellHeight);
        doc.text(header.label, currentX + 2, y + 7);
        header._x = currentX;
        header._width = colWidth;
        currentX += colWidth;
      });
    };
  
    //let rowY = startY;
  
    //drawHeaders(rowY);
    //rowY += cellHeight;
  
    let startYInitial = 60;
    let startYNextPage = 20; // Pour les pages suivantes
    let rowY = startYInitial;
    
    drawHeaders(rowY);
    rowY += cellHeight;
    
    this.inscrires.forEach((row, i) => {
      // ➤ Si dépassement de page
      if (rowY + cellHeight > pageHeight - bottomMargin) {
        doc.addPage();
    
        // ➤ Réinitialiser Y pour les pages suivantes
        rowY = startYNextPage;
    
        drawHeaders(rowY);
        rowY += cellHeight;
      }
    
      let cellX = startX;
      headers.forEach((header, index) => {
        const colWidth = header._width!;
        let text = '';
        const isDayColumn = index >= 4; // à partir de Lundi
      
        if (!isDayColumn) {
          if (index === 0) text = '' + (i + 1);
          else if (index === 1) text = row.matricule;
          else if (index === 2) text = row.nom;
          else if (index === 3) text = row.prenom;
      
          doc.rect(cellX, rowY, colWidth, cellHeight);
          doc.text(text, cellX + 2, rowY + 7);
        } else {
          const demiCol = colWidth / 2;
          doc.rect(cellX, rowY, demiCol, cellHeight);
          doc.text(" ", cellX + 2, rowY + 7); // ou vide à cocher
      
          doc.rect(cellX + demiCol, rowY, demiCol, cellHeight);
          doc.text(" ", cellX + demiCol + 2, rowY + 7);
        }
      
        cellX += colWidth; // avance pour la prochaine cellule
      });
      
      rowY += cellHeight;
    });
    
  }
  
}
