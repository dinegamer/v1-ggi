import { Component, OnInit } from '@angular/core';
import { Anneeuv } from '../../model/anneeuv.model';
import { Filiere } from '../../model/filiere.model';
import { NgSelectModule } from '@ng-select/ng-select';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AnneeuvService } from '../../service/anneeuv.service';
import { FiliereService } from '../../service/filiere.service';
import { User } from '../../model/user.model';
import { AuthService } from '../../service/auth.service';
import { InscriptionService } from '../../service/inscription.service';
import { Etudiant } from '../../model/etudiant.model';
import { NombreEtudiantParFiliere } from '../../donnees/NombreEtudiantParFiliere';
import { NgxPaginationModule, PaginationInstance } from 'ngx-pagination';

@Component({
  selector: 'app-etudiants',
  standalone: true,
  imports: [
    NgSelectModule,
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent, 
    ColComponent,
    RowComponent,
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    NgxPaginationModule,
    FormsModule
  ],
  templateUrl: './etudiants.component.html',
  styleUrls: ['./etudiants.component.scss']
})
export class EtudiantsComponent implements OnInit {
  inscrires: Etudiant[] = [];
  filteredInscrires: Etudiant[] = [];
  searchText: string = '';
  filieres: Filiere[] = [];
  roleActuel!: string;
  annees: Anneeuv[] = [];
  cours = [
    {id: 1, nom: 'JOUR'},
    {id: 2, nom: 'SOIR'}
  ];
  user!: User;
  resultat = false;
  nombreparfilieres: NombreEtudiantParFiliere[] = [];
  defaultLogoUrl = '../../../../assets/images/logo-v.png';
  
  // Configuration de la pagination
  public config: PaginationInstance = {
    id: 'custom',
    itemsPerPage: 10,
    currentPage: 1
  };

  readonly mesRecherches = new FormGroup({   
    cours: new FormControl(""),
    filiere: new FormControl(""),
    annee: new FormControl("")
  });

  constructor(
    private inscriptionService: InscriptionService, 
    private filiereService: FiliereService,
    private authService: AuthService,
    private anneeuvService: AnneeuvService
  ) {}

  ngOnInit(): void {
    this.getAllFiliere();
    this.getAllAnnee();
    this.user = this.authService.getUserFromLocalStorage();
    this.roleActuel = this.user.administrateur.role.nom;
    this.filteredInscrires = [...this.inscrires];
  }

  // Méthode de recherche
  applyFilter(): void {
    if (!this.searchText) {
      this.filteredInscrires = [...this.inscrires];
      return;
    }

    const searchTerm = this.searchText.toLowerCase();
    this.filteredInscrires = this.inscrires.filter(inscris => 
      inscris.matricule?.toLowerCase().includes(searchTerm) ||
      inscris.nom?.toLowerCase().includes(searchTerm) ||
      inscris.prenom?.toLowerCase().includes(searchTerm) ||
      inscris.telephone?.toLowerCase().includes(searchTerm)
    );
    
    this.config.currentPage = 1;
  }

  // Changer le nombre d'éléments par page
  changeItemsPerPage(itemsPerPage: number): void {
    this.config.itemsPerPage = itemsPerPage;
    this.config.currentPage = 1;
  }

  // Calcul du maximum pour les barres de progression
  get maxEtudiants(): number {
    return Math.max(...this.nombreparfilieres.map(x => x.nombreEtudiant), 0);
  }

  // Méthode utilitaire pour afficher la plage d'éléments
  getDisplayRange(): string {
    const start = (this.config.currentPage - 1) * this.config.itemsPerPage + 1;
    const end = Math.min(this.config.currentPage * this.config.itemsPerPage, this.filteredInscrires.length);
    return `Affichage de ${start} à ${end} sur ${this.filteredInscrires.length} éléments`;
  }

  getAllAnnee(): void {
    this.anneeuvService.getAllAnnee().subscribe({
      next: (data) => {
        this.annees = data;
      },
      error: (error) => {
        console.error("Erreur de connexion à la base de données", error);
      }
    });
  }

  getAllFiliere(): void {
    this.filiereService.getAllFilieres().subscribe({
      next: (data) => {
        this.filieres = data;
      },
      error: (error) => {
        console.error("Erreur lors de la récupération des filières", error);
      }
    });
  }

  RechercheEtudiant(): void {
    const donnees = this.mesRecherches.value;
    const donnee = [
      donnees.annee,
      donnees.cours,
      donnees.filiere,
      this.user.administrateur.site.id
    ];
    
    this.inscriptionService.getListeParClasse(donnee).subscribe({
      next: (data) => {
        this.inscrires = data;
        this.filteredInscrires = [...data];
        this.resultat = true;
        this.config.currentPage = 1;
      },
      error: (error) => {
        console.error("Erreur lors de la recherche des étudiants", error);
      }
    });
  }

  getStudentPhotoUrl(photoName: string): string {
    return `../../../../assets/images/etudiants/${photoName}`;
  }
  
  handleImageError(event: Event): void {
    const imgElement = event.target as HTMLImageElement;
    imgElement.src = this.defaultLogoUrl;
    imgElement.classList.add('default-image-style');
  }
}