import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { InscriptionService } from '../../../service/inscription.service';
import { Inscrire } from '../../../model/inscription.model';
import { Etudiant } from '../../../model/etudiant.model';
import { Fraixscolaire } from '../../../model/fraixscolaire.model';
import { Paiement } from '../../../model/paiement.model';
import { EtudiantService } from '../../../service/etudiant.service';
import { CommonModule } from '@angular/common';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { User } from '../../../model/user.model';
import { AuthService } from '../../../service/auth.service';
@Component({
  selector: 'app-detail',
  standalone: true,
  imports: [
    CommonModule,
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent, 
    ColComponent,
    RowComponent,
    RouterModule
  ],
  templateUrl: './detail.component.html',
  styleUrl: './detail.component.scss'
})
export class DetailComponent implements OnInit {
  etudiantId!: number
  anneeId!: number
  etudiant!: Etudiant
  inscrires: Inscrire[] = []
  inscrire!: Inscrire
  frais: Fraixscolaire[] = []
  paies: Paiement[] = []
  user!: User
  dateFormatee!: string
  isLoaded: boolean = false;

  constructor(
    private route: ActivatedRoute,
    private etudiantService: EtudiantService,
    private inscrireService: InscriptionService,
    private authService: AuthService
  ) {}

  ngOnInit(): void { 
    this.etudiantId = Number(this.route.snapshot.paramMap.get('id'));
    this.anneeId = Number(this.route.snapshot.paramMap.get('annee'));
   
    this.user = this.authService.getUserFromLocalStorage()
    //date 
    const aujourdHui = new Date();
    const datePlusUnAn = new Date(aujourdHui);
    datePlusUnAn.setFullYear(datePlusUnAn.getFullYear() + 1);

    const jour = String(datePlusUnAn.getDate()).padStart(2, '0');
    const mois = String(datePlusUnAn.getMonth() + 1).padStart(2, '0'); // Mois commence à 0
    const annee = datePlusUnAn.getFullYear();

    const dateFormate = `${jour}/${mois}/${annee}`;
    this.dateFormatee = dateFormate
    this.loadData()
  }
  loadData() {
    this.etudiantService.getEtudiantById(this.etudiantId).subscribe({
      next: (dataEtudiant) => {
        this.etudiant = dataEtudiant;
  
        this.inscrireService.getAllInscrireEtudiant(this.etudiantId).subscribe({
          next: (dataInscrires) => {
            this.inscrires = dataInscrires;
            this.inscrire = this.inscrires.find(ins => ins.anneeuv && ins.anneeuv.id === this.anneeId)!;
            
            // Date formattée
            const aujourdHui = new Date();
            const datePlusUnAn = new Date(aujourdHui);
            datePlusUnAn.setFullYear(datePlusUnAn.getFullYear() + 1);
            const jour = String(datePlusUnAn.getDate()).padStart(2, '0');
            const mois = String(datePlusUnAn.getMonth() + 1).padStart(2, '0');
            const annee = datePlusUnAn.getFullYear();
            this.dateFormatee = `${jour}/${mois}/${annee}`;
  
            // ✅ Tout est chargé
            this.isLoaded = true;
          }
        });
      }
    });
  }
}
