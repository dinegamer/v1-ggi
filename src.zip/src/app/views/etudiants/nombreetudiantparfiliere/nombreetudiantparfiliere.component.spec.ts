import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NombreetudiantparfiliereComponent } from './nombreetudiantparfiliere.component';

describe('NombreetudiantparfiliereComponent', () => {
  let component: NombreetudiantparfiliereComponent;
  let fixture: ComponentFixture<NombreetudiantparfiliereComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [NombreetudiantparfiliereComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(NombreetudiantparfiliereComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
