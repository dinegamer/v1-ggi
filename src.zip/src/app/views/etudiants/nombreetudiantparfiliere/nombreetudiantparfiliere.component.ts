import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { InscriptionService } from '../../../service/inscription.service';
import { AuthService } from '../../../service/auth.service';
import { User } from '../../../model/user.model';
import { NombreEtudiantParFiliere } from '../../../donnees/NombreEtudiantParFiliere';

@Component({
  selector: 'app-nombreetudiantparfiliere',
  standalone: true,
  imports: [
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent, 
    ColComponent,
    RowComponent,
    CommonModule,
  ],
  templateUrl: './nombreetudiantparfiliere.component.html',
  styleUrl: './nombreetudiantparfiliere.component.scss'
})
export class NombreetudiantparfiliereComponent implements OnInit{
  user!: User;
  nombreparfilieres: NombreEtudiantParFiliere[] = []
  //init
  ngOnInit(): void {
    this.user = this.authService.getUserFromLocalStorage()
    this.EtudiantParFiliere()
  }
  //constructeur
  constructor(
    private authService: AuthService,
    private inscrire: InscriptionService
  ){}
  // Calcul du maximum pour les barres de progression
  get maxEtudiants(): number {
    return Math.max(...this.nombreparfilieres.map(x => x.nombreEtudiant));
  }
  //rechercher le nombre par filiere
  EtudiantParFiliere(){
    this.inscrire.getNombreEtudiantParFiliere(this.user.parametre.anneepardefaut.id,this.user.administrateur.site.id).subscribe({
      next: (data) => {
        this.nombreparfilieres = data
      }
    })
  }
}
