import { Component, OnInit } from '@angular/core';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { InscriptionService } from '../../../service/inscription.service';
import { NombreEtudiantParSite } from '../../../donnees/NombreEtudiantParSite';
import { CommonModule } from '@angular/common';
import { Site } from '../../../model/site.model';
import { Anneeuv } from '../../../model/anneeuv.model';
import { User } from '../../../model/user.model';
import { AuthService } from '../../../service/auth.service';
@Component({
  selector: 'app-nombreetudiantparcycle',
  standalone: true,
  imports: [
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent,
    ColComponent,
    RowComponent,
    CommonModule
  ],
  templateUrl: './nombreetudiantparcycle.component.html',
  styleUrl: './nombreetudiantparcycle.component.scss'
})
export class NombreetudiantparcycleComponent implements OnInit {
  site!: Site
  an!: Anneeuv
  user!: User
  nombreEtudiantParSite!: NombreEtudiantParSite

  constructor(
    private inscriptionService: InscriptionService,
    private authService: AuthService
  ){}

  ngOnInit(): void {
    this.getNombreEtudiantParSite()    
  }

  getNombreEtudiantParSite(){
    this.user = this.authService.getUserFromLocalStorage()
    this.site = this.user.administrateur.site
    this.an = this.user.parametre.anneepardefaut
    this.inscriptionService.getNombreEtudiantParSite(this.an.id, this.site.id).subscribe(data =>{
      this.nombreEtudiantParSite = data
    })
  }
}
 