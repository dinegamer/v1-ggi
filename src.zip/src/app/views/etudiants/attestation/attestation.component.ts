import { Component } from '@angular/core';
import { Etudiant } from '../../../model/etudiant.model';
import { ActivatedRoute } from '@angular/router';
import { EtudiantService } from '../../../service/etudiant.service';
import { InscriptionService } from '../../../service/inscription.service';
import { Inscrire } from '../../../model/inscription.model';
import { AuthService } from '../../../service/auth.service';
import { User } from '../../../model/user.model';
import { CommonModule } from '@angular/common';
import { jsPDF } from 'jspdf';

@Component({
  selector: 'app-attestation',
  standalone: true,
  imports: [
    CommonModule
  ],
  templateUrl: './attestation.component.html',
  styleUrl: './attestation.component.scss'
})
export class AttestationComponent {
  etudiantId!: number
  etudiant!:  Etudiant
  inscrires: Inscrire[] = []
  inscrire!: Inscrire
  user!: User
  dateDuJour: string = '';
  nomSignateur: string = '';
  roleSignateur: string = '';

  ngOnInit(): void {
    this.etudiantId = Number(this.route.snapshot.paramMap.get('id'));
    this.user = this.authService.getUserFromLocalStorage();
    if (this.user && this.user.administrateur.site.id) {
      this.signateur();
    } else {
      alert('Utilisateur ou site manquant au chargement');
    }
    this.getEtudiant()
    this.getAllInscrireEtudiant()
    // Initialiser la date du jour
    const today = new Date();
    const jour = String(today.getDate()).padStart(2, '0');
    const mois = String(today.getMonth() + 1).padStart(2, '0'); // les mois commencent à 0
    const annee = today.getFullYear();

    this.dateDuJour = `${jour}/${mois}/${annee}`;
    
  }

  constructor(
    private route: ActivatedRoute,
    private etudiantService: EtudiantService,
    private inscrireService: InscriptionService,
    private authService: AuthService
  ){}
  //Recherche du signateur
  signateur(){
    if (!this.user || !this.user.administrateur.site.id) {
      console.warn('Utilisateur ou site non défini');
      return;
    }
  
    switch (this.user.administrateur.site.id) {
      case 1:
        this.nomSignateur = 'Docteur Khalid DEMBELE';
        this.roleSignateur = 'Secrétaire Général';
        break;
      case 2:
        this.nomSignateur = 'Monsieur Salif COULIBALY';
        this.roleSignateur = 'Directeur des Etudes';
        break;
      case 3:
        this.nomSignateur = 'Monsieur Daouda DIAKITE';
        this.roleSignateur = 'Directeur des Etudes';
        break;
      default:
        this.nomSignateur = 'Inconnu';
        this.roleSignateur = 'Rôle non défini';
        break;
    }
  }
  //retrouver l'etudiant
  getEtudiant(){
    this.etudiantService.getEtudiantById(this.etudiantId).subscribe({
      next: (data) =>{this.etudiant = data}
    })
  }
  //les inscription d'un etuaint
  getAllInscrireEtudiant(){
    this.inscrireService.getAllInscrireEtudiant(this.etudiantId).subscribe({
      next: (data) =>{
        this.inscrires = data

        if (this.user && this.user.parametre?.anneepardefaut?.id) {
          this.inscrire = this.inscrires.find(
            inscription => inscription.anneeuv.id === this.user.parametre.anneepardefaut.id
          )!;
        }
      }
    })
  }
  printAttestation(): void {
    const imageUrl = 'assets/images/logo-v.png';
    const img = new Image();
    img.src = imageUrl;
        
    const doc = new jsPDF();
    doc.addImage(img,'PNG', 10, 5, 35, 35);
    // Taille de la page
    const pageWidth = doc.internal.pageSize.getWidth();
    // Coordonnée Y de départ pour le texte
    const yStart = 12;
    const lineHeight = 15; // ← tu peux ajuster ici l’interligne
    // Texte à centrer à droite de l’image
    doc.setFont("Times", "bold");
    doc.setFontSize(14);
    doc.text('INSTITUT SUPÉRIEUR DES TECHNIQUES', pageWidth / 2 + 20, yStart, { align: 'center' });
    doc.text('ÉCONOMIQUES COMPTABLES ET COMMERCIALES', pageWidth / 2 + 20, yStart + lineHeight, { align: 'center' });
    doc.text('DUT – LICENCE – MASTER', pageWidth / 2 + 20, yStart + lineHeight * 2, { align: 'center' });
    //le contenue 
    doc.setFont("Times", "normal");
    doc.setFontSize(14);
    doc.text('ATTESTATION D\'INSCRIPTION', 70,65)
    doc.setFont("Times", "normal");
    doc.setFontSize(12);
    doc.text('Je soussigné, '+this.nomSignateur+', le '+this.roleSignateur+' de l\'Institut Supérieur des Techniques',10,85)
    doc.text('Economiques, Comptables et Commerciales (INTEC SUP) atteste par la présente que :',10,100)
    doc.text('M/Mlle/Mme. '+ this.etudiant.nom+' '+this.etudiant.prenom+' , né(e) le '+this.etudiant.naissance,10,115)
    doc.text('Fils/Fille de : '+this.etudiant.prenompere+' et de '+this.etudiant.prenommere+' '+this.etudiant.nommere,10,130)
    doc.text('Nationalité : '+this.etudiant.nationalite,10,145)
    doc.text('Est inscrit(e) à l\'INTEC SUP sous le N° Matricule : '+this.etudiant.matricule+' Cycle : '+this.inscrire.filiere.cycle.nom,10,160)
    doc.text('Filière : '+this.inscrire.filiere.description,10,175)
    doc.text('Au titre de l\'année universitaire : '+this.inscrire.anneeuv.nom,10,190)
    doc.text('En foi de quoi la présente attestation est délivrée pour servir et valoir ce que de droit.',10,205)
    
    doc.text('Fait à Bamako, le '+this.dateDuJour,120,220)

    doc.setFont("Times", "bold");
    doc.setFontSize(12);
    doc.text(this.roleSignateur,123,230)
    doc.text(this.nomSignateur,120,250)    
    doc.text('NB : Il n\'est délivré qu\'un seul exemplaire de cette attestation',10,265)

    doc.setFont("Times", "normal");
    doc.setFontSize(9);
    const text1 = 'Hamdallaye ACI 2000 PB : E5671, du monument « Bougie Ba » vers Sébénicoro 44 38 28 02 / 68 88 02 02 / 78 88 02 02';
    const text2 = 'www.intec-sup.com | intecsup@intec-sup.com';

    const textWidth1 = doc.getTextWidth(text1);
    const textWidth2 = doc.getTextWidth(text2);

    doc.text(text1, (pageWidth - textWidth1) / 2, 280);
    doc.text(text2, (pageWidth - textWidth2) / 2, 285);
    // Générer le blob
    const blob = doc.output('blob');
    // Créer une URL temporaire
    const blobUrl = URL.createObjectURL(blob);
    // Ouvrir dans un nouvel onglet
    window.open(blobUrl, '_blank');
  }

  
}
