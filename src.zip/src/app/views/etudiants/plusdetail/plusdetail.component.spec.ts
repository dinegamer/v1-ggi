import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlusdetailComponent } from './plusdetail.component';

describe('PlusdetailComponent', () => {
  let component: PlusdetailComponent;
  let fixture: ComponentFixture<PlusdetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PlusdetailComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PlusdetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
