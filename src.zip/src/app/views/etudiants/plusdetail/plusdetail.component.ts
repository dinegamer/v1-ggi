import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { Inscrire } from '../../../model/inscription.model';
import { ActivatedRoute } from '@angular/router';
import { InscriptionService } from '../../../service/inscription.service';
import { FraixscolaireService } from '../../../service/fraixscolaire.service';
import { Fraixscolaire } from '../../../model/fraixscolaire.model';
import { Paiement } from '../../../model/paiement.model';
import { PaiementService } from '../../../service/paiement.service';

@Component({
  selector: 'app-plusdetail',
  standalone: true,
  imports: [
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent, 
    ColComponent,
    RowComponent,
    CommonModule,
  ],
  templateUrl: './plusdetail.component.html',
  styleUrl: './plusdetail.component.scss'
})
export class PlusdetailComponent implements OnInit {
  id!: number;
  inscrires: Inscrire[] = []
  frais: Fraixscolaire[] = []
  paiements: Paiement[] = []

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      this.id = Number(params.get('id'));
      this.getAllInscrireEtudiant(this.id);
      this.getAllfraisetudiant(this.id);
      this.getAllPaies(this.id);
    });
  }

  constructor(
    private route: ActivatedRoute,
    private inscrireService: InscriptionService,
    private fraisService: FraixscolaireService,
    private paiementService: PaiementService
  ){}
  //les paiements 
  getAllPaies(id: number){
    this.paiementService.getPaieDeEtudiant(id).subscribe({
      next: (data) =>{ this.paiements = data }
    })
  }
  //les inscription
  getAllInscrireEtudiant(id: number){
    this.inscrireService.getAllInscrireEtudiant(id).subscribe({
      next: (data) =>{ this.inscrires =  data }
    });
  }
  //les frais
  getAllfraisetudiant(id: number){
    this.fraisService.fraisetudiant(id).subscribe({
      next: (data) =>{ this.frais = data},
      error: (error) =>{console.log("Erreur !!!"+error)}
    })
  }

}
