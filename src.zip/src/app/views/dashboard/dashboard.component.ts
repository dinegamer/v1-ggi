
import { AuthService } from '../../service/auth.service';
import { User } from '../../model/user.model';
import { Component, OnInit } from '@angular/core';
import { CardBodyComponent, CardComponent, CardFooterComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { CommonModule } from '@angular/common';
import { NgSelectModule } from '@ng-select/ng-select';
import { Anneeuv } from '../../model/anneeuv.model';
import { AnneeuvService } from '../../service/anneeuv.service';
import { RouterModule } from '@angular/router';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DashboardService } from '../../service/dashboard.service';
import { Site } from '../../model/site.model';
import { SiteService } from '../../service/site.service';
import { Tableaudebord } from '../../model/tableaudebord.model';

@Component({
  templateUrl: 'dashboard.component.html',
  styleUrls: ['dashboard.component.scss'],
  standalone: true,
  imports: [
  CardBodyComponent,
  CardFooterComponent,
  CardHeaderComponent,
  CardComponent,
  RowComponent,
  CommonModule,
  ColComponent,
  RouterModule,
  ReactiveFormsModule,
  NgSelectModule,
  FormsModule
  ]
})
export class DashboardComponent implements OnInit {
  tableaudebord!: Tableaudebord
  user!: User
  roleActuel!: string
  sites: Site[] = []
  annees: Anneeuv[] = []
  isLoading: boolean = false
  tdbdroit: boolean = false
  annee = new FormControl()
  site = new FormControl()
  selectedAnnee: number | null = null;
  selectedSite: number | null = null;

  constructor(
    private authService: AuthService,
    private anneeService: AnneeuvService,
    private dashboardService: DashboardService,
    private siteService: SiteService
  ){  }  

  ngOnInit(): void {
    this.user = this.authService.getUserFromLocalStorage()
    this.getAllAnnee() 
    this.getAllSite()
    this.annee.setValue(this.user.parametre.anneepardefaut.id) 
    this.site.setValue(this.user.administrateur.site.id) 
    this.roleActuel = this.user.administrateur.role.nom   
    if(this.roleActuel == 'DE'){
      this.selectedSite = this.user.administrateur.site.id
    }
  }
  onSubmit(form: any) {
    if (form.valid) {
      console.log('Année sélectionnée:', this.selectedAnnee);
      console.log('Site sélectionné:', this.selectedSite);
      this.TableaudeBordDG();
    }
  }

  getAllSite(){
    this.siteService.getAllSite().subscribe({
      next: (data) =>{
        this.sites = [{ id: 0, nom: 'Ensemble des sites', adresse:'',  signature:'', titre:'', responsable:'', ecole:{idEcole:0,
             nomEcole:'',  descriptionEcole:'', adresseEcole:'', categorie:{id:0,nom:''}} }, ...data]
      },
      error: (error) =>{
        console.log(error+"mdt")
      }
    })
  }
  getAllAnnee(){
    this.anneeService.getAllAnnee().subscribe({
      next: (data) =>{
        this.annees = data
      },
      error: (error) =>{
        console.log(error+"mdt")
      }
    })
  }
  TableaudeBordDG(){   
    this.isLoading = true 
    if(this.selectedSite !== 0){
      this.dashboardService.gettableaudebord(this.selectedAnnee, this.selectedSite).subscribe({
        next: (response) =>{
          this.isLoading = false
          this.tableaudebord = response
        },
        error: (error) =>{
          alert("Erreur de chargement des données !!"+error)
        }
      })
   }else{
    this.dashboardService.TableaudebordTotal(this.selectedAnnee).subscribe({
      next: (response) =>{
        this.isLoading = false
        this.tableaudebord = response
      },
      error: (error) =>{
        alert("Erreur de chargement des données !!"+error)
      }
    })
   }
  }
  getPercentageColor(value: number): string {
    if (value >= 100) return 'success';
    if (value >= 80) return 'info';
    if (value >= 50) return 'warning';
    return 'danger';
  }

}
