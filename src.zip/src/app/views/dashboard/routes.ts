import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    data: {
      title: 'Dashboard'
    },
    children: [
      {
        path: '',
        redirectTo: 'dashboard',
        pathMatch: 'full',
      },
      {
        path: 'dashboard',
        loadComponent: () => import('./dashboard.component').then(m => m.DashboardComponent),
        data: {
          title: `Tableau de bord`
        }
      },
      {
        path: 'detailsite',
        loadComponent: () => import('./detailsite/detailsite.component').then(m => m.DetailsiteComponent),
        data: {
          title: `Detail Par Site`
        }
      },
      {
        path: 'detailsites',
        loadComponent: () => import('./detailsites/detailsites.component').then(m => m.DetailsitesComponent),
        data: {
          title: `Detail Pour les sites`
        }
      }
    ]
  }
];

