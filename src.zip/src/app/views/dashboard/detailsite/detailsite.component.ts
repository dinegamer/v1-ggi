import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../service/auth.service';
import { User } from '../../../model/user.model';
import { DashboardService } from '../../../service/dashboard.service';
import { Tableaudebord } from '../../../model/tableaudebord.model';

import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { CommonModule } from '@angular/common';
import { TableauDeBordSite } from '../../../dto/tableaudebordsite.dto';

@Component({
  selector: 'app-detailsite',
  standalone: true,
  imports: [
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent, 
    ColComponent,
    RowComponent,
    CommonModule,
    RouterModule,
    ReactiveFormsModule
  ],
  templateUrl: './detailsite.component.html',
  styleUrl: './detailsite.component.scss'
})
export class DetailsiteComponent implements OnInit{
  user!: User
  isLoading: boolean = false
  tableaudebords: TableauDeBordSite[] = []
  selectedAnnee: number | null = null;
  selectedSite: number | null = null;

  totalEtudiants: number = 0;
  totalFrais: number = 0;
  totalReductions: number = 0;
  totalPayes: number = 0;
  totalReliquats: number = 0;
  totalReliquatsPayes: number = 0;

  ngOnInit(): void {
    this.user = this.authService.getUserFromLocalStorage()
    this.tableaudeboard()
  }

  constructor(
    private authService: AuthService,
    private dashboardService: DashboardService,
  ){}

  tableaudeboard(){
    this.selectedAnnee = this.user.parametre.anneepardefaut.id
    this.selectedSite = this.user.administrateur.site.id
    this.dashboardService.gettableaudebordsite(this.selectedAnnee, this.selectedSite).subscribe({
      next: (response) =>{
        this.isLoading = false
        this.tableaudebords = response
      },
      error: (error) =>{
        alert("Erreur de chargement des données !!"+error)
      }
    })
  }

} 
