import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailsitesComponent } from './detailsites.component';

describe('DetailsitesComponent', () => {
  let component: DetailsitesComponent;
  let fixture: ComponentFixture<DetailsitesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DetailsitesComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DetailsitesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
