import { Component } from '@angular/core';

@Component({
  selector: 'app-detailsites',
  standalone: true,
  imports: [],
  templateUrl: './detailsites.component.html',
  styleUrl: './detailsites.component.scss'
})
export class DetailsitesComponent {

}
