import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { Cycle } from 'src/app/model/cycle.model';
import { Departement } from 'src/app/model/departement.model';
import { Filiere } from 'src/app/model/filiere.model';
import { CycleService } from 'src/app/service/cycle.service';
import { DepartementService } from 'src/app/service/DepartementService';
import { FiliereService } from 'src/app/service/filiere.service';

@Component({
  selector: 'app-filiere',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './filiere.component.html',
  styleUrl: './filiere.component.scss'
})
export class FiliereComponent implements OnInit {
  filieres: Filiere[] = [];
  currentFiliere: Filiere = {
    nom: '',
    description: '',
    cycle: { id: 0, nom: '' },
    departement: { id: 0, nom: '' }
  };
  isEditing = false;
  cycles: Cycle[] = [];
  departements: Departement[] = [];

  constructor(
    private filiereService: FiliereService,
    private cycleService: CycleService,
    private departementService: DepartementService
  ) {}

  ngOnInit(): void {
    this.loadAll();
  }
  cancelEdit(): void {
    this.isEditing = false;
    this.currentFiliere = {
      nom: '',
      description: '',
      cycle: { id: 0, nom: '' },
      departement: { id: 0, nom: '' }
    };
  }

  loadAll() {
    this.filiereService.getAllFilieres().subscribe(data => this.filieres = data);
    this.cycleService.getAllCycle().subscribe(data => this.cycles = data);
    this.departementService.getAll().subscribe(data => this.departements = data);
  }

  saveOrUpdate() {
    const request = this.isEditing
      ? this.filiereService.update(this.currentFiliere)
      : this.filiereService.save(this.currentFiliere);
    
    request.subscribe(() => {
      this.loadAll();
      this.resetForm();
    });
  }

  edit(filiere: Filiere) {
    this.currentFiliere = { ...filiere };
    this.isEditing = true;
  }

  delete(id: number) {
    this.filiereService.delete(id).subscribe(() => this.loadAll());
  }

  resetForm() {
    this.currentFiliere = {
      nom: '',
      description: '',
      cycle: { id: 0, nom: '' },
      departement: { id: 0, nom: '' }
    };
    this.isEditing = false;
  }
}
