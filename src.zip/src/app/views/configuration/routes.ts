import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    data: {
      title: 'Configuration'
    },
    children: [  
      {
        path: '',
        loadComponent: () => import('../configuration/configuration.component').then(m => m.ConfigurationComponent),
        data: {
          title: 'Gestion des Configurations'
        }
      },    
      {
        path: 'anneeuv',
        loadComponent: () => import('../configuration/anneeuv/anneeuv.component').then(m => m.AnneeuvComponent),
        data: {
          title: 'Année UV'
        }
      },{
        path: 'categorie',
        loadComponent: () => import('../configuration/categorie/categorie.component').then(m => m.CategorieComponent),
        data: {
          title: 'Catégorie'
        }
      },
      {
        path: 'role',
        loadComponent: () => import('../configuration/role/role.component').then(m => m.RoleComponent),
        data: {
          title: 'Role'
        }
      },
      {
        path: 'site',
        loadComponent: () => import('../configuration/site/site.component').then(m => m.SiteComponent),
        data: {
          title: 'Site'
        }
      },
      {
        path: 'filiere',
        loadComponent: () => import('../configuration/filiere/filiere.component').then(m => m.FiliereComponent),
        data: {
          title: 'Filiere'
        }
      },
      {
        path: 'cycle',
        loadComponent: () => import('../configuration/cycle/cycle.component').then(m => m.CycleComponent),
        data: {
          title: 'Cycle'
        }
      },
      {
        path: 'departement',
        loadComponent: () => import('../configuration/departement/departement.component').then(m => m.DepartementComponent),
        data: {
          title: 'Departement'
        }
      },      
      {
        path: 'ecole',
        loadComponent: () => import('../configuration/ecole/ecole.component').then(m => m.EcoleComponent),
        data: {
          title: 'Ecole'
        }
      }
    ]
  }
];
