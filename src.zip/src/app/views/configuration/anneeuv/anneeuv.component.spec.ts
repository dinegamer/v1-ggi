import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AnneeuvComponent } from './anneeuv.component';

describe('AnneeuvComponent', () => {
  let component: AnneeuvComponent;
  let fixture: ComponentFixture<AnneeuvComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AnneeuvComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AnneeuvComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
