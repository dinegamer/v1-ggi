import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {RouterModule } from '@angular/router';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { NgSelectModule } from '@ng-select/ng-select';
import { Anneeuv } from '../../../model/anneeuv.model';
import { AnneeuvService } from '../../../service/anneeuv.service';
@Component({
  selector: 'app-anneeuv',
  standalone: true,
  imports: [
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent, 
    ColComponent,
    RowComponent,
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    NgSelectModule ,
    FormsModule
  ],
  templateUrl: './anneeuv.component.html',
  styleUrl: './anneeuv.component.scss'
})
export class AnneeuvComponent implements OnInit {
  annees: Anneeuv[] = [];
  anneeuv: Anneeuv = { id: 0, nom: '', debutannee: '', finannee: '' };
  isEdit: boolean = false;

  constructor(private anneeuvService: AnneeuvService) {}

  ngOnInit() {
    this.loadAnnees();
  }

  loadAnnees() {
    this.anneeuvService.getAllAnnee().subscribe((data) => {
      this.annees = data;
    });
  }

  editAnnee(annee: Anneeuv) {
    this.anneeuv = { ...annee }; // Copie pour éviter les modifications directes
    this.isEdit = true;
  }

  save() {
    if (this.isEdit) {
      this.anneeuvService.updateAnnee(this.anneeuv.id!, this.anneeuv).subscribe(() => {
        this.resetForm();
        this.loadAnnees();
      });
    } else {
      this.anneeuvService.createAnnee(this.anneeuv).subscribe(() => {
        this.resetForm();
        this.loadAnnees();
      });
    }
  }

  deleteAnnee(id: number) {
    this.anneeuvService.deleteAnnee(id).subscribe(() => {
      this.loadAnnees();
    });
  }

  resetForm() {
    this.anneeuv = {id: 0, nom: '', debutannee: '', finannee: '' };
    this.isEdit = false;
  }
}
