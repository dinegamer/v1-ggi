import { Component, OnInit } from '@angular/core';
import { Cycle } from '../../../model/cycle.model';
import { CycleService } from '../../../service/cycle.service';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-cycle',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    CommonModule
  ],
  templateUrl: './cycle.component.html',
  styleUrl: './cycle.component.scss'
})
export class CycleComponent implements OnInit {
  cycles: Cycle[] = [];
  form: FormGroup;
  isEditing = false;
  currentId: number | null = null;
  isLoading = true;

  constructor(
    private fb: FormBuilder,
    private cycleService: CycleService
  ) {
    this.form = this.fb.group({
      nom: ['']
    });
  }

  ngOnInit(): void {
    this.loadCycles();
  }

  loadCycles(): void {
    this.cycleService.getAllCycle().subscribe({
      next: (data) => {
        this.cycles = data;
        this.isLoading = false;
      },
      error: () => this.isLoading = false
    });
  }

  onSubmit(): void {
    if (this.form.invalid) return;

    const cycle: Cycle = this.form.value;

    if (this.isEditing && this.currentId) {
      this.cycleService.update(this.currentId, cycle)
        .subscribe(() => this.resetForm());
    } else {
      this.cycleService.create(cycle)
        .subscribe(() => this.resetForm());
    }
  }

  editCycle(cycle: Cycle): void {
    this.isEditing = true;
    this.currentId = cycle.id!;
    this.form.patchValue(cycle);
  }

  deleteCycle(id: number): void {
    if (confirm('Voulez-vous vraiment supprimer ce cycle ?')) {
      this.cycleService.delete(id)
        .subscribe(() => this.loadCycles());
    }
  }

  resetForm(): void {
    this.form.reset();
    this.isEditing = false;
    this.currentId = null;
    this.loadCycles();
  }
}
