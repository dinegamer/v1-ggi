import { Component, OnInit } from '@angular/core';
import { Categorie } from '../../../model/categorie.model';
import { CategorieService } from '../../../service/categorieService';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-categorie',
  standalone: true,
  imports: [
    FormsModule,
    CommonModule
  ],
  templateUrl: './categorie.component.html',
  styleUrl: './categorie.component.scss'
})
export class CategorieComponent implements OnInit {
  categories: Categorie[] = [];
  categorie: Categorie = { id: 0, nom: '' };
  isEditing: boolean = false;

  constructor(private categorieService: CategorieService) {}

  ngOnInit(): void {
    this.loadCategories();
  }

  loadCategories(): void {
    this.categorieService.getAll().subscribe(data => {
      this.categories = data;
    });
  }

  saveOrUpdate(): void {
    if (this.isEditing) {
      this.categorieService.update(this.categorie).subscribe(() => {
        this.loadCategories();
        this.resetForm();
      });
    } else {
      this.categorieService.save(this.categorie).subscribe(() => {
        this.loadCategories();
        this.resetForm();
      });
    }
  }

  edit(c: Categorie): void {
    this.categorie = { ...c };
    this.isEditing = true;
  }

  delete(id: number): void {
    this.categorieService.delete(id).subscribe(() => {
      this.loadCategories();
    });
  }

  resetForm(): void {
    this.categorie = { id: 0, nom: '' };
    this.isEditing = false;
  }
}