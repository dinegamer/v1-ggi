import { Component, OnInit } from '@angular/core';
import { Ecole } from '../../../model/ecole.model';
import { EcoleService } from '../../../service/ecole.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Categorie } from '../../../model/categorie.model';
import { CategorieService } from '../../../service/categorieService';

@Component({
  selector: 'app-ecole',
  standalone: true,
  imports: [
    FormsModule,
    CommonModule
  ],
  templateUrl: './ecole.component.html',
  styleUrl: './ecole.component.scss'
})
export class EcoleComponent implements OnInit {
  ecoles: Ecole[] = [];
  categories: Categorie[] = [];
  currentEcole: Ecole = {
    idEcole: 0,
    nomEcole: '',
    descriptionEcole: '',
    adresseEcole: '',
    categorie: { id: 0, nom: '' }
  };
  isEditing = false;

  constructor(
    private ecoleService: EcoleService,
    private categorieService: CategorieService
  ) {}

  ngOnInit(): void {
    this.loadEcoles();
  }
  cancelEdit(): void {
    this.isEditing = false;
    this.currentEcole = {
      idEcole: 0,
      nomEcole: '',
      descriptionEcole: '',
      adresseEcole: '',
      categorie: { id: 0, nom: '' }
    }; // Réinitialiser l'objet
  }

  loadEcoles(): void {
    this.ecoleService.getAllEcole().subscribe((data) => {
      this.ecoles = data;
    });
  }
  loadCategories(): void{
    this.categorieService.getAll().subscribe({
      next: (data) => { this.categories = data},
      error: (error) => {console.log("Erreur !!!"+error)}
    })
  }

  saveOrUpdate(): void {
    if (this.isEditing) {
      this.ecoleService.update(this.currentEcole.idEcole, this.currentEcole).subscribe(() => {
        this.loadEcoles();
        this.resetForm();
      });
    } else {
      this.ecoleService.save(this.currentEcole).subscribe(() => {
        this.loadEcoles();
        this.resetForm();
      });
    }
  }

  edit(ecole: Ecole): void {
    this.currentEcole = { ...ecole };
    this.isEditing = true;
  }

  delete(id: number): void {
    this.ecoleService.delete(id).subscribe(() => {
      this.loadEcoles();
    });
  }

  resetForm(): void {
    this.currentEcole = {
      idEcole: 0,
      nomEcole: '',
      descriptionEcole: '',
      adresseEcole: '',
      categorie: { id: 0, nom: '' }
    };
    this.isEditing = false;
  }
}