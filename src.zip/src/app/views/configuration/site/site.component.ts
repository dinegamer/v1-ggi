import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Ecole } from 'src/app/model/ecole.model';
import { Site } from 'src/app/model/site.model';
import { EcoleService } from 'src/app/service/ecole.service';
import { SiteService } from 'src/app/service/site.service';

@Component({
  selector: 'app-site',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './site.component.html',
  styleUrls: ['./site.component.scss']
})
export class SiteComponent implements OnInit {
  sites: Site[] = [];
  ecoles: Ecole[] = [];
  currentSite: Partial<Site> = this.createEmptySite();
  isEditing = false;
  isLoading = false;
  errorMessage = '';

  constructor(
    private siteService: SiteService,
    private ecoleService: EcoleService
  ) {}

  ngOnInit(): void {
    this.loadData();
  }

  loadData(): void {
    this.isLoading = true;
    this.errorMessage = '';

    // Chargement parallèle des sites et écoles
    Promise.all([
      this.siteService.getAllSite().toPromise(),
      this.ecoleService.getAllEcole().toPromise()
    ]).then(([sites, ecoles]) => {
      this.sites = sites || [];
      this.ecoles = ecoles || [];
      this.isLoading = false;
    }).catch(error => {
      this.errorMessage = 'Erreur lors du chargement des données';
      this.isLoading = false;
      console.error('Loading error:', error);
    });
  }

  saveOrUpdate(): void {
    if (!this.isFormValid()) return;

    this.isLoading = true;
    const operation = this.isEditing 
      ? this.siteService.update(this.currentSite as Site)
      : this.siteService.save(this.currentSite as Site);

    operation.subscribe({
      next: () => {
        this.loadData();
        this.resetForm();
      },
      error: (error) => {
        this.errorMessage = `Erreur lors de ${this.isEditing ? 'la mise à jour' : "l'ajout"}`;
        console.error('Save error:', error);
        this.isLoading = false;
      }
    });
  }

  edit(site: Site): void {
    this.currentSite = { ...site };
    this.isEditing = true;
    window.scrollTo(0, 0);
  }

  delete(id: number): void {
    if (!confirm('Êtes-vous sûr de vouloir supprimer ce site ?')) return;

    this.isLoading = true;
    this.siteService.delete(id).subscribe({
      next: () => this.loadData(),
      error: (error) => {
        this.errorMessage = 'Erreur lors de la suppression';
        console.error('Delete error:', error);
        this.isLoading = false;
      }
    });
  }

  resetForm(): void {
    this.currentSite = this.createEmptySite();
    this.isEditing = false;
    this.errorMessage = '';
  }

  private createEmptySite(): Partial<Site> {
    return {
      nom: '',
      adresse: '',
      signature: '',
      titre: '',
      responsable: '',
      ecole: {
        idEcole: 0,
        nomEcole: '',
        descriptionEcole: '',
        adresseEcole: '',
        categorie: {
          id: 0,
          nom: ''
        }
      }
    };
  }

  private isFormValid(): boolean {
    return !!this.currentSite.nom && 
           !!this.currentSite.adresse && 
           !!this.currentSite.ecole;
  }
}