import { Component, OnInit } from '@angular/core';
import { Departement } from '../../../model/departement.model';
import { DepartementService } from '../../../service/DepartementService';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
@Component({
  selector: 'app-departement',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './departement.component.html',
  styleUrl: './departement.component.scss'
})
export class DepartementComponent implements OnInit {
  departements: Departement[] = [];
  currentDepartement: Departement = {id:0, nom: '' };
  isEditing = false;

  constructor(private service: DepartementService) {}

  ngOnInit(): void {
    this.loadDepartements();
  }

  loadDepartements(): void {
    this.service.getAll().subscribe(data => this.departements = data);
  }

  saveOrUpdate(): void {
    if (this.isEditing) {
      this.service.update(this.currentDepartement).subscribe(() => {
        this.loadDepartements();
        this.resetForm();
      });
    } else {
      this.service.save(this.currentDepartement).subscribe(() => {
        this.loadDepartements();
        this.resetForm();
      });
    }
  }

  edit(dep: Departement): void {
    this.currentDepartement = { ...dep };
    this.isEditing = true;
  }

  delete(id?: number): void {
    if (id) {
      this.service.delete(id).subscribe(() => this.loadDepartements());
    }
  }

  resetForm(): void {
    this.currentDepartement = {id:0, nom: '' };
    this.isEditing = false;
  }
}
