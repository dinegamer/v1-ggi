import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    data: {
      title: 'Frais'
    },
    children: [
      {
        path: '',
        redirectTo: 'frais',
        pathMatch: 'full'
      },{
        path: 'frais',
        loadComponent: () => import('../frais/frais.component').then(m => m.FraisComponent),
        data: {
          title: 'Frais scolaire'
        }
      },
      {
        path: 'parfiliere',
        loadComponent: () => import('../frais/parfiliere/parfiliere.component').then(m => m.ParfiliereComponent),
        data: {
          title: 'Frai par Filiere'
        }
      },
      {
        path: 'parcycle',
        loadComponent: () => import('../frais/parcycle/parcycle.component').then(m => m.ParcycleComponent),
        data: {
          title: 'les frais Par Cycle'
        }
      },
      {
        path: 'parsite',
        loadComponent: () => import('../frais/parsite/parsite.component').then(m => m.ParsiteComponent),
        data: {
          title: 'Frai pour le site'
        }
      },
    ]
  }
];

