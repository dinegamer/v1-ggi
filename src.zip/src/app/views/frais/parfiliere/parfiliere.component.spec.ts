import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ParfiliereComponent } from './parfiliere.component';

describe('ParfiliereComponent', () => {
  let component: ParfiliereComponent;
  let fixture: ComponentFixture<ParfiliereComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ParfiliereComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ParfiliereComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
