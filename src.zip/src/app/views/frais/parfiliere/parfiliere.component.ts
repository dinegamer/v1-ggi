import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { NgSelectModule } from '@ng-select/ng-select';
import { Filiere } from '../../../model/filiere.model';
import { FraisParFiliere } from '../../../donnees/FraisParFiliere';
import { FraixscolaireService } from '../../../service/fraixscolaire.service';
import { FiliereService } from '../../../service/filiere.service';
import { User } from '../../../model/user.model';
import { AuthService } from '../../../service/auth.service';
import { Fraixscolaire } from '../../../model/fraixscolaire.model';
import { Etudiant } from '../../../model/etudiant.model';

@Component({
  selector: 'app-parfiliere',
  standalone: true,
  imports: [
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent,
    ColComponent,
    RowComponent,
    RouterModule,
    ReactiveFormsModule,
    CommonModule,
    NgSelectModule,
    FormsModule
  ],
  templateUrl: './parfiliere.component.html',
  styleUrl: './parfiliere.component.scss'
})
export class ParfiliereComponent implements OnInit{

  cours = [
    {id:1, nom:'JOUR'},
    {id:2, nom:'SOIR'}
  ]
  filieres: Filiere[] = []
  resultat: boolean = false
  fraiparfilieres!: FraisParFiliere
  user!: User;
  donnee: string[] = []

  constructor(
    private fraixService: FraixscolaireService,
    private filiereService: FiliereService,
    private authService: AuthService      
  ){}

  ngOnInit(): void {
    this.getAllFiliere()
  }
  
  readonly myFormGroup = new FormGroup({    
    cour: new FormControl(""),
    filiere: new FormControl(""),    
  });
  Ajouter(frais: Fraixscolaire){
    this.fraixService.create(frais).subscribe({
      next: (response) =>{ 
        alert("Ajouter avec succes !") 
        this.rechercheFraisEtudiant()
      },
      error: (errer) => {
        alert("Erreur "+ (errer.message || errer) )
      }
    })
  }
  Modifier(frais: Fraixscolaire){
    this.fraixService.update(frais.id,frais).subscribe({
      next: (response) => {
         alert("succes !! "+response)
        },
      error: (errer) => { alert("Erreur !!"+ (errer.message || errer)) }
    })
  }
  Supprimer(frais: Fraixscolaire){
    if(confirm("Voulez-vous vraiment supprimer ce frais ?")) {
      this.fraixService.delete(frais.id).subscribe({
        next: () => {
          alert("Supprimé avec succès !");
          this.rechercheFraisEtudiant()
        },
        error: (error) => {
          alert("Erreur lors de la suppression : " + (error.message || error));
        }
      });
    }
  }

  getAllFiliere(){
    this.filiereService.getAllFilieres().subscribe(data => {
      this.filieres = data
    });
  }

  rechercheFraisEtudiant(){
    this.resultat = true
    this.user = this.authService.getUserFromLocalStorage();
    let site = this.user.administrateur.site.id
    let an = this.user.parametre.anneepardefaut.id
    const donnees = this.myFormGroup.value
    let cour = donnees.cour
    let filiere = donnees.filiere
    //console.log(site,an,cour,filiere +" mdt +++++")

    this.fraixService.getFraiParFiliere(site,an,cour,filiere).subscribe(data => {
      this.fraiparfilieres = data 
    })
  }

}
