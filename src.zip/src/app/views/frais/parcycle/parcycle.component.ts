import { Component, OnInit } from '@angular/core';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { InscriptionService } from '../../../service/inscription.service';
import { NombreEtudiantParSite } from '../../../donnees/NombreEtudiantParSite';
import { CommonModule } from '@angular/common';
import { Site } from '../../../model/site.model';
import { Anneeuv } from '../../../model/anneeuv.model';
import { User } from '../../../model/user.model';
import { AuthService } from '../../../service/auth.service';
import { FraisParSite } from '../../../donnees/FraisParSite';
import { FraixscolaireService } from '../../../service/fraixscolaire.service';

@Component({
  selector: 'app-parcycle',
  standalone: true,
  imports: [
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent,
    ColComponent,
    RowComponent,
    CommonModule
  ],
  templateUrl: './parcycle.component.html',
  styleUrl: './parcycle.component.scss'
})
export class ParcycleComponent implements OnInit{
  
  user!: User
  fraisParSite!: FraisParSite
  resultat: boolean = false

  constructor(
    private fraixscolaireService: FraixscolaireService,
    private authService: AuthService
  ){}

  ngOnInit(): void {
    this.getNombreEtudiantParSite()    
  }

  getNombreEtudiantParSite(){
    this.resultat = true
    this.user = this.authService.getUserFromLocalStorage()
    let site = this.user.administrateur.site.id
    let an = this.user.parametre.anneepardefaut.id
    this.fraixscolaireService.getFraiParSite(site,an).subscribe(data =>{
      this.fraisParSite = data
    })
  }
}
