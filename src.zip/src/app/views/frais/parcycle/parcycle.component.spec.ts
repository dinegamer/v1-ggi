import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ParcycleComponent } from './parcycle.component';

describe('ParcycleComponent', () => {
  let component: ParcycleComponent;
  let fixture: ComponentFixture<ParcycleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ParcycleComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ParcycleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
