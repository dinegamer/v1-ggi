import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { NgSelectModule } from '@ng-select/ng-select';
import { Filiere } from '../../../model/filiere.model';
import { FraisParFiliere } from '../../../donnees/FraisParFiliere';
import { FraixscolaireService } from '../../../service/fraixscolaire.service';
import { FiliereService } from '../../../service/filiere.service';
import { User } from '../../../model/user.model';
import { AuthService } from '../../../service/auth.service';

@Component({
  selector: 'app-parsite',
  standalone: true,
  imports: [
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent,
    ColComponent,
    RowComponent,
    RouterModule,
    ReactiveFormsModule,
    CommonModule,
    NgSelectModule
  ],
  templateUrl: './parsite.component.html',
  styleUrl: './parsite.component.scss'
})
export class ParsiteComponent implements OnInit {

   cours = [
      {id:1, nom:'JOUR'},
      {id:2, nom:'SOIR'}
    ]
    filieres: Filiere[] = []
    resultat: boolean = false
    fraiparfilieres!: FraisParFiliere
    user!: User;
    
  
    constructor(
      private fraixscoalire: FraixscolaireService,
      private filiereService: FiliereService,
      private authService: AuthService      
    ){}

    ngOnInit(): void {
      this.getAllFiliere()
    }
    
    readonly myFormGroup = new FormGroup({    
      cour: new FormControl(""),
      filiere: new FormControl(""),    
    });

    getAllFiliere(){
      this.filiereService.getAllFilieres().subscribe(data => {
        this.filieres = data
      });
    }
  
    rechercheFraisEtudiant(){
      this.resultat = true
      this.user = this.authService.getUserFromLocalStorage();
      let site = this.user.administrateur.site.id
      let an = this.user.parametre.anneepardefaut.id
      const donnees = this.myFormGroup.value
      let cour = donnees.cour
      let filiere = donnees.filiere
      //console.log(site,an,cour,filiere +" mdt +++++")

      this.fraixscoalire.getFraiParFiliere(site,an,cour,filiere).subscribe((data:any) => {
        this.fraiparfilieres = data 
      })
    }

}
