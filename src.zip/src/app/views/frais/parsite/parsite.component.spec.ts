import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ParsiteComponent } from './parsite.component';

describe('ParsiteComponent', () => {
  let component: ParsiteComponent;
  let fixture: ComponentFixture<ParsiteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ParsiteComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ParsiteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
