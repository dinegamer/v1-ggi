import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Administrateur } from '../../model/administrateur.model';
import { AdminService } from '../../service/admin.service';
import { SiteService } from '../../service/site.service';
import { RoleService } from '../../service/role.service';
import { Site } from '../../model/site.model';
import { Role } from '../../model/role.model';

@Component({
  selector: 'app-administrateur',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './administrateur.component.html'
})
export class AdministrateurComponent implements OnInit {
  administrateurs: Administrateur[] = [];
  sites: Site[] = [];
  roles: Role[] = [];
  
  selectedFile!: File;
  previewUrl: string | ArrayBuffer | null = null;

  onFileSelected(event: any): void {
    this.selectedFile = event.target.files[0];

    const reader = new FileReader();
    reader.onload = () => {
      this.previewUrl = reader.result;
    };
    reader.readAsDataURL(this.selectedFile);
  }

  currentAdmin: Administrateur = {
    id: 0,
    nom: '',
    prenom: '',
    adresse: '',
    telephone: '',
    email: '',
    lieun: '',
    datedn: '',
    photo: '',
    username: '',
    password: '',
    site: { id: 0, nom: '', adresse: '', signature:'', titre:'', responsable:'', ecole: { idEcole: 0, nomEcole: '', descriptionEcole: '', adresseEcole: '', categorie: { id: 0, nom: '' } } },
    role: { id: 0, nom: '', description: '', categorie: { id: 0, nom: '' }  }
  };

  isEditing = false;

  constructor(
    private adminService: AdminService,
    private siteService: SiteService,
    private roleService: RoleService
  ) {}

  ngOnInit(): void {
    this.loadAll();
  }

  loadAll(): void {
    this.adminService.getAllAdmin().subscribe(data => this.administrateurs = data);
    this.siteService.getAllSite().subscribe(data => this.sites = data);
    this.roleService.getRoles().subscribe(data => this.roles = data);
  }

  saveOrUpdate(): void {
    const request = this.isEditing ? this.adminService.update(this.currentAdmin) : this.adminService.save(this.currentAdmin);
    request.subscribe(() => {
      this.loadAll();
      this.resetForm();
    });
  }

  edit(admin: Administrateur): void {
    this.currentAdmin = { ...admin };
    this.isEditing = true;
  }

  delete(id: number): void {
    this.adminService.delete(id).subscribe(() => this.loadAll());
  }

  resetForm(): void {
    this.currentAdmin = {
      id: 0,
      nom: '',
      prenom: '',
      adresse: '',
      telephone: '',
      email: '',
      lieun: '',
      datedn: '',
      photo: '',
      username: '',
      password: '',
      site: { id: 0, nom: '', adresse: '', signature:'', titre:'', responsable:'', ecole: { idEcole: 0, nomEcole: '', descriptionEcole: '', adresseEcole: '', categorie: { id: 0, nom: '' } } },
      role: { id: 0, nom: '', description: '', categorie: { id: 0, nom: '' }  }
    };
    this.isEditing = false;
  }
}
