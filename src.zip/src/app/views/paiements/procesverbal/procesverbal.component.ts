import { Component } from '@angular/core';

@Component({
  selector: 'app-procesverbal',
  standalone: true,
  imports: [],
  templateUrl: './procesverbal.component.html',
  styleUrl: './procesverbal.component.scss'
})
export class ProcesverbalComponent {

}
