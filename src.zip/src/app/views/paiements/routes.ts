import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    data: {
      title: 'Paiements'
    },
    children: [
      {
        path: '',
        redirectTo: 'paiements',
        pathMatch: 'full'
      },
      {
        path: 'paiements',
        loadComponent: () => import('../paiements/paiements.component').then(m => m.PaiementsComponent),
        data: {
          title: 'Paiement'
        }
      },
      {
        path: 'enregistre',
        loadComponent: () => import('../paiements/enregistre/enregistre.component').then(m => m.EnregistreComponent),
        data: {
          title: 'Enregistre un Paiement'
        }
      },
      {
        path: 'paretudiant',
        loadComponent: () => import('../paiements/paretudiant/paretudiant.component').then(m => m.ParetudiantComponent),
        data: {
          title: 'Paiement par etudiant'
        }
      },
      {
        path: 'parclasse',
        loadComponent: () => import('../paiements/parclasse/parclasse.component').then(m => m.ParclasseComponent),
        data: {
          title: 'Paiement par classe'
        }
      },
      {
        path: 'procesverbal',
        loadComponent: () => import('../paiements/procesverbal/procesverbal.component').then(m => m.ProcesverbalComponent),
        data: {
          title: 'Proces verbal arret de caisse'
        }
      },
    ]
  }
];

