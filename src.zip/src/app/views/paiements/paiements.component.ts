import { CommonModule, DatePipe } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { NgSelectModule } from '@ng-select/ng-select';
import { Filiere } from '../../model/filiere.model';
import { Etudiant } from '../../model/etudiant.model';
import { User } from '../../model/user.model';
import { Anneeuv } from '../../model/anneeuv.model';
import { FiliereService } from '../../service/filiere.service';
import { InscriptionService } from '../../service/inscription.service';
import { AuthService } from '../../service/auth.service';
import { AnneeuvService } from '../../service/anneeuv.service';
import { PaiementService } from '../../service/paiement.service';

@Component({
  selector: 'app-paiements',
  standalone: true,
  imports: [
    CardHeaderComponent,
    CardBodyComponent,
    CardComponent,
    ColComponent,
    RowComponent,
    RouterModule,
    ReactiveFormsModule,
    CommonModule,
    NgSelectModule
  ],
  providers: [DatePipe],
  templateUrl: './paiements.component.html',
  styleUrl: './paiements.component.scss'
})
export class PaiementsComponent {
  

}
