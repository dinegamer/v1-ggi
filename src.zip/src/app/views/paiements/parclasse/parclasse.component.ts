import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { NgSelectModule } from '@ng-select/ng-select';
import { Anneeuv } from '../../../model/anneeuv.model';
import { Filiere } from '../../../model/filiere.model';
import { Site } from '../../../model/site.model';
import { PaiementService } from '../../../service/paiement.service';
import { AnneeuvService } from '../../../service/anneeuv.service';
import { FiliereService } from '../../../service/filiere.service';
import { AuthService } from '../../../service/auth.service';
import { User } from '../../../model/user.model';
import { Statistiqueparclasse } from '../../../donnees/statistiqueparclasse';
import $ from 'jquery';
import 'datatables.net';

@Component({
  selector: 'app-parclasse',
  standalone: true,
  imports: [
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent,
    ColComponent,
    RowComponent,
    RouterModule,
    ReactiveFormsModule,
    CommonModule,
    NgSelectModule
  ],
  templateUrl: './parclasse.component.html',
  styleUrl: './parclasse.component.scss'
})
export class ParclasseComponent {

  donnee: any[] = [];
  statistiqueparclasse!: Statistiqueparclasse
  filieres: Filiere[] = []
  annees: Anneeuv[] = [] 
  cours = [
    {id:1, nom:'JOUR'},
    {id:2, nom:'SOIR'}
  ]
  sites: Site[] = []
  user!: User;
  resultat: boolean = false
  constructor(
    private paiementService: PaiementService, 
    private anneeuvService: AnneeuvService,
    private filiereService: FiliereService,
    private authService: AuthService
    ){  }
  ngOnInit(): void {
    this.getAllFiliere()
    this.getAllAnnee()
    //retrouver les informations de l'utilisateur
    this.user = this.authService.getUserFromLocalStorage();
    //console.log(this.user.site.nom+" ++///+ *** ")
  }

  getAllFiliere(){
    this.filiereService.getAllFilieres().subscribe({
      next: data => { this.filieres = data}
    });
  }
  getAllAnnee(){
    this.anneeuvService.getAllAnnee().subscribe({
      next: (data) =>{ this.annees = data}
    });
  }

  readonly myFormGroup = new FormGroup({
    annee: new FormControl(""),
    cours: new FormControl(""),
    filiere: new FormControl(""),
    semestre: new FormControl(""),
    etudiant: new FormControl(""),
  });


  rechercheStatistiqueEtudiant(){ 
    const donnees = this.myFormGroup.value
    this.donnee[0] = this.user.administrateur.site.id
    this.donnee[1] = donnees.filiere
    this.donnee[2] = donnees.annee
    this.donnee[3] = donnees.cours
    //console.log(this.donnee+" données ")
    this.paiementService.getStatistiqueClasse(this.donnee).subscribe((data:any) =>{
      this.statistiqueparclasse = data      
      this.resultat = true
      /*setTimeout(() => {
        let table = ($('#donnees') as any).DataTable();

        if ($.fn.DataTable.isDataTable('#donnees')) {
          table.destroy(); // Détruit l'ancienne instance
        }
        ($('#donnees') as any).DataTable({
          paging: true,
          searching: true,
          ordering: true,
          info: true,
          lengthMenu: [5, 10, 25, 50], // Options pour le nombre de lignes affichées
          pageLength: 5,        // Nombre de lignes par défaut
          language: {
            search: "🔍 Rechercher :",
            lengthMenu: "Afficher _MENU_ entrées",
            info: "Affichage de _START_ à _END_ sur _TOTAL_ entrées",
            paginate: {
              first: "⏪",
              last: "⏩",
              next: "▶",
              previous: "◀"
            }}
        }); // Initialise DataTables après le rendu
      }, 100);*/
    })
    
  } 
}
