import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ParclasseComponent } from './parclasse.component';

describe('ParclasseComponent', () => {
  let component: ParclasseComponent;
  let fixture: ComponentFixture<ParclasseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ParclasseComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ParclasseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
