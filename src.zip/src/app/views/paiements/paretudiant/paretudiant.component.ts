import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { NgSelectModule } from '@ng-select/ng-select';
import { Anneeuv } from '../../../model/anneeuv.model';
import { Filiere } from '../../../model/filiere.model';
import { Etudiant } from '../../../model/etudiant.model';
import { Site } from '../../../model/site.model';
import { StatistiqueParEtudiant } from '../../../donnees/statistiqueParEtudiant';
import { InscriptionService } from '../../../service/inscription.service';
import { PaiementService } from '../../../service/paiement.service';
import { AnneeuvService } from '../../../service/anneeuv.service';
import { FiliereService } from '../../../service/filiere.service';
import { AuthService } from '../../../service/auth.service';
import { User } from '../../../model/user.model';

@Component({
  selector: 'app-paretudiant',
  standalone: true,
  imports: [
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent,
    ColComponent,
    RowComponent,
    RouterModule,
    ReactiveFormsModule,
    CommonModule,
    NgSelectModule
  ],
  templateUrl: './paretudiant.component.html',
  styleUrl: './paretudiant.component.scss'
})
export class ParetudiantComponent {

  donnee: any[] = [];
  statistiqueparetudiant!: StatistiqueParEtudiant
  etudiants: Etudiant[] = []
  filieres: Filiere[] = []
  anneeuvs: Anneeuv[] = [] 
  cours = [
    {id:1, nom:'JOUR'},
    {id:2, nom:'SOIR'}
  ]
  sites: Site[] = []
  user!: User;
  pourcentage!: number;
  constructor(
    private inscrireService: InscriptionService,
    private paiementService: PaiementService, 
    private filiereService: FiliereService,
    private authService: AuthService,
    private anneeService: AnneeuvService
    ){  }
  ngOnInit(): void {
    this.getAllFiliere()
    this.getAllAnneeuv()
    this.user = this.authService.getUserFromLocalStorage();
    //console.log(this.user.site.nom+" ++///+ *** ")
  }
  getAllAnneeuv(){
    this.anneeService.getAllAnnee().subscribe({
      next: (response) =>{
        this.anneeuvs = response
      }
    })
  }

  getAllFiliere(){
    this.filiereService.getAllFilieres().subscribe(data => {
      this.filieres = data
    });
  }

  readonly myFormGroup = new FormGroup({
    annee: new FormControl(""),
    cours: new FormControl(""),
    filiere: new FormControl(""),
    semestre: new FormControl(""),
    etudiant: new FormControl(""),
  });

  
  AfficherEtudiants(){
    const donnees = this.myFormGroup.value
    this.donnee[0] = donnees.annee
    this.donnee[1] = donnees.cours
    this.donnee[2] = donnees.filiere
    this.donnee[3] = this.user.administrateur.site.id
    //console.log("test test *- ***")
    this.inscrireService.getListeParClasse(this.donnee).subscribe((data: any) =>{
      this.etudiants = data
    })
  }

  rechercheStatistiqueEtudiant(){ 
    const donnees = this.myFormGroup.value
    this.donnee[0] = donnees.etudiant
    this.donnee[1] = donnees.filiere
    this.donnee[2] = donnees.annee
    this.donnee[3] = donnees.cours
    this.donnee[4] = this.user.administrateur.site.id

    this.paiementService.getStatistiqueEtudiant(this.donnee).subscribe((data:any) =>{
      this.statistiqueparetudiant = data
      this.pourcentage = this.statistiqueparetudiant.pourcentage
    })
    /*this.paiementService.getTotalPaieParEtudiant(this.donnee).subscribe(data =>{
      this.totalpaiparetudiant = data
    })*/
  } 
}
