import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ParetudiantComponent } from './paretudiant.component';

describe('ParetudiantComponent', () => {
  let component: ParetudiantComponent;
  let fixture: ComponentFixture<ParetudiantComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ParetudiantComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ParetudiantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
