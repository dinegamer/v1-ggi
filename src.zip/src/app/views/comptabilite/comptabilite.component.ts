import { CommonModule, DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CardBodyComponent, CardComponent, CardHeaderComponent, ColComponent, RowComponent } from '@coreui/angular';
import { FiliereService } from '../../service/filiere.service';
import { Filiere } from '../../model/filiere.model';
import { NgSelectModule } from '@ng-select/ng-select';
import { Etudiant } from '../../model/etudiant.model';
import { InscriptionService } from '../../service/inscription.service';
import { AuthService } from '../../service/auth.service';
import { User } from '../../model/user.model';
import { AnneeuvService } from '../../service/anneeuv.service';
import { Anneeuv } from '../../model/anneeuv.model';
import { PaiementService } from '../../service/paiement.service';
@Component({
  selector: 'app-comptabilite',
  standalone: true,
  imports: [
    CardHeaderComponent,
    CardBodyComponent,
    CardComponent,
    ColComponent,
    RowComponent,
    RouterModule,
    ReactiveFormsModule,
    CommonModule,
    NgSelectModule
  ],
  providers: [DatePipe],
  templateUrl: './comptabilite.component.html',
  styleUrl: './comptabilite.component.scss'
})
export class ComptabiliteComponent implements OnInit{
  filieres: Filiere[] = [];
  etudiants: Etudiant[] = [];
  frais: any[] = [];
  cours = [
    {id:1, nom:'JOUR'},
    {id:2, nom:'SOIR'}
  ]
  resultat: boolean = false
  user!: User
  anneereliquat: boolean = false
  annees!: Anneeuv[]
  paie: string[] = []
  message = ''

  constructor(
    private filiereService: FiliereService, 
    private inscrireService: InscriptionService,
    private authService: AuthService,
    private anneeuvService: AnneeuvService,
    private paiementService: PaiementService,
    private datePipe: DatePipe
  ){
    const donnees = this.FormulaireEnregistrement.value
    //console.log("test mdt "+donnees.reliquat+" ")
    this.FormulaireEnregistrement.get("reliquat")?.valueChanges.subscribe((valeur) =>{
      if(valeur == true){
        this.anneereliquat = true
        this.anneeuvService.getAllAnnee().subscribe(data =>{
          this.annees = data
        })
      }else{
        this.anneereliquat = false
      }
    });
  }
 readonly FormulaireEnregistrement = new FormGroup({
    annee: new FormControl(""),
    cours: new FormControl(""),
    filiere: new FormControl(""),
    site: new FormControl(""),
    etudiant: new FormControl(""),
    reliquat: new FormControl(false),
    anneereliquat: new FormControl(null),
    montant: new FormControl(""),
    enlettre: new FormControl(""),
    datepaie: new FormControl(""),
    motif: new FormControl("")
  });

  ngOnInit(): void {
    this.getAllFiliere()
    this.user = this.authService.getUserFromLocalStorage()
  }
  
  
  getAllFiliere(){
    this.filiereService.getAllFilieres().subscribe(data => {
      this.filieres = data
    });
  }

  AfficherEtudiants(){
    const donnees = this.FormulaireEnregistrement.value
   
    let donnee = [
      this.user.parametre.anneepardefaut.id,
      donnees.cours,
      donnees.filiere,
      this.user.administrateur.site.id
    ]
    //console.log("test test *- ***")
    this.inscrireService.getListeParClasse(donnee).subscribe((data: any) =>{
      this.etudiants = data      
    })
  }
  AfficherForm(){
    const donnees = this.FormulaireEnregistrement.value
    if(donnees.etudiant == ""){
      alert("Selectionner une étudiant ! Merci")
      return
    }
    this.resultat = true
  }
  Enregistre(){
    const now = new Date();
    const dateStr = now.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' });
    //
    const donnees = this.FormulaireEnregistrement.value
    this.paie[0] = ''+this.user.parametre.anneepardefaut.id || ''
    this.paie[1] = donnees.filiere || ''
    this.paie[2] = donnees.etudiant || ''
    this.paie[3] = donnees.reliquat != null ? donnees.reliquat.toString() : "false"
    this.paie[4] = donnees.anneereliquat || ''
    this.paie[5] = donnees.montant || ''
    this.paie[6] = donnees.enlettre || ''
    this.paie[7] = this.datePipe.transform(donnees.datepaie, 'dd/MM/yyyy') || '';
    this.paie[8] = donnees.motif || ''
    this.paie[9] = dateStr

    this.paiementService.Enregistre(this.paie).subscribe({
      next: (response) => {
        this.message = response.message; // Afficher le message renvoyé par le backend
        this.resetForm()
      },
      error: (error) => {this.message = "Une erreur est survenue. Veuillez réessayer.";}
    })
  }
  resetForm(){
    // 🔄 Recharger la page après succès
    setTimeout(() => {
      window.location.reload();
    }, 3000); // Petite pause pour afficher le message
  }
}

