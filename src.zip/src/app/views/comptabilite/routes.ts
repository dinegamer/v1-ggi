import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    data: {
      title: 'Comptabilite'
    },
    children: [
      {
        path: '',
        redirectTo: 'comptabilite',
        pathMatch: 'full'
      },
      {
        path: 'comptabilite',
        loadComponent: () => import('./comptabilite.component').then(m => m.ComptabiliteComponent),
        data: {
          title: 'Comptabilite'
        }
      }
    ]
  }
];

