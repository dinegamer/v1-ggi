import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Tableaudebord } from '../model/tableaudebord.model';
import { TableauDeBordSite } from '../dto/tableaudebordsite.dto';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  readonly apUrl = environment.apiURL+"/dashboard";
  constructor(private http: HttpClient) { }

  gettableaudebord(annee: any, site: any): Observable<Tableaudebord>{
    return this.http.get<Tableaudebord>(this.apUrl+"/"+annee+"/"+site)
  }
  TableaudebordTotal(annee: any): Observable<Tableaudebord>{
    return this.http.get<Tableaudebord>(this.apUrl+"/"+annee)
  }
  gettableaudebordsite(annee: any, site: any): Observable<TableauDeBordSite[]>{
    return this.http.get<TableauDeBordSite[]>(this.apUrl+"/detailsite/"+annee+"/"+site)
  }
}
