import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Site } from '../model/site.model';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class SiteService {
  readonly apiUrl = environment.apiURL+'/sites';

  constructor(private httpClient: HttpClient) { }

  getAllSite(): Observable<Site[]>{
    return this.httpClient.get<Site[]>(this.apiUrl);
  }

  save(site: Site): Observable<Site> {
    return this.httpClient.post<Site>(this.apiUrl, site);
  }

  update(site: Site): Observable<Site> {
    return this.httpClient.put<Site>(this.apiUrl, site);
  }

  delete(id: number): Observable<void> {
    return this.httpClient.delete<void>(`${this.apiUrl}/${id}`);
  }

  findById(id: number): Observable<Site> {
    return this.httpClient.get<Site>(`${this.apiUrl}/${id}`);
  }
}
