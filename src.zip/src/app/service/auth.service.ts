import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';
import { BehaviorSubject, Observable } from 'rxjs';
import { Administrateur } from '../model/administrateur.model';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = environment.apiURL;

  private isLoggedInSubject = new BehaviorSubject<boolean>(false);

  constructor(private http: HttpClient, private router: Router) {}

  login(credentials: { username: string; password: string }) {
    return this.http.post<any>(this.apiUrl+"/administrateurs/loginsup", credentials);   
  }
  saveUserToLocalStorage(user: any): void {
    localStorage.setItem('user', JSON.stringify(user));
  }

  updateUserInLocalStorage(updatedAdmin: Administrateur): void {
    const currentUser = this.getUserFromLocalStorage();
    if (currentUser) {
      currentUser.administrateur = updatedAdmin; // Met à jour l'administrateur
      localStorage.setItem('user', JSON.stringify(currentUser)); // Remet à jour dans localStorage
    }
  }
  

  getUserFromLocalStorage(): any {
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user) : null;
  }

  logout(): void {
    localStorage.removeItem('user');
    this.router.navigate(['/login']);
    //etat de connexion
    this.isLoggedInSubject.next(false);
    localStorage.removeItem('isLoggedIn');
  }
  //etat de connexion
  isLoggedIn(): Observable<boolean> {
    return this.isLoggedInSubject.asObservable();
  }

  checkLoginStatus(): void {
    const status = localStorage.getItem('isLoggedIn') === 'true';
    this.isLoggedInSubject.next(status);
  }

}
