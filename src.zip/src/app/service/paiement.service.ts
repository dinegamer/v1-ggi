import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Paiement } from '../model/paiement.model';
import { StatistiqueParEtudiant } from '../donnees/statistiqueParEtudiant';
import { Statistiqueparclasse } from '../donnees/statistiqueparclasse';

@Injectable({
  providedIn: 'root'
})
export class PaiementService {

  readonly apiUrl = environment.apiURL+"/paiements";

  constructor(private httpClient: HttpClient) { }
  //enregistre
  Enregistre(donnees: any): Observable<{message: string, status: string}>{
    return this.httpClient.post<{message: string, status: string}>(this.apiUrl+"/enregistre", donnees)
  }
//tout les paiements
  getAllPaiement(): Observable<Paiement[]>{
    return this.httpClient.get<Paiement[]>(this.apiUrl);
  }
   //total des paiements
  getTotalPaie(donnee: any): Observable<string>{
    return this.httpClient.post<string>(this.apiUrl+"/totalmontantpaie", donnee);
  }
  //statistique pour etudiant
  getStatistiqueEtudiant(donnee: any): Observable<StatistiqueParEtudiant>{
    return this.httpClient.post<StatistiqueParEtudiant>(this.apiUrl+"/statistiqueetudiant",donnee);
  }
  //statistique pour une classe
  getStatistiqueClasse(donnee: any): Observable<Statistiqueparclasse>{
    return this.httpClient.post<Statistiqueparclasse>(this.apiUrl+"/statistiqueclasse", donnee);
  }
  //montant paie par etudiant
  getPaieDeEtudiant(id: number): Observable<Paiement[]>{
    return this.httpClient.get<Paiement[]>(this.apiUrl+"/paretudiant/"+id)
  }
}
