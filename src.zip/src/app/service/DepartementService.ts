import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Departement } from '../model/departement.model';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class DepartementService {
  private url =  environment.apiURL+"/departements";

  constructor(private http: HttpClient) {}

  getAll(): Observable<Departement[]> {
    return this.http.get<Departement[]>(this.url);
  }

  save(dep: Departement): Observable<Departement> {
    return this.http.post<Departement>(this.url, dep);
  }

  update(dep: Departement): Observable<Departement> {
    return this.http.put<Departement>(this.url, dep);
  }

  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.url}/${id}`);
  }
}
