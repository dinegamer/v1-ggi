import { Injectable } from "@angular/core";
import { NoteModel } from "../model/note.model";
import { Observable } from "rxjs";
import { HttpClient } from "@angular/common/http";
import { environment } from "../../environments/environment";
import { Statistique } from "../model/statistique.model";
import { Noteparsemestre } from "../donnees/noteparsemestre";
import { Notedutun } from "../donnees/notedutun";
import { Notedutdeux } from "../donnees/notedutdeux";
import { TypeUEDTO } from "../dto/typeue.dto";

@Injectable({
  providedIn: 'root'
})
export class NoteService{
    readonly apiUrl = environment.apiURL+"/controles";

    constructor(private httpClient: HttpClient) { }
    //verifier l'existance d'une note
    getverifiernotedunetudiant(donnees: any): Observable<any>{
      return this.httpClient.post<any>(this.apiUrl+"/verifiernotedunetudiant", donnees)
    }
    //
    getAllControles(): Observable<NoteModel[]>{
      return this.httpClient.get<NoteModel[]>(this.apiUrl);
    }

    getStatistique(search: any): Observable<Statistique>{
      return this.httpClient.post<Statistique>(this.apiUrl+"/statistique", search);
    }
    getControleParClasse(search: any): Observable<Notedutun>{
      return this.httpClient.post<Notedutun>(this.apiUrl+"/noteparclasse", search);
    }
    getControleDutUn(search: any): Observable<Notedutun[]>{
      return this.httpClient.post<Notedutun[]>(this.apiUrl+"/notedutun", search);
    }
    getNotes(search: any): Observable<any>{
      return this.httpClient.post<any>(this.apiUrl+"/notes",search);
    }
    // Supprimer un contrôle par ID
    deleteControleById(id: string): Observable<any> {
      return this.httpClient.delete(this.apiUrl+"/"+id);
    }

    getControleDutDeux(search: any): Observable<Notedutdeux[]>{
      return this.httpClient.post<Notedutdeux[]>(this.apiUrl+"/notedutdeux", search);
    }
    //note par cycle
   /* getControleParCycle(search: any): Observable<Controle>{
      return this.httpClient.post<Controle>(this.apiUrl+"/controles/noteparcycle", search);
    }*/
    //enregistre une note
    saveNoteEtudiant(search: any): Observable<any>{
      return this.httpClient.post<any>(this.apiUrl+"/ajoutnoteetudiant", search);
    }
    //modifier
    updateNoteEtudiant(search: any): Observable<any>{
      return this.httpClient.put<any>(this.apiUrl+"/updatenoteetudiant", search);
    }
    getControleParSemestre(search: any): Observable<Noteparsemestre>{
      return this.httpClient.post<Noteparsemestre>(this.apiUrl+"/noteparsemestre", search);
    }
    //releve par classe
    getReleveParClasse(donnee: any): Observable<TypeUEDTO[]>{
      return this.httpClient.post<TypeUEDTO[]>(this.apiUrl+"/releveparclasse", donnee);
    }

  // Supprimer toutes les notes (tous les contrôles)
  deleteAllControles(donnees: any): Observable<{ status: string, message: string }> {
    return this.httpClient.delete<{ status: string, message: string }>(this.apiUrl+"/all", { body: donnees });
  }
}
