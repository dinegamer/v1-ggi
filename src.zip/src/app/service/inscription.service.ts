import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { Etudiant } from '../model/etudiant.model';
import { Inscrire } from '../model/inscription.model';
import { environment } from '../../environments/environment';
import { NombreEtudiantParSite } from '../donnees/NombreEtudiantParSite';
import { NombreEtudiantParFiliere } from '../donnees/NombreEtudiantParFiliere';


@Injectable({
  providedIn: 'root'
})
export class InscriptionService {

  readonly apiUrl = environment.apiURL+"/inscriptions";

  constructor(private httpClient: HttpClient) { }

  //le nombre etudiant par cycle
  getNombreEtudiantParSite(an: number, site: number): Observable<NombreEtudiantParSite>{
    return this.httpClient.get<NombreEtudiantParSite>(this.apiUrl+"/nombreetudiantparsite/"+an+"/"+site);
  }
  getNombreEtudiantParFiliere(an: number, site: number): Observable<NombreEtudiantParFiliere[]>{
    return this.httpClient.get<NombreEtudiantParFiliere[]>(this.apiUrl+"/nombreetudiantparfiliere/"+an+"/"+site)
  }

  getAllInscription(): Observable<Inscrire[]>{
    return this.httpClient.get<Inscrire[]>(this.apiUrl);
  }
  //les inscription d'un etudiant
  getAllInscrireEtudiant(etudiant: number): Observable<Inscrire[]>{
    return this.httpClient.get<Inscrire[]>(this.apiUrl+"/etudiantinscrire/"+etudiant);
  }

  getListeParClasseDuSite(donnee: any): Observable<Etudiant[]>{
    return this.httpClient.post<Etudiant[]>(this.apiUrl+"/listeparclassedusite", donnee);
  }
  //liste par classe
  getListeParClasse(donnee: any): Observable<Etudiant[]>{
    return this.httpClient.post<Etudiant[]>(this.apiUrl+"/listeparclasse", donnee);
  }
  //nombre d'incrit par an
  getNombreInscrit(donnee: any): Observable<string>{
    return this.httpClient.post<string>(this.apiUrl+"/nombreetudiant", donnee);
  }
  //enregistre
  inscrireEtudiant(inscrire: any): Observable<number> {
    return this.httpClient.post<number>(this.apiUrl+"/enregistre", inscrire);
  }
}
