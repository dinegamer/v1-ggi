import { TestBed } from '@angular/core/testing';

import { AttestationPdfService } from '../services/attestation-pdf.service';

describe('AttestationPdfService', () => {
  let service: AttestationPdfService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AttestationPdfService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
