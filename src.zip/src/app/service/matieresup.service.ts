import { Injectable } from "@angular/core";
import { environment } from "../../environments/environment";
import { HttpClient } from "@angular/common/http";
import { Matieresup } from "../model/matieresup.model";
import { Observable } from "rxjs";


@Injectable({
  providedIn: 'root'
})
export class MatieresupService {

  readonly apiUrl = environment.apiURL;

  constructor(private httpClient: HttpClient) { }

  getAllMatieresup(): Observable<Matieresup[]>{
    return this.httpClient.get<Matieresup[]>(this.apiUrl+"/matieresups");
  }
  ListeMFS(donnee: any): Observable<Matieresup>{
    return this.httpClient.post<Matieresup>(this.apiUrl+"/matieresups/semestreandfiliere", donnee)
  }
  ListeMFSU(donnee: any): Observable<Matieresup>{
    return this.httpClient.post<Matieresup>(this.apiUrl+"/matieresups/semestreandfiliereue", donnee)
  }
  save(donnee: any): Observable<Matieresup>{
    return this.httpClient.post<Matieresup>(this.apiUrl+"/save", donnee)
  }
}
