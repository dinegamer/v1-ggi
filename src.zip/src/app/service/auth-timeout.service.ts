import { Injectable, NgZone } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthTimeoutService {

  private timeoutId: any;
  private readonly TIMEOUT_DURATION = 15 * 60 * 1000; // 15 minutes

  constructor(private router: Router, private ngZone: NgZone) {
    this.resetTimer();
    this.listenToUserActivity();
  }

  // 🔄 Réinitialise le timer à chaque activité
  private resetTimer() {
    clearTimeout(this.timeoutId);
    this.timeoutId = setTimeout(() => this.logout(), this.TIMEOUT_DURATION);
  }

  // 🔄 Écoute les événements utilisateurs
  private listenToUserActivity() {
    ['mousemove', 'keydown', 'click', 'scroll'].forEach(event => {
      document.addEventListener(event, () => this.resetTimer());
    });
  }

  // 🚪 Déconnecte l'utilisateur
  private logout() {
    this.ngZone.run(() => {
      localStorage.removeItem('token'); // Supprime le token
      this.router.navigate(['/login']); // Redirige vers login
    });
  }
}
