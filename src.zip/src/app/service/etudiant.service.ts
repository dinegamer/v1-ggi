import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Etudiant } from '../model/etudiant.model'
import { environment } from '../../environments/environment';


@Injectable({
  providedIn: 'root'
})
export class EtudiantService {

  readonly apiUrl = environment.apiURL+"/etudiants";

  constructor(private httpClient: HttpClient) { }

  rechercherEtudiants(filters: any): Observable<any[]> {
    return this.httpClient.get<any[]>(this.apiUrl+"/search", { params: filters });
  }

  getEtudiantParMatricule(matricule: any): Observable<{ message: string }>{
    return this.httpClient.get<{ message: string }>(this.apiUrl+"/"+matricule);
  }

  getEtudiants(): Observable<Etudiant[]>{
    return this.httpClient.get<Etudiant[]>(this.apiUrl)
  }
  //enregistre un etudiant
  saveEtudiant(donnee: any): Observable<{ message: string }>{
    return this.httpClient.post<{ message: string }>(this.apiUrl+"/save", donnee)
  }
  //retourner l'etudiant a partir de son id
  getEtudiantById(id: number): Observable<any> {
    return this.httpClient.get(this.apiUrl+"/id/"+id);
  }
  getEtudiantDetails(id: any, an: any): Observable<any> {
    return this.httpClient.get<any>(this.apiUrl+"/"+id+"/"+an+"/details");
  }
  TransfereEtudiantEntreClasse(donnee: any) : Observable<any>{
    return this.httpClient.post<any>(this.apiUrl+"/tranfereEntreClasse", donnee);
  }
  update(id: number, etudiant: Etudiant): Observable<any>{
    return this.httpClient.put<any>(this.apiUrl+"/"+id, etudiant);
  }
}
