import { Injectable } from "@angular/core";
import { environment } from "../../environments/environment";
import { HttpClient } from "@angular/common/http";
import { Semestre } from "../model/semestre.model";
import { Observable } from "rxjs";


@Injectable({
  providedIn: 'root'
})
export class SemestreService {
  readonly apiUrl = environment.apiURL;

  constructor(private httpClient: HttpClient) { }

  getAllSemestre(): Observable<Semestre[]>{
    return this.httpClient.get<Semestre[]>(this.apiUrl+"/semestres")
  }
  RetournerUnSemestre(id: any): Observable<Semestre>{
    return this.httpClient.get<Semestre>(this.apiUrl+'/semestres/'+id)
  }
}
