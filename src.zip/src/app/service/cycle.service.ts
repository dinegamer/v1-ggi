import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Cycle } from '../model/cycle.model';
import { environment } from '../../environments/environment';
@Injectable({
  providedIn: 'root'
})
export class CycleService {

  readonly apiUrl = environment.apiURL+"/cycles";

  constructor(private httpClient: HttpClient) { }

  getAllCycle(): Observable<Cycle[]>{
    return this.httpClient.get<Cycle[]>(this.apiUrl);
  }
  create(cycle: Cycle): Observable<Cycle> {
    return this.httpClient.post<Cycle>(this.apiUrl, cycle);
  }

  update(id: number, cycle: Cycle): Observable<Cycle> {
    return this.httpClient.put<Cycle>(`${this.apiUrl}/${id}`, cycle);
  }
  delete(id: number): Observable<void> {
    return this.httpClient.delete<void>(`${this.apiUrl}/${id}`);
  }
}
