import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Fraixscolaire } from '../model/fraixscolaire.model';
import { environment } from '../../environments/environment';
import { FraisParFiliere } from '../donnees/FraisParFiliere';
import { FraisParSite } from '../donnees/FraisParSite';



@Injectable({
  providedIn: 'root'
})
export class FraixscolaireService {

  readonly apiUrl = environment.apiURL+"/frais";

  constructor(private httpClient: HttpClient) { }
  //les frais par site
  getFraiParSite(site: number,an: number): Observable<FraisParSite>{
    return this.httpClient.get<FraisParSite>(this.apiUrl+"/fraisparsite/"+site+"/"+an);
  }
  //les frais d'un filiere
  getFraiParFiliere(site: number,an: number,cours: any,filiere: any): Observable<FraisParFiliere>{
    return this.httpClient.get<FraisParFiliere>(this.apiUrl+"/fraisparfiliere/"+site+"/"+an+"/"+cours+"/"+filiere)
  }
  getAll(): Observable<any> {
    return this.httpClient.get(this.apiUrl);
  }
  //les frais d'un etudiant
  fraisetudiant(etudiantId: number): Observable<Fraixscolaire[]>{
    return this.httpClient.get<Fraixscolaire[]>(this.apiUrl+"/fraisetudiant/"+etudiantId)
  }
  //recherche frai
  getFraiDeEtudiant(donne: any): Observable<any>{
    return this.httpClient.post<any>(this.apiUrl+"/search", donne);
  }

  getById(id: number): Observable<any> {
    return this.httpClient.get(`${this.apiUrl}/${id}`);
  }

  create(frais: any): Observable<any> {
    return this.httpClient.post(this.apiUrl, frais);
  }

  update(id: number, frais: any): Observable<any> {
    return this.httpClient.put(`${this.apiUrl}/${id}`, frais);
  }

  delete(id: number): Observable<any> {
    return this.httpClient.delete(this.apiUrl+"/"+id);
  }
 
}
