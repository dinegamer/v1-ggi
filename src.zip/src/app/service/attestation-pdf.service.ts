import { Injectable } from '@angular/core';
import { jsPDF } from 'jspdf';
import { Etudiant } from '../model/etudiant.model';
import { User } from '../model/user.model';
import { Filiere } from '../model/filiere.model';
import { Anneeuv } from '../model/anneeuv.model';

@Injectable({
  providedIn: 'root'
})
export class AttestationPdfService {
  constructor() {}

  async generatePDF(
    etudiant: Etudiant,
    mentionE: string,
    user: User,
    filiere: Filiere,
    annee: Anneeuv
  ): Promise<void> {
    const mention = this.getMentionFromStatus(mentionE);
    const images = await this.loadImages();

    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();

    // Ajouter les bordures
    doc.addImage(images.imgTop, 'PNG', 8, 13, pageWidth - 20, 7);
    doc.addImage(images.imgBottom, 'PNG', 8, pageHeight - 20, pageWidth - 20, 7);
    doc.addImage(images.imgLeft, 'PNG', 10, 20, 5, pageHeight - 40);
    doc.addImage(images.imgRight, 'PNG', pageWidth - 19, 20, 5, pageHeight - 40);

    // En-tête administrative
    doc.setFont('Times', 'normal');
    doc.setFontSize(12);
    doc.text("MINISTERE DE L'ENSEIGNEMENT SUPERIEUR", 20, 25);
    doc.text("ET DE LA RECHERCHE SCIENTIFIQUE", 23, 30);
    doc.text("************************", 25, 35);
    doc.text("REPUBLIQUE DU MALI", 137, 25);
    doc.text("Un Peuple - Un But - Une Foi", 135, 30);
    doc.text("*********************", 137, 35);

    doc.addImage(images.imgLogo, 'PNG', 25, 37, 25, 25);
    doc.addImage(images.imgLogo, 'PNG', 155, 37, 25, 25);

    doc.setTextColor(0, 0, 255);
    doc.setFontSize(12);
    doc.text("INSTITUT SUPERIEUR DES TECHNIQUE ECONOMIQUES", 47, 42);
    doc.text("COMPTABLES ET COMMERCIALES - INTEC SUP", 52, 47);

    doc.setTextColor(0, 0, 0);
    doc.setFont('Times', 'bold');
    doc.setFontSize(12);
    doc.text("Etablissement Supérieur d'Enseignement Professionnel", 52, 55);

    doc.setFont('Times', 'normal');
    doc.setFontSize(6);
    doc.text(user.administrateur.site.adresse, 25, 65);

    doc.setLineWidth(0.5);
    doc.line(15, 67, 190, 67);

    doc.setTextColor(0, 0, 255);
    doc.setFont('Times', 'bold');
    doc.setFontSize(20);
    doc.text("ATTESTATION DE DIPLÔME", 50, 80);

    doc.setTextColor(0, 0, 0);
    doc.setFont('Times', 'normal');
    doc.setFontSize(12);

    // Texte principal
    const yStart = 95;
    const lineHeight = 12;
    let y = yStart;
    const fullName = `${etudiant.prenom} ${etudiant.nom}`;

    doc.text(`Je soussigné, Monsieur ${user.administrateur.prenom} ${user.administrateur.nom}, ${user.administrateur.role.description}`, 20, y); y += lineHeight;
    doc.text(`de l'Institut Supérieur des Techniques Economiques, Comptables et Commerciales (INTEC SUP),`, 20, y); y += lineHeight;
    doc.text(`atteste par la présente que :`, 20, y); y += lineHeight;
    doc.setFont('Times', 'bold');
    doc.text(`Mll/Mme ${fullName} né(e) le ${etudiant.naissance}`, 20, y); y += lineHeight;
    doc.setFont('Times', 'normal');
    doc.text(`a validé les modules du ${filiere.cycle.nom} en ${filiere.departement.nom}`, 20, y); y += lineHeight;
    doc.text(`Filière : ${filiere.description}`, 20, y); y += lineHeight;
    doc.text(`Au titre de l'année universitaire ${annee.nom}      Mention : ${mention}`, 20, y); y += lineHeight;
    doc.text(`Cette attestation lui est délivrée pour servir et valoir ce que de droit.`, 20, y); y += lineHeight * 2;

    // Signature
    const today = new Date();
    const formattedDate = today.toLocaleDateString('fr-FR');
    doc.text(`Fait à Bamako, le ${formattedDate}`, 120, 210);
    doc.setFont('Times', 'bold');
    doc.text(user.administrateur.role.description, 130, 215);
    doc.text(`M. ${user.administrateur.prenom} ${user.administrateur.nom}`, 120, 235);

    doc.setFont('Times', 'normal');
    doc.setFontSize(10);
    doc.text("NB : Il n'est délivré qu'un seul exemplaire de cette attestation.", 20, 250);

    doc.setFontSize(6);
    doc.text(user.administrateur.site.adresse, 20, 270);

    // Affichage
    const blob = doc.output('blob');
    const blobUrl = URL.createObjectURL(blob);
    window.open(blobUrl, '_blank');
  }

  // Mention selon le statut
  private getMentionFromStatus(status: string): string {
    return status === 'Admis' ? 'Assez Bien' : status;
  }

  // Chargement des images en parallèle
  private loadImages(): Promise<{
    imgTop: HTMLImageElement;
    imgBottom: HTMLImageElement;
    imgLeft: HTMLImageElement;
    imgRight: HTMLImageElement;
    imgLogo: HTMLImageElement;
  }> {
    const loadImage = (src: string): Promise<HTMLImageElement> => {
      return new Promise((resolve, reject) => {
        const img = new Image();
        img.src = src;
        img.onload = () => resolve(img);
        img.onerror = (err) => reject(err);
      });
    };

    return Promise.all([
      loadImage('assets/images/border.png'),       // imgTop
      loadImage('assets/images/border.png'),       // imgBottom
      loadImage('assets/images/bordergd.png'),     // imgLeft
      loadImage('assets/images/bordergd.png'),     // imgRight
      loadImage('assets/images/logo.png')          // imgLogo
    ]).then(([imgTop, imgBottom, imgLeft, imgRight, imgLogo]) => ({
      imgTop,
      imgBottom,
      imgLeft,
      imgRight,
      imgLogo
    }));
  }
}
