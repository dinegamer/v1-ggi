import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Filiere } from '../model/filiere.model';

@Injectable({
  providedIn: 'root'
})
export class FiliereService {

  private apiUrl = environment.apiURL+"/filieres";

  constructor(private httpClient: HttpClient) { }
  //tout les filieres
  getAllFilieres(): Observable<Filiere[]>{
    return this.httpClient.get<Filiere[]>(this.apiUrl);
  }
  //filiere pour le cycle 4
  getFiliereParCycle(cycle: any): Observable<Filiere[]>{
    return this.httpClient.post<Filiere[]>(this.apiUrl+"/filieresparcycle", cycle)
  }

  save(filiere: Filiere): Observable<Filiere> {
    return this.httpClient.post<Filiere>(this.apiUrl, filiere);
  }

  update(filiere: Filiere): Observable<Filiere> {
    return this.httpClient.put<Filiere>(this.apiUrl, filiere);
  }

  delete(id: number): Observable<void> {
    return this.httpClient.delete<void>(`${this.apiUrl}/${id}`);
  }

}
