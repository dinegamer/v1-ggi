import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { environment } from "../../environments/environment";
import { Ecole } from "../model/ecole.model";
import { Injectable } from "@angular/core";

@Injectable({
  providedIn: 'root'
})
export class EcoleService{

    readonly apiUrl = environment.apiURL;

    constructor(private httpClient: HttpClient){}

    getAllEcole(): Observable<Ecole[]>{
        return this.httpClient.get<Ecole[]>(this.apiUrl+"/ecoles");
    }
    
  getById(id: number): Observable<Ecole> {
    return this.httpClient.get<Ecole>(`${this.apiUrl}/${id}`);
  }

  save(ecole: Ecole): Observable<Ecole> {
    return this.httpClient.post<Ecole>(this.apiUrl, ecole);
  }

  update(id: number, ecole: Ecole): Observable<Ecole> {
    return this.httpClient.put<Ecole>(`${this.apiUrl}/${id}`, ecole);
  }

  delete(id: number): Observable<void> {
    return this.httpClient.delete<void>(`${this.apiUrl}/${id}`);
  }
}