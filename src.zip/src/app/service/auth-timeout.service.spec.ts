import { TestBed } from '@angular/core/testing';

import { AuthTimeoutService } from './auth-timeout.service';

describe('AuthTimeoutService', () => {
  let service: AuthTimeoutService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AuthTimeoutService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
