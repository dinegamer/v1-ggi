export const environment = {
    production: false,
    apiURL: 'http://localhost:8080'
    //apiURL: 'http://groupeintec-gestionplus.org'
};
