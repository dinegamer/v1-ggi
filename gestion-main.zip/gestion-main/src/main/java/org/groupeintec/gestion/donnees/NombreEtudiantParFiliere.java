package org.groupeintec.gestion.donnees;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.groupeintec.gestion.model.Filiere;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NombreEtudiantParFiliere {
    private Filiere filiere;
    private int nombreEtudiant;
}
