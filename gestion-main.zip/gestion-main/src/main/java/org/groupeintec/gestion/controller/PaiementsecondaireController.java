package org.groupeintec.gestion.controller;

import org.groupeintec.gestion.model.Paiementsecondaire;
import org.groupeintec.gestion.service.PaiementsecondaireService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/paiementsecondaires")
public class PaiementsecondaireController {
    @Autowired
    private PaiementsecondaireService service;
    @GetMapping
    public ResponseEntity<List<Paiementsecondaire>> getAllPaiement(){
        return ResponseEntity.ok(service.paiementsecondaires());
    }
}
