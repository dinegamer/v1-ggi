package org.groupeintec.gestion.repository;

import org.groupeintec.gestion.model.Anneeuv;
import org.groupeintec.gestion.model.Filiere;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FiliereRepository extends JpaRepository<Filiere, Integer> {
    public List<Filiere> findByOrderByNomAsc();
    //filiers par cycle choisi
    @Query("SELECT f FROM Filiere f WHERE f.cycle.id = :cycle ORDER BY f.nom ASC")
    List<Filiere> filieresparcycle(@Param("cycle") int cycle);
}
