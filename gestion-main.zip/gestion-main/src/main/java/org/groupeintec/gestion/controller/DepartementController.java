package org.groupeintec.gestion.controller;

import org.groupeintec.gestion.model.Departement;
import org.groupeintec.gestion.repository.DepartementRepository;
import org.groupeintec.gestion.service.DepartementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/departements")
public class DepartementController {
    @Autowired
    private DepartementService service;
    @GetMapping
    public ResponseEntity<List<Departement>> getAllDepartement(){
        return ResponseEntity.ok(service.getAllDepartement());
    }
    @GetMapping("/{id}")
    public Departement getById(@PathVariable int id) {
        return service.getById(id);
    }

    @PostMapping
    public Departement save(@RequestBody Departement d) {
        return service.save(d);
    }

    @PutMapping
    public Departement update(@RequestBody Departement d) {
        return service.update(d);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable int id) {
        service.delete(id);
    }
}
