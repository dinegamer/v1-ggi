package org.groupeintec.gestion.repository;

import org.groupeintec.gestion.model.Controle;
import org.groupeintec.gestion.model.Inscrire;
import org.groupeintec.gestion.model.Semestre;
import org.groupeintec.gestion.model.Typeue;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ControleRepository extends JpaRepository<Controle, Integer> {
    //mise a jour de note
    @Query("SELECT i FROM Controle i WHERE i.anneeuv.id = 8")
    List<Controle> findAllAnneeuvControles();
    @Query("SELECT i FROM Controle i, Ue u, Typeue tu WHERE i.anneeuv.id = :an AND i.filiere.id = :filiere " +
            " AND i.etudiant.id = :etudiant AND i.semestre.id = :semestre  AND i.matieresup.ue = u AND u.typeue = :tu")
    List<Controle> releveretudiant(int an, int filiere, int etudiant, int semestre, Typeue tu);
    @Query("SELECT i FROM Controle i, Matieresup m, Ue u, Typeue tu WHERE i.anneeuv.id = :an AND i.filiere.id = :filiere " +
            " AND i.etudiant.id = :etudiant AND i.semestre.id = :semestre AND i.matieresup = m AND m.ue = u")
    List<Controle> releveretudiantsemestre(int an, int filiere, int etudiant, int semestre);
    //retrouver un controle
    @Query("SELECT c FROM Controle c WHERE c.filiere.id = :filiere AND c.anneeuv.id = :annee AND c.etudiant.id = :etudiant AND c.matieresup.id = :matiere AND c.semestre.id = :semestre")
    Optional<Controle> rechercheControle(int filiere, int annee, int etudiant, int matiere, int semestre);
    //note par classe
    @Query("SELECT c FROM Controle c, Inscrire i WHERE c.anneeuv.id = :an AND c.semestre.id = :semestre " +
            " AND c.matieresup.id = :matiere AND c.filiere.id = :filiere AND i.rive.id = :site" +
            " AND i.anneeuv.id = c.anneeuv.id AND i.filiere.id = c.filiere.id AND c.etudiant.id = i.etudiant.id" +
            " AND i.cours = :cours")
    List<Controle> controleparclasse(int an, int semestre, int matiere, int filiere, int site, String cours);

    @Query("SELECT c FROM Controle c, Inscrire i WHERE c.anneeuv.id = :an AND c.semestre.id = :semestre AND c.filiere.id = :filiere" +
            " AND i.cours = :cours AND i.anneeuv.id = c.anneeuv.id AND i.filiere.id = c.filiere.id AND c.etudiant.id = i.etudiant.id" +
            " AND i.rive.id = :site")
    List<Controle> controleParTypeue(String cours, int site, int an, int filiere, int semestre);

}
