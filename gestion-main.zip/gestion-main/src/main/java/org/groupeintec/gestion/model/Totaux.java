package org.groupeintec.gestion.model;

public class Totaux {
    private Long nombreInscrit;
    private Long totalFrais;
    private Long totalPaie;
    private Long totalReduction;
    private Long totalReliquat;
    private Long totalReliquatp;

    public Totaux() {

    }

    public Long getNombreInscrit() {
        return nombreInscrit;
    }

    public void setNombreInscrit(Long nombreInscrit) {
        this.nombreInscrit = nombreInscrit;
    }

    public Long getTotalFrais() {
        return totalFrais;
    }

    public void setTotalFrais(Long totalFrais) {
        this.totalFrais = totalFrais;
    }

    public Long getTotalPaie() {
        return totalPaie;
    }

    public void setTotalPaie(Long totalPaie) {
        this.totalPaie = totalPaie;
    }

    public Long getTotalReduction() {
        return totalReduction;
    }

    public void setTotalReduction(Long totalReduction) {
        this.totalReduction = totalReduction;
    }

    public Long getTotalReliquat() {
        return totalReliquat;
    }

    public void setTotalReliquat(Long totalReliquat) {
        this.totalReliquat = totalReliquat;
    }

    public Long getTotalReliquatp() {
        return totalReliquatp;
    }

    public void setTotalReliquatp(Long totalReliquatp) {
        this.totalReliquatp = totalReliquatp;
    }
}
