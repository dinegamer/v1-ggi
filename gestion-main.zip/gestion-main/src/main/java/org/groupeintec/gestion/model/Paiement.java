package org.groupeintec.gestion.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "paiement")
public class Paiement {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private int montant;
    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "etudiant")
    private Etudiant etudiant;

    private String datepaie;
    private String dateaction;
    private String enlettre;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "anneunv")
    private Anneeuv anneunv;
    private String motif;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "filiere")
    private Filiere filiere;

    @Column(name = "reliquat", nullable = true)
    private boolean reliquat;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "anneeuvreliquat", nullable = true)
    private Anneeuv anneeuvreliquat;

}
