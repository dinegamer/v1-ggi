package org.groupeintec.gestion.donnees;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Statistiqueparclasse {
    private List<StatistiqueParEtudiant> statistiqueParEtudiants;
    private int totalfrais;
    private int totalreduction;
    private int totaldue;
    private int montantpaie;
    private int resteapaie;
    private double pourcentage;
}
