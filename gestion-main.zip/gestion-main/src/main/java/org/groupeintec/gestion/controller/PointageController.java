package org.groupeintec.gestion.controller;

import org.groupeintec.gestion.model.Pointage;
import org.groupeintec.gestion.service.PointageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/pointages")
public class PointageController {
    @Autowired
    private PointageService pointageService;
    @GetMapping
    public ResponseEntity<List<Pointage>> getAllPointage(){
        return ResponseEntity.ok(pointageService.pointages());
    }
}
