package org.groupeintec.gestion.controller;

import org.groupeintec.gestion.dto.NoteExamenEtudiantDTO;
import org.groupeintec.gestion.dto.TypeUEDTO;
import org.groupeintec.gestion.model.*;

import org.groupeintec.gestion.service.ControleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/controles")
public class ControleController {
    @Autowired
    private ControleService controleService;
    @GetMapping
    public ResponseEntity<List<Controle>> getAllControles(){
        return ResponseEntity.ok(controleService.ControleParAnnee());
    }
    @PostMapping("/ajoutnoteetudiant")
    public ResponseEntity<Map<String, String>> AjoutNoteEtudiant(@RequestBody String[] search){
        Map<String, String> response = controleService.EnregistreNote(search);
        return ResponseEntity.ok(response);
    }
    @PostMapping("/verifiernotedunetudiant")
    public ResponseEntity<Map<String, Object>> verifier(@RequestBody String[] donnees){
        Map<String, Object> response = controleService.verifierNote(donnees);
        return ResponseEntity.ok(response);
    }
    @PutMapping("/updatenoteetudiant")
    public ResponseEntity<Map<String, String>> update(@RequestBody String[] donnees){
        Map<String, String> response = controleService.updateNote(donnees);

        return ResponseEntity.ok(response);
    }
    //relever par classe
    @PostMapping("/releveparclasse")
    public ResponseEntity<List<TypeUEDTO>> releveParClasse(@RequestBody String[] donnees){
        int cours = Integer.parseInt(donnees[0]); int site = Integer.parseInt(donnees[3]);
        int anneeId = Integer.parseInt(donnees[4]); int filiereId = Integer.parseInt(donnees[1]); int semestreId = Integer.parseInt(donnees[2]);
        List<TypeUEDTO> releve = controleService.getReleveParTypeU(cours, site, anneeId, filiereId, semestreId);
        return ResponseEntity.ok(releve);
    }
    /* @PostMapping("/releveretudiant")
     public ResponseEntity<List<Releveretudiant>> releveretudiantControle(@RequestBody Integer[] search){
         int an = search[0];
         int filiere = search[1];
         int etudiant = search[2];
         int semestre = search[3];
         return ResponseEntity.ok(controleService.ReleverEtudiant(an, filiere, etudiant, semestre));
     }*/
    @PostMapping("/noteparsemestre")
    public ResponseEntity<NoteParSemestre> noteparsemestre(@RequestBody Integer[] search){
        int an = search[0];
        int filiere = search[1];
        int etudiant = search[2];
        int semestre = search[3];
        return ResponseEntity.ok(controleService.noteParSemestre(an, filiere, etudiant, semestre));
    }
    @PostMapping("/notes")
    public ResponseEntity<List<Controle>> notes(@RequestBody String[] donnees){
        return ResponseEntity.ok(controleService.notes(donnees));
    }
    @PostMapping("/noteparclasse")
    public ResponseEntity<List<Controle>> controleparclasse(@RequestBody int[] search){
        int annee = search[0];
        int filiere = search[1];
        int cours = search[2];
        int semestre = search[3];
        int matiere = search[4];
        int site = search[5];
        return ResponseEntity.ok(controleService.controleparclasse(annee, semestre, matiere, filiere, site, cours));
    }
    @PostMapping("/notedutun")
    public ResponseEntity<List<NoteDutUn>> notedutun(@RequestBody int[] search){
        int annee = search[0];
        int filiere = search[1];
        int cours = search[2];
        int sun = search[3];
        int sdeux = search[4];
        int site = search[5];
        //System.out.println("mdt ** "+search);
        return ResponseEntity.ok(controleService.NoteDutUn(annee, filiere, cours, sun, sdeux, site));
    }
    @PostMapping("/notedutdeux")
    public ResponseEntity<List<NoteDutDeux>> notedutdeux(@RequestBody int[] search){
        int annee = search[0];
        int filiere = search[1];
        int cours = search[2];
        int sun = search[3];
        int sdeux = search[4];
        int site = search[5];
        //System.out.println("mdt ** "+search);
        return ResponseEntity.ok(controleService.NoteDutDeux(annee, filiere, cours, sun, sdeux, site));
    }
    //statistique
    @PostMapping("/statistique")
    public ResponseEntity<List<Statistique>> statistique(@RequestBody int[] search){
        int annee = search[0];
        int site = search[1];
        int cycle = search[2];
        //System.out.println("mdt ** "+controleService.Statistique(annee,site,cycle));
        return ResponseEntity.ok(controleService.Statistique(annee,site,cycle));
    }
    /*notedutdeux
    @PostMapping("/noteparcycle")
    public ResponseEntity<List<ControleParCycle>> controleparcycle(@RequestBody String[] search){
        String annee = search[0];
        String filiere = search[1];
        String cours = search[2];
        String semestrea = search[3];
        String semestreb = search[4];
        //System.out.println("test mdt 123 * "+cycle+" * "+cours);
        return ResponseEntity.ok(controleService.ControleParCycle(annee, filiere, cours, semestrea, semestreb));
    }*/
    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, String>> deleteControle(@PathVariable int id) {
        Map<String, String> response = new HashMap<>();
        System.out.println(id+" nnnnnn ");
        controleService.deleteControle(id);
        response.put("message","Contrôle supprimé avec succès !");
        return ResponseEntity.ok(response);
    }
    // Supprimer toutes les notes
    @DeleteMapping("/all")
    public ResponseEntity<Map<String, String>> deleteAllControles(@RequestBody int[] search) {
        Map<String, String> response = new HashMap<>();
        int annee = search[0];
        int filiere = search[1];
        int cours = search[2];
        int semestre = search[3];
        int matiere = search[4];
        int site = search[5];
        List<Controle> controles = controleService.controleparclasse(annee, semestre, matiere, filiere, site, cours);
        controleService.deleteAllControles(controles);
        response.put("status", "success");
        response.put("message", String.valueOf(controles.stream().count())+" note(s) Supprimer avec succès !");
        return ResponseEntity.ok(response);
    }
    //note d'examen d'un étudiant
    @GetMapping("/examen/{inscrire}")
    public ResponseEntity<Map<String, Object>> noteExamenEtudiant(@PathVariable int inscrire){
        Map<String, Object> response = new HashMap<>();
        NoteExamenEtudiantDTO noteExamen = controleService.NoteExamenEtudiant(inscrire);
        // Vérifier si une note a été trouvée
        if (noteExamen != null) {
            response.put("status", "success");
            response.put("message", "Données récupérées avec succès");
            response.put("resultat", noteExamen);
            return ResponseEntity.ok(response);
        } else {
            response.put("status", "error");
            response.put("message", "Aucune note trouvée pour cet étudiant et cette filière");
            return ResponseEntity.status(404).body(response);
        }
    }

}