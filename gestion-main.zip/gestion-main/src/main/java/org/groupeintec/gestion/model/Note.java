package org.groupeintec.gestion.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.groupeintec.gestion.fonctions.Appreciation;

import java.math.BigDecimal;
import java.math.RoundingMode;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table
public class Note {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "periode")
    private Periode periode;
    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "matiere")
    private Matiere matiere;
    private BigDecimal noteClasse;
    private BigDecimal noteCompo;
    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "eleve")
    private Eleve eleve;
    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "ecole")
    private Ecole ecole;
    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "classe")
    private Classe classe;
    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "anneeuv")
    private Anneeuv anneeuv;

    public BigDecimal getMg(){
        //composition mutiplie par deux
        BigDecimal endeux = getNoteCompo().multiply(new BigDecimal(2));
        //deuxieme somme
        BigDecimal sdeux = getNoteClasse().add(endeux);
        //le tout diviser par 3
        BigDecimal divtroi = sdeux.divide(new BigDecimal(3), 2, RoundingMode.HALF_UP);
        return divtroi;
    }
    public BigDecimal getMgc(){
        BigDecimal coef = new BigDecimal(getMatiere().getCoefficient());
        BigDecimal moyennecof = getMg().multiply(coef);
        return moyennecof;
    }
    public String getMention(){
        Appreciation appreciation = new Appreciation();
        return appreciation.AppreciationSecondaire(getMg());
    }
}
