package org.groupeintec.gestion.donnees;

import lombok.Data;
import org.groupeintec.gestion.model.Anneeuv;
import org.groupeintec.gestion.model.Cycle;

@Data
public class EtatParCycle {

    private Cycle cycle;
    private int nombreEtudiant;
    private int chiffreAffaire;
    private int reduction;
    private int montantpaye;
    private int reliquat;
    private int reliquatpays;
}
