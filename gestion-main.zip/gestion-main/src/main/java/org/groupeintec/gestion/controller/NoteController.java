package org.groupeintec.gestion.controller;

import org.groupeintec.gestion.model.Bulletin;
import org.groupeintec.gestion.model.Matiere;
import org.groupeintec.gestion.model.Note;
import org.groupeintec.gestion.repository.MatiereRepository;
import org.groupeintec.gestion.repository.NoteRepository;
import org.groupeintec.gestion.service.NoteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/notes")
public class NoteController {
    @Autowired
    private NoteService noteService;
    @GetMapping
    public ResponseEntity<List<Note>> getAllNotes(){
        return ResponseEntity.ok(noteService.getAllNotes());
    }
    @PostMapping("/noteeleve")
    public ResponseEntity<Bulletin> NoteEleve(@RequestBody String[] search){
        String eleve = search[0]; String annee = search[1]; String periode = search[2];
        String classe = search[3]; String ecole = search[4];
        return ResponseEntity.ok(noteService.NoteEleve(eleve, annee, periode, classe, ecole));
    }
}
