package org.groupeintec.gestion.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NoteParTypeUe {
    private Typeue typeue;
    private List<Releveretudiant> releveretudiants;
    private BigDecimal mgtypeue;
    private BigDecimal credittypeue;
    private String mentiontypeue;
    private String appreciationtypeue;
}
