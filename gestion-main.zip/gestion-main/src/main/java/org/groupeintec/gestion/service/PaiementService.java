package org.groupeintec.gestion.service;

import org.groupeintec.gestion.donnees.StatistiqueParEtudiant;
import org.groupeintec.gestion.donnees.Statistiqueparclasse;
import org.groupeintec.gestion.model.*;
import org.groupeintec.gestion.repository.InscrireRepository;
import org.groupeintec.gestion.repository.PaiementRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class PaiementService {
    @Autowired
    private PaiementRepository paiementRepository;
    @Autowired
    private FraixscolaireService fraixscolaireService;
    @Autowired
    private InscrireRepository inscrireRepository;
    public boolean existsPaiement(int etudiant,int anneunv,int filiere,int montant, String datepaie){
        return paiementRepository.existsPaiement(etudiant,anneunv,filiere,montant, datepaie);
    }
    public Map<String, String> savePaiement(Paiement paiement) {
        Map<String, String> response = new HashMap<>();

        if (existsPaiement(paiement.getEtudiant().getId(), paiement.getAnneunv().getId(), paiement.getFiliere().getId(), paiement.getMontant(), paiement.getDatepaie())) {
           response.put("message","Paiement déjà existant pour cet étudiant et cette année avec le meme montant !");
           return response;
        }else {
            paiementRepository.save(paiement);
            response.put("message","Paiement enregistre avec success ! Merci");
            return response;
        }
    }
    public List<Paiement> paiementEtudiant(int etudiant, int filiere, int an){
        List<Paiement> paiements = paiementRepository.statistiqueEtudiant(etudiant, filiere, an);
        return paiements;
    }
    //paiement par classe
    public Statistiqueparclasse statistiqueparclasse(int site, int filiere, int an, int cours){
        Statistiqueparclasse statistiqueparclasse = new Statistiqueparclasse();
        List<StatistiqueParEtudiant> statistiqueParEtudiants = new ArrayList<>();
        String cour;
        if(cours==1){cour="Jour";}else{cour="Soir";}
        List<Inscrire> inscrires = inscrireRepository.EtudiantParClasse(an,cour,filiere,site);
        //System.out.println(" mdt ** "+an+" "+cour+" "+filiere+" "+site);
        for (Inscrire inscrire: inscrires){
            StatistiqueParEtudiant statistiqueParEtudiant = statistiqueParEtudiant(inscrire.getEtudiant().getId(),filiere,an,cours,site);
            statistiqueParEtudiants.add(statistiqueParEtudiant);
            statistiqueParEtudiant.setEtudiant(inscrire.getEtudiant());
        }
        //frai total frais
        int totalfrais = statistiqueParEtudiants.stream().mapToInt(StatistiqueParEtudiant::getFrais).sum();
        statistiqueparclasse.setTotalfrais(totalfrais);
        //reduction total
        int totalreduction = statistiqueParEtudiants.stream().mapToInt(StatistiqueParEtudiant::getReduction).sum();
        statistiqueparclasse.setTotalreduction(totalreduction);
        //total due
        int totaldue = totalfrais-totalreduction;
        statistiqueparclasse.setTotaldue(totaldue);
        //total paie
        int totalpaie = statistiqueParEtudiants.stream().mapToInt(StatistiqueParEtudiant::getPaie).sum();
        statistiqueparclasse.setMontantpaie(totalpaie);
        //total reste
        int totalreste = statistiqueParEtudiants.stream().mapToInt(StatistiqueParEtudiant::getReste).sum();
        statistiqueparclasse.setResteapaie(totalreste);
        if (totaldue != 0) {
            double pourcentage = ((double) totalpaie / totaldue) * 100;
            pourcentage = Math.round(pourcentage * 100.0) / 100.0;
            statistiqueparclasse.setPourcentage(pourcentage);
        } else {
            statistiqueparclasse.setPourcentage(0.0);
        }

        statistiqueparclasse.setStatistiqueParEtudiants(statistiqueParEtudiants);
        return statistiqueparclasse;
    }

    //montant paie par etudiant
    public StatistiqueParEtudiant statistiqueParEtudiant(int etudiant, int filiere, int an, int cours, int site){
        StatistiqueParEtudiant statistiqueParEtudiant = new StatistiqueParEtudiant();

        List<Paiement> paiements = paiementRepository.statistiqueEtudiant(etudiant,filiere,an);
        statistiqueParEtudiant.setPaiements(paiements);

        int frais = fraixscolaireService.getUniqueFrais(an, cours, filiere, site, etudiant);
        statistiqueParEtudiant.setFrais(frais);
        //total paie
        int paie = paiements.stream().mapToInt(Paiement::getMontant).sum();
        statistiqueParEtudiant.setPaie(paie);
        int reduction = fraixscolaireService.getUniqueReduction(an, cours, filiere, site, etudiant);
        statistiqueParEtudiant.setReduction(reduction);
        int due = frais-reduction;
        statistiqueParEtudiant.setDue(due);
        int reste = due-paie;
        statistiqueParEtudiant.setReste(reste);
        double pourcentage = ( (double) paie/due)*100;
        statistiqueParEtudiant.setPourcentage(pourcentage);
        return statistiqueParEtudiant;
    }

    public List<Paiement> paieParEtudiant(int etudiantId) {
        return paiementRepository.findByEtudiantId(etudiantId);
    }
    //paiement par classe
}
