package org.groupeintec.gestion.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Classeecole {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "classe")
    @JsonIgnoreProperties("classeecoles")
    private Classe classe;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "ecole")
    @JsonIgnoreProperties("classeecoles")
    private Ecole ecole;
}
