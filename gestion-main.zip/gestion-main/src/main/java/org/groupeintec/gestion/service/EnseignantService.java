package org.groupeintec.gestion.service;

import org.groupeintec.gestion.model.Enseignant;
import org.groupeintec.gestion.repository.EnseignantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EnseignantService {

    @Autowired
    private EnseignantRepository enseignantRepository;

    public List<Enseignant> getAllEnseignants() {
        return enseignantRepository.findAll();
    }

    public Optional<Enseignant> getEnseignantById(int id) {
        return enseignantRepository.findById(id);
    }

    public Enseignant createEnseignant(Enseignant enseignant) {
        return enseignantRepository.save(enseignant);
    }

    public Enseignant updateEnseignant(int id, Enseignant enseignantDetails) {
        Enseignant enseignant = enseignantRepository.findById(id).orElseThrow(() -> new RuntimeException("Enseignant non trouvé"));
        enseignant.setMatricule(enseignantDetails.getMatricule());
        enseignant.setNom(enseignantDetails.getNom());
        enseignant.setPrenom(enseignantDetails.getPrenom());
        enseignant.setAdresse(enseignantDetails.getAdresse());
        enseignant.setTelephone(enseignantDetails.getTelephone());
        enseignant.setEmail(enseignantDetails.getEmail());
        enseignant.setLieun(enseignantDetails.getLieun());
        enseignant.setDatedn(enseignantDetails.getDatedn());
        enseignant.setPhoto(enseignantDetails.getPhoto());
        enseignant.setEcole(enseignantDetails.getEcole());
        enseignant.setTarif(enseignantDetails.getTarif());
        return enseignantRepository.save(enseignant);
    }

    public void deleteEnseignant(int id) {
        enseignantRepository.deleteById(id);
    }

    public List<Enseignant> getByEcoleId(long ecoleId) {
        return enseignantRepository.findByEcoleIdEcole(ecoleId);
    }
}