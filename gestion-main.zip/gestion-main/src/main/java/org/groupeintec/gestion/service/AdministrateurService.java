package org.groupeintec.gestion.service;

import org.groupeintec.gestion.model.*;
import org.groupeintec.gestion.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AdministrateurService {
    @Autowired
    private AdministrateurRepository administrateurRepository;
    @Autowired
    private RoleRepository roleRepository;
    @Autowired
    private SiteRepository siteRepository;
    @Autowired
    private EcoleRepository ecoleRepository;
    @Autowired
    private ParametreRepository parametreRepository;

    public User administrateur(String username, String password) {
        // 1️⃣ Rechercher l'administrateur par son username
        Administrateur administrateur = administrateurRepository.findByUsername(username);
        // 2️⃣ Vérifier si l'administrateur existe
        if (administrateur == null) {
            throw new RuntimeException("Invalid username or password 1");
        }

        // 3️⃣ Vérifier si le mot de passe est correct (si haché, utiliser BCrypt)
        //BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        if (!password.equals(administrateur.getPassword())) {
            throw new RuntimeException("Invalid username or password 2");
        }

        // 4️⃣ Récupérer le paramètre (id = 1)
        long id = 1;
        Parametre parametre = parametreRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Parametre non trouvé avec l'id : " + id));

        // 5️⃣ Créer l'objet User et assigner les valeurs
        User user = new User();
        user.setAdministrateur(administrateur);
        user.setParametre(parametre);

        // 6️⃣ Masquer le mot de passe avant de retourner l'utilisateur
        administrateur.setPassword(null);

        return user;
    }

    //identifier les admin du superieur
    public User authenticate(String username, String password) {

        Administrateur administrateur = administrateurRepository.findByUsername(username);
        if (administrateur == null) {
            throw new RuntimeException("Invalid username or password 1");
        }
        if (!password.equals(administrateur.getPassword())) {
            throw new RuntimeException("Invalid username or password 2");
        }
        long id = 1;
        Parametre parametre = parametreRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Parametre non trouvé avec l'id : " + id));
        // 5️⃣ Créer l'objet User et assigner les valeurs
        User user = new User();
        user.setAdministrateur(administrateur);
        user.setParametre(parametre);
        // 6️⃣ Masquer le mot de passe avant de retourner l'utilisateur
        administrateur.setPassword(null);
        return user;
    }

    public Administrateur save(Administrateur administrateur) {
        return administrateurRepository.save(administrateur);
    }

    public List<Administrateur> getAllAdministrateursSup() {
        return administrateurRepository.getAllAdministrateursSup();
    }

    public List<Administrateur> getAllAdministrateursSecond() {
        return administrateurRepository.getAllAdministrateursSecond();
    }

    public Optional<Administrateur> findById(Integer administrateurId) {
        return administrateurRepository.findById(administrateurId);
    }

    public void deleteById(Integer administrateurId) {
        administrateurRepository.deleteById(administrateurId);
    }

    public Administrateur updateAdmin(Integer administrateurid, Administrateur adminDetails) {
        // Trouver l'administrateur existant par son ID
        Administrateur admin = administrateurRepository.findById(administrateurid)
                .orElseThrow(() -> new ResourceNotFoundException("Admin not found for this id :: " + administrateurid));

        // Mettre à jour les champs de l'administrateur
        admin.setNom(adminDetails.getNom());
        admin.setPrenom(adminDetails.getPrenom());
        admin.setEmail(adminDetails.getEmail());
        Role role = roleRepository.getReferenceById((long) adminDetails.getRole().getId());
        admin.setRole(role);
        Ecole ecole = ecoleRepository.getReferenceById(adminDetails.getEcole().getIdEcole());
        admin.setEcole(ecole);
        Site site = siteRepository.getReferenceById(adminDetails.getSite().getId());
        admin.setSite(site);
        // Sauvegarder les modifications dans la base de données
        return administrateurRepository.save(admin);
    }
}
