package org.groupeintec.gestion.donnees;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.groupeintec.gestion.model.Etudiant;
import org.groupeintec.gestion.model.Filiere;
import org.groupeintec.gestion.model.Fraixscolaire;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FraisParFiliere {
    private Filiere filiere;
    private List<Fraixscolaire> fraixscolaires;
    private int montanttotal;
    private int reductiontotal;
}
