package org.groupeintec.gestion.controller;

import org.groupeintec.gestion.dto.ClasseDTO;
import org.groupeintec.gestion.model.Classeecole;
import org.groupeintec.gestion.model.Eleve;
import org.groupeintec.gestion.repository.ClasseecoleRepository;
import org.groupeintec.gestion.repository.EleveRepository;
import org.groupeintec.gestion.service.EleveService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/eleves")
public class EleveController {
    @Autowired
    private EleveRepository eleveRepository;
    @Autowired
    private EleveService eleveService;
    //liste des eleves par ecole et par classe pour une annee
    @GetMapping("/{ecoleId}/{classeId}/{anneeId}")
    public ResponseEntity<List<Eleve>> getAllEleve(@PathVariable int ecoleId,@PathVariable int classeId,@PathVariable int anneeId){
        return ResponseEntity.ok(eleveRepository.findAll());
    }
}
