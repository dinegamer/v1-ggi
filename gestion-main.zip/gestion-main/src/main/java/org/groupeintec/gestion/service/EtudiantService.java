package org.groupeintec.gestion.service;

import org.groupeintec.gestion.donnees.StatistiqueParEtudiant;
import org.groupeintec.gestion.dto.EtudiantDetailsDTO;
import org.groupeintec.gestion.model.*;
import org.groupeintec.gestion.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

@Service
public class EtudiantService {
    @Autowired
    private EtudiantRepository etudiantRepository;
    @Autowired
    private InscrireRepository inscrireRepository;
    @Autowired
    private SiteRepository siteRepository;
    @Autowired
    private FiliereRepository filiereRepository;
    @Autowired
    private FraixscolaireRepository fraixscolaireRepository;
    @Autowired
    private PaiementRepository paiementRepository;
    @Autowired
    private AnneeuvRepository anneeuvRepository;
    @Autowired
    private PaiementService paiementService;
    @Autowired
    private ParametreService parametreService;
    public List<Etudiant> rechercherEtudiants(String nom, String prenom, String numeroTuteur, String telephone) {
        System.out.println(nom+" "+prenom+" "+numeroTuteur+" "+telephone+" mdt ");
        if (nom != null && !nom.trim().isEmpty()) {
            // Recherche par nom si le champ 'nom' est renseigné
            return etudiantRepository.findByNom(nom);
        } else if (prenom != null && !prenom.trim().isEmpty()) {
            // Recherche par prénom si le champ 'prenom' est renseigné
            return etudiantRepository.findByPrenom(prenom);
        } else if (numeroTuteur != null && !numeroTuteur.trim().isEmpty()) {
            // Recherche par numéro de tuteur si ce champ est renseigné
            return etudiantRepository.findByTeltuteur(numeroTuteur);
        } else if (telephone != null && !telephone.trim().isEmpty()) {
            // Recherche par téléphone si ce champ est renseigné
            return etudiantRepository.findByTelephone(telephone);
        } else {
            // Si aucun critère n'est renseigné, tu peux gérer un retour vide ou toutes les données
            return new ArrayList<>(); // Retourne une liste vide si rien n'est renseigné
        }
    }
    public List<Etudiant> getAllEtudiant(){
        List<Etudiant> etudiants = etudiantRepository.findAll();
        return etudiants;
    }
    public Map<String, String> etudiantParMatricule(String matricule){
        Map<String, String> response = new HashMap<>();
        if (etudiantRepository.existsByMatricule(matricule)) {
            response.put("message", "Un étudiant avec le numéro matricule "+matricule+"  existe deja !!!");
        }
        return response;

    }
    // Méthode pour enregistrer un étudiant
    public Map<String, String> saveEtudiant(String[] donnees) {
        Map<String, String> response = new HashMap<>();

        String matricule = donnees[0];
        if (etudiantRepository.existsByMatricule(matricule)) {
            response.put("message", "Un étudiant avec le numéro matricule "+matricule+"  existe deja !!!");
            return response;
        }

        String nom = donnees[1];
        String genre = donnees[2];
        String nationalite = donnees[3];
        String telephone = donnees[4];
        String adresse = donnees[5];
        String email = donnees[6];
        String naissance = donnees[7];
        String teltuteur = donnees[8];
        String prenompere = donnees[9];
        String prenommere = donnees[10];
        String nommere = donnees[11];
        String dateajout = donnees[12];
        String heureajout = donnees[13];
        String prenom = donnees[14];
        //etudiant
        Etudiant etudiant = new Etudiant();
        etudiant.setMatricule(matricule);
        etudiant.setPassword("Intec@Sup*-");
        etudiant.setNom(nom);
        etudiant.setPrenom(prenom);
        etudiant.setGenre(genre);
        etudiant.setNationalite(nationalite);
        etudiant.setTelephone(telephone);
        etudiant.setAdresse(adresse);
        etudiant.setEmail(email);
        etudiant.setNaissance(naissance);
        etudiant.setTeltuteur(teltuteur);
        etudiant.setPrenompere(prenompere);
        etudiant.setPrenommere(prenommere);
        etudiant.setNommere(nommere);
        etudiant.setDateajout(dateajout);
        etudiant.setHeureajout(heureajout);
        Etudiant etudiantSave = etudiantRepository.save(etudiant);
        //incription
        String site = donnees[15];
        String cours = donnees[16];
        String observation = donnees[17];
        String filiere = donnees[18];
        String annee = donnees[19];

        Inscrire inscrire = new Inscrire();
        inscrire.setHeureajout(heureajout);
        inscrire.setDateajout(dateajout);
        inscrire.setCours(cours);
        inscrire.setObservation(observation);

        Site siteSelect = siteRepository.getReferenceById(Integer.valueOf(site));
        inscrire.setRive(siteSelect);
        Filiere filiereSelect = filiereRepository.getReferenceById(Integer.valueOf(filiere));
        inscrire.setFiliere(filiereSelect);
        Anneeuv anneeuv = anneeuvRepository.getReferenceById(Integer.valueOf(annee));
        inscrire.setAnneeuv(anneeuv);
        inscrire.setEtudiant(etudiantSave);
        Inscrire inscrireSave = inscrireRepository.save(inscrire);
        //retour
        response.put("message", "L'étudiant " + etudiantSave.getLabel() +
                " a été inscrit avec succès dans la filière " + inscrireSave.getFiliere().getNom() +
                " pour " + inscrireSave.getAnneeuv().getNom() + " le site " + inscrireSave.getRive().getNom()
        );
        return response;
    }

    public Optional<Etudiant> getEtudiantById(int id) {
        return etudiantRepository.findById(id);
    }

    public EtudiantDetailsDTO getEtudiantDetails(int etudiantId, int an) {
        Etudiant etudiant = etudiantRepository.findById(etudiantId).orElseThrow(() -> new RuntimeException("Étudiant non trouvé"));
        Inscrire inscrire = inscrireRepository.findByEtudiantIdAndAnneeuvId(etudiantId,an);
        Fraixscolaire fraixscolaire = fraixscolaireRepository.findByEtudiantIdAndAnneeuvIdAndFiliereId(etudiantId,an,inscrire.getFiliere().getId());
        List<Paiement> paiements = paiementRepository.findByEtudiantIdAndAnneunvId(etudiantId,an);
        EtudiantDetailsDTO dto = new EtudiantDetailsDTO();
        dto.setEtudiant(etudiant);
        dto.setInscrire(inscrire);
        dto.setFraixscolaire(fraixscolaire);
        dto.setPaiements(paiements);
        return dto;
    }
    public EtudiantDetailsDTO transfereEtudiantEntreClasse(String[] donnees){
        int cour = Integer.parseInt(donnees[0]); int filier = Integer.parseInt(donnees[1]); String cours;
        if(cour == 1){ cours = "Jour"; }else { cours = "Soir";}
        int an = Integer.parseInt(donnees[2]); int site = Integer.parseInt(donnees[3]);
        int etudian = Integer.parseInt(donnees[4]);

        //verification
        Etudiant etudiant = etudiantRepository.findById(etudian).orElseThrow(() -> new RuntimeException("Étudiant non trouvé"));
        Inscrire inscrire = inscrireRepository.findByEtudiantIdAndAnneeuvId(etudian,an);
        inscrire.setCours(cours);
        Filiere filiere = filiereRepository.getReferenceById(filier);
        inscrire.setFiliere(filiere);
        if(!donnees[5].equals("")) {
            int newSite = Integer.parseInt(donnees[5]);
            Site site1 = siteRepository.getReferenceById(newSite);
            inscrire.setRive(site1);
        }
        inscrireRepository.save(inscrire);
        //frais
        Fraixscolaire fraixscolaire = fraixscolaireRepository.findByEtudiantIdAndAnneeuvIdAndFiliereId(etudian,an,inscrire.getFiliere().getId());
        fraixscolaire.setFiliere(filiere);
        fraixscolaireRepository.save(fraixscolaire);
        //paiement
        List<Paiement> paiements = paiementRepository.findByEtudiantIdAndAnneunvId(etudian,an);
        for (Paiement paiement: paiements){
            paiement.setFiliere(filiere);
            paiementRepository.save(paiement);
        }
        //mise a jour
        EtudiantDetailsDTO dto = new EtudiantDetailsDTO();
        dto.setEtudiant(etudiant);
        return dto;
    }

    public Map<String, Object> login(String[] donnees) {
        Map<String, Object> response = new HashMap<>();
        String matricule = donnees[0];
        String password = donnees[1];
        int filiere = Integer.parseInt(donnees[2]);
        int an = Integer.parseInt(donnees[3]);
        Optional<Etudiant> etudiant = etudiantRepository.findByMatriculeAndPassword(matricule, password);
       if(etudiant.isPresent()){
           Optional<Inscrire> inscrire = inscrireRepository.findByEtudiantIdAndAnneeuvIdAndFiliereId(etudiant.get().getId(),an, filiere);
           if(inscrire.isPresent()){
               //les paiement
               int cours;
               if (inscrire.get().getCours() == "Jour"){cours = 1;}else {cours=2;}

               StatistiqueParEtudiant statistiqueParEtudiant = paiementService.statistiqueParEtudiant(
                       inscrire.get().getEtudiant().getId(),inscrire.get().getFiliere().getId(),
                       inscrire.get().getAnneeuv().getId(),cours,inscrire.get().getRive().getId()
                       );
               //Parametre par defaut verifier
               Parametre parametre = parametreService.getById(1L);
               if(statistiqueParEtudiant.getPourcentage() <= parametre.getPourcentage()){
                   response.put("statut",false);
                   response.put("errorMessage","Vous devriez être à 50 % de paiement pour bénéficier de ce service, Merci !");
               }else {
                   response.put("statut",true);
                   response.put("inscrire", inscrire);
               }
           }else {
               response.put("statut",false);
               response.put("errorMessage","verifier votre inscription ! Merci");
           }
           //response.put("etudiant", etudiant);
       }else {
           response.put("statut",false);
           response.put("errorMessage","L'étudiant avec se numero matricule et le mot de passe n'existe pas ! Merci");
       }
        return response;
    }

    public Etudiant save(Etudiant etudiant) {
        return etudiantRepository.save(etudiant);
    }
}
