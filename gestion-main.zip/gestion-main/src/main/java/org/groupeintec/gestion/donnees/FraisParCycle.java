package org.groupeintec.gestion.donnees;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.groupeintec.gestion.model.Cycle;

import java.util.List;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class FraisParCycle {
    private Cycle cycle;
    private List<FraisParFiliere> fraisParFilieres;
    private int montantotal;
    private int totalreduction;
}
