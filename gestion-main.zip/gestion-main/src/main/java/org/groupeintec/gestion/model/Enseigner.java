package org.groupeintec.gestion.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table
public class Enseigner {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "matiere")
    private Matiere matiere;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "classe")
    private Classe classe;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "professeur")
    private Enseignant enseignant;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "ecole")
    private Ecole ecole;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "anneeuv")
    private Anneeuv anneeuv;
}
