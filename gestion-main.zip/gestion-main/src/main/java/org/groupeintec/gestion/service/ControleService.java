package org.groupeintec.gestion.service;

import jakarta.transaction.Transactional;
import org.groupeintec.gestion.donnees.NoteParClasse;
import org.groupeintec.gestion.donnees.NoteParMatiere;
import org.groupeintec.gestion.donnees.ReleveParClasse;
import org.groupeintec.gestion.dto.*;
import org.groupeintec.gestion.fonctions.Appreciation;
import org.groupeintec.gestion.fonctions.CalculNoteDeSemestre;
import org.groupeintec.gestion.model.*;
import org.groupeintec.gestion.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class ControleService {

    @Autowired
    private InscrireService inscrireService;
    @Autowired
    private InscrireRepository inscrireRepository;
    @Autowired
    private MatieresupService matieresupService;
    @Autowired
    private ControleRepository controleRepository;
    @Autowired
    private TypeueRepository typeueRepository;
    @Autowired
    private UeRepository ueRepository;
    @Autowired
    private SemestreRepository semestreRepository;
    @Autowired
    private AnneeuvRepository anneeuvRepository;
    @Autowired
    private FiliereRepository filiereRepository;
    @Autowired
    private EtudiantRepository etudiantRepository;
    @Autowired
    private MatieresupRepository matieresupRepository;
    @Autowired
    private CycleRepository cycleRepository;

    //releve par classe
    public List<TypeUEDTO> getReleveParTypeU(int cours, int site, int anneeId, int filiereId, int semestreId) {
        String cour = (cours == 1) ? "Jour" : "Soir";

        // Préparer la map de résultats par typeUE
        Map<String, TypeUEDTO> typeUEMap = new HashMap<>();

        List<Typeue> typeues = typeueRepository.findAll();
        List<Matieresup> matieresups = matieresupRepository.findBySemestreIdAndFiliereId(semestreId, filiereId);
        List<Controle> controles = controleRepository.controleParTypeue(cour, site, anneeId, filiereId, semestreId);
        List<Inscrire> inscrires = inscrireRepository.EtudiantParClasse(anneeId, cour, filiereId, site);

        // Préparer la liste globale des étudiants (une fois)
        List<EtudiantDTO> etudiantDTOS = inscrires.stream()
                .map(inscrire -> {
                    EtudiantDTO e = new EtudiantDTO();
                    e.setId(inscrire.getEtudiant().getId());
                    e.setNom(inscrire.getEtudiant().getNom());
                    e.setPrenom(inscrire.getEtudiant().getPrenom());
                    e.setMatricule(inscrire.getEtudiant().getMatricule());
                    return e;
                })
                .distinct()
                .toList();

        for (Typeue typeue : typeues) {
            TypeUEDTO typeUEDTO = new TypeUEDTO();
            typeUEDTO.setNomTypeUE(typeue.getNom());
            typeUEDTO.setEtudiants(etudiantDTOS); // même liste pour chaque type UE

            List<MatiereDTO> matiereDTOS = new ArrayList<>();

            for (Matieresup mat : matieresups) {
                if (mat.getUe() != null
                        && mat.getUe().getTypeue() != null
                        && Objects.equals(mat.getUe().getTypeue().getId(), typeue.getId())) {
                    MatiereDTO matiereDTO = new MatiereDTO();
                    matiereDTO.setNomMatiere(mat.getNom());
                    matiereDTO.setCredit(mat.getCredit() != null ? mat.getCredit() : BigDecimal.ZERO);

                    List<NoteDTO> noteDTOS = new ArrayList<>();

                    for (EtudiantDTO etudiant : etudiantDTOS) {
                        NoteDTO noteDTO = new NoteDTO();
                        noteDTO.setEtudiantId(etudiant.getId());

                        // Chercher le contrôle correspondant
                        Controle controle = controles.stream()
                                .filter(c -> c.getEtudiant() != null
                                        && c.getMatieresup() != null
                                        && Objects.equals(c.getEtudiant().getId(), etudiant.getId())
                                        && Objects.equals(c.getMatieresup().getId(), mat.getId()))
                                .findFirst()
                                .orElse(null);


                        if (controle != null) {
                            BigDecimal noteClasse = Optional.ofNullable(controle.getNoteclasse()).orElse(BigDecimal.ZERO);
                            BigDecimal noteExamen = Optional.ofNullable(controle.getNoteexamen()).orElse(BigDecimal.ZERO);
                            BigDecimal moyenne = noteClasse.add(noteExamen).divide(BigDecimal.valueOf(2), 2, RoundingMode.HALF_UP);
                            noteDTO.setNoteClasse(noteClasse);
                            noteDTO.setNoteExamen(noteExamen);
                            noteDTO.setMoyenne(moyenne);
                            if (moyenne != null && moyenne.compareTo(BigDecimal.valueOf(5)) <= 0) {
                                noteDTO.setNoteCredit(BigDecimal.ZERO);
                            } else {
                                noteDTO.setNoteCredit(mat.getCredit());
                            }
                            noteDTO.setValidation(moyenne.compareTo(BigDecimal.TEN) >= 0 ? "V" : "NV");
                        } else {
                            noteDTO.setNoteClasse(BigDecimal.ZERO);
                            noteDTO.setNoteExamen(BigDecimal.ZERO);
                            noteDTO.setMoyenne(BigDecimal.ZERO);
                            noteDTO.setNoteCredit(BigDecimal.ZERO);
                            noteDTO.setValidation("NV");
                        }

                        noteDTOS.add(noteDTO);
                    }

                    matiereDTO.setNotes(noteDTOS);
                    matiereDTOS.add(matiereDTO);
                }
            }

            typeUEDTO.setMatieres(matiereDTOS);
            typeUEMap.put(typeue.getNom(), typeUEDTO);
        }

        return new ArrayList<>(typeUEMap.values());
    }

    //les notes de la filiere pour affichage
    public List<Controle> notes(String[] donnees){
        int an = Integer.parseInt(donnees[0]);
        int semestre = Integer.parseInt(donnees[3]);
        int matiere = Integer.parseInt(donnees[4]);
        int filiere = Integer.parseInt(donnees[1]);
        int site = Integer.parseInt(donnees[5]);
        int cours = Integer.parseInt(donnees[2]);
        String cour;
        if(cours == 1){ cour = "Jour";}else {cour = "Soir";}
        List<Controle> controles = controleRepository.controleparclasse(an, semestre, matiere, filiere, site, cour);
        return controles;
    }
    //note par classe
    public List<Controle> controleparclasse(int an, int semestre, int matiere, int filiere, int site, int cours){
        String cour;
        if(cours == 1){cour = "Jour";}else {cour="Soir";}
        List<Inscrire> inscrires = inscrireRepository.EtudiantParClasse(an,cour,filiere,site);
        List<Controle> controles = controleRepository.controleparclasse(an, semestre, matiere, filiere, site, cour);
        if(controles.isEmpty()){
            //System.out.println("pas de note pour cette matiere !!");
            List<Controle> controleList = new ArrayList<>();
            for(Inscrire inscrire: inscrires){
                Controle controle = new Controle();
                controle.setEtudiant(inscrire.getEtudiant());
                controle.setNoteclasse(new BigDecimal(0.0));
                controle.setNoteexamen(new BigDecimal(0.0));
                controleList.add(controle);
            }
            return controleList;

        }else {
            //return controles;
            List<Controle> controleList = new ArrayList<>();
            for (Inscrire inscrire: inscrires){
                boolean verif = controles.stream().anyMatch(controle -> controle.getEtudiant().equals(inscrire.getEtudiant()));
                if (verif == true){
                    Controle c = controles.stream().filter(controle -> controle.getEtudiant().equals(inscrire.getEtudiant())).findFirst().orElse(null);
                    controleList.add(c);
                }else {
                    Controle ctl = new Controle();
                    ctl.setEtudiant(inscrire.getEtudiant());
                    ctl.setNoteclasse(new BigDecimal(0.0));
                    ctl.setNoteexamen(new BigDecimal(0.0));
                    controleList.add(ctl);
                }
            }
            return controleList;
        }
    }
    //enregistre une note
    public Map<String, String> EnregistreNote(String[] ctl){
        int filier = Integer.parseInt(ctl[2]); int annee = Integer.parseInt(ctl[0]);
        int etudian = Integer.parseInt(ctl[1]); int matiere = Integer.parseInt(ctl[3]);
        int semestr = Integer.parseInt(ctl[4]);
        Map<String, String> response = new HashMap<>();

        Anneeuv anneeuv = anneeuvRepository.getReferenceById(Integer.valueOf(ctl[0]));
        Etudiant etudiant = etudiantRepository.getReferenceById(Integer.valueOf(ctl[1]));
        Filiere filiere = filiereRepository.getReferenceById(Integer.valueOf(ctl[2]));
        Matieresup matieresup = matieresupRepository.getReferenceById(Integer.valueOf(ctl[3]));
        Semestre semestre = semestreRepository.getReferenceById(Integer.valueOf(ctl[4]));
        Controle controle = new Controle();
        controle.setAnneeuv(anneeuv);
        controle.setEtudiant(etudiant);
        controle.setFiliere(filiere);
        controle.setMatieresup(matieresup);
        controle.setSemestre(semestre);
        String cc = ctl[5];
        String ex = ctl[6];
        cc = cc.replace(",", "."); // Remplace une éventuelle virgule par un point
        ex = ex.replace(",", ".");
        controle.setNoteclasse(new BigDecimal(cc));
        controle.setNoteexamen(new BigDecimal(ex));
        //System.out.println(controle);
        Controle controle1 = controleRepository.saveAndFlush(controle);
        Controle verifier = controleRepository.findById(controle1.getId()).orElse(null);
        String msg;
        if (verifier != null) {
            response.put("message","Le controle a été sauvegardé et récupéré avec succès !");
            return response;
        } else {
            response.put("message","Le controle n'a pas été trouvé après la sauvegarde.");
            return response;
        }


    }
    public List<Controle> ControleParAnnee(){
        List<Controle> controles = controleRepository.findAllAnneeuvControles();
        return controles;
    }
    /*public List<ControleParCycle> ControleParCycle(int annee, int filiere, int cours, String semestrea, String semestreb){
        List<ControleParCycle> donnees = new ArrayList<>();
        List<Inscrire> inscrires = inscrireService.EtudiantParFiliereAnneeCours(annee,cours,filiere);
        for(Inscrire inscrire: inscrires){
            ControleParCycle controleParCycle = new ControleParCycle();
            controleParCycle.setEtudiant(inscrire.getEtudiant());
            donnees.add(controleParCycle);
        }
        return donnees;
    }*/
    public List<NoteDutDeux> NoteDutDeux(int annee, int filiere, int cours, int sun, int sdeux, int site){
        List<NoteDutDeux> noteDutDeuxs = new ArrayList<>();
        List<Etudiant> etudiants = inscrireService.EtudiantParFiliereAnneeCours(annee,cours,filiere,site);
        for (Etudiant etudiant: etudiants){
            NoteDutDeux noteDutDeux = new NoteDutDeux();
            noteDutDeux.setEtudiant(etudiant);
            CalculNoteDeSemestre notesun = this.calculNoteDeSemestre(annee,filiere,etudiant.getId(),sun);
            noteDutDeux.setMgsun(notesun.getMoyenne());
            CalculNoteDeSemestre notesdeux = this.calculNoteDeSemestre(annee,filiere,etudiant.getId(),sdeux);
            BigDecimal moyennean = (notesun.getMoyenne().add(notesdeux.getMoyenne())).divide(new BigDecimal(2), 2, BigDecimal.ROUND_HALF_UP);
            noteDutDeux.setMannuel(moyennean);
            noteDutDeux.setMgsdeux(notesdeux.getMoyenne());
            NoteParSemestre notedut = this.noteParSemestre(annee,filiere,etudiant.getId(),8);
            noteDutDeux.setMdut(notedut.getMgsemestre());
            BigDecimal moyennegeneral = (moyennean.add(notedut.getMgsemestre())).divide(new BigDecimal(2), 2, BigDecimal.ROUND_HALF_UP);
            noteDutDeux.setMannuel(moyennegeneral);
            Appreciation appreciation = new Appreciation();
            noteDutDeux.setMention(appreciation.Mention(moyennegeneral));
            BigDecimal totalcredit = notesun.getCredit().add(notesdeux.getCredit());
            noteDutDeux.setCredit(totalcredit);
            noteDutDeux.setAppreciation(appreciation.Apprecier(totalcredit,moyennegeneral));

            noteDutDeuxs.add(noteDutDeux);
        }
        return noteDutDeuxs;
    }
    public List<Statistique> Statistique(int annee,int site,int cycle){
        List<Statistique> statistiques = new ArrayList<>();
        /*le semestre 4 a id 5*/
        int sun=0, sdeux=0;
        if(cycle==4){sun=1;sdeux=2;}  /** DUT 1 **/
        if(cycle==5){sun=3;sdeux=5;}  /** DUT 2 **/
        if(cycle==6){sun=1;sdeux=2;} /** LICENCE 1 **/
        if(cycle==7){sun=3;sdeux=5;} /** LICENCE 2 **/
        if(cycle==11){sun=6;sdeux=7;} /** LICENCE 3 **/
        if(cycle==8){sun=1;sdeux=2;} /** MASTER 1 **/
        if(cycle==9){sun=3;sdeux=5;} /** MASTER 2 **/
        List<Filiere> filieres = filiereRepository.filieresparcycle(cycle);
        for (Filiere filiere: filieres){
            Statistique statistique = new Statistique();
            statistique.setClasse(filiere);
            int nombrejour = inscrireService.nombreParTypeCours(site,annee,filiere.getId(),statistique.getJour());
            int nombresoir = inscrireService.nombreParTypeCours(site, annee,filiere.getId(),statistique.getSoir());
            statistique.setNombrejour(nombrejour);
            statistique.setNombresoir(nombresoir);

            List<NoteDutUn> etatjour = NoteDutUn(annee,filiere.getId(),1,sun,sdeux,site);
            List<NoteDutUn> etatsoir = NoteDutUn(annee,filiere.getId(),2,sun,sdeux,site);
            long validerjour, validersoir, enjembamentjour, enjembamentsoir, nvaliderjour, nvalidersoir;
            validerjour = etatjour.stream().map(NoteDutUn::getAppreciation).filter(admin -> admin == "Admis").count();
            validersoir = etatsoir.stream().map(NoteDutUn::getAppreciation).filter(admin -> admin == "Admis").count();
            statistique.setValidejour(validerjour);
            statistique.setValidesoir(validersoir);

            enjembamentjour = etatjour.stream().map(NoteDutUn::getAppreciation).filter(admin -> admin == "Admission Conditionnelle").count();
            enjembamentsoir = etatsoir.stream().map(NoteDutUn::getAppreciation).filter(admin -> admin == "Admission Conditionnelle").count();
            statistique.setNonvalidejour(enjembamentjour);
            statistique.setNonvalidesoir(enjembamentsoir);

            nvaliderjour = etatjour.stream().map(NoteDutUn::getAppreciation).filter(admin -> admin == "Ajourné").count();
            nvalidersoir = etatsoir.stream().map(NoteDutUn::getAppreciation).filter(admin -> admin == "Ajourné").count();
            statistique.setEnjabementjour(nvaliderjour);
            statistique.setEnjabementsoir(nvalidersoir);

            long pourcentagejour = 0, pourcentagesoir = 0;
            if(nombrejour != 0){
                pourcentagejour = (((validerjour+enjembamentjour)-nvaliderjour)/nombrejour)*100;
            }
            if(nombresoir != 0){
                pourcentagesoir = (((validersoir+enjembamentsoir)-nvalidersoir)/nombresoir)*100;
            }
            statistique.setPourcentagejour(pourcentagejour);
            statistique.setPourcentagesoir(pourcentagesoir);
            statistiques.add(statistique);
        }
        return statistiques;
    }
    public List<NoteDutUn> NoteDutUn(int annee, int filiere, int cours, int sun, int sdeux, int site){
        //List<Controle> controles = controleRepository.controleparclasse(annee, semestre, matiere, filiere, site, cours);
        List<NoteDutUn> noteDutUns = new ArrayList<>();
        List<Etudiant> etudiants = inscrireService.EtudiantParFiliereAnneeCours(annee,cours,filiere,site);
        for (Etudiant etudiant: etudiants){
            NoteDutUn noteDutUn = new NoteDutUn();
            noteDutUn.setEtudiant(etudiant);
            CalculNoteDeSemestre notesun = this.calculNoteDeSemestre(annee,filiere,etudiant.getId(),sun);
            noteDutUn.setMgsun(notesun.getMoyenne());
            CalculNoteDeSemestre notesdeux = this.calculNoteDeSemestre(annee,filiere,etudiant.getId(),sdeux);
            noteDutUn.setMgsdeux(notesdeux.getMoyenne());
            //calcul moyenne annuelle
            BigDecimal mgan = notesun.getMoyenne().add(notesdeux.getMoyenne());
            BigDecimal mgannel = mgan.divide(new BigDecimal(2), 2, BigDecimal.ROUND_HALF_UP);
            noteDutUn.setMannuel(mgannel);
            Appreciation appreciation = new Appreciation();
            noteDutUn.setMention(appreciation.Mention(mgannel));
            BigDecimal totalcredit = notesun.getCredit().add(notesdeux.getCredit());
            noteDutUn.setCredit(totalcredit);
            noteDutUn.setAppreciation(appreciation.Apprecier(totalcredit,mgannel));
            noteDutUns.add(noteDutUn);
        }
        return noteDutUns;
    }
    //calcul note de semestre
    public CalculNoteDeSemestre calculNoteDeSemestre(int an, int filiere, int etudiant, int semestre){
        CalculNoteDeSemestre calculNoteDeSemestre = new CalculNoteDeSemestre();
        List<Releveretudiant> releveretudiants = this.ReleverEtudiantSemetre(an,filiere,etudiant,semestre);
        BigDecimal mg = releveretudiants.stream().map(Releveretudiant::getMg).reduce(BigDecimal.ZERO, BigDecimal::add);
        Long nombrematiere = releveretudiants.stream().count();
        BigDecimal mgtotal;
        if(nombrematiere != 0){
            mgtotal = mg.divide(new BigDecimal(nombrematiere), 2, BigDecimal.ROUND_HALF_UP);
        }else {
            mgtotal = new BigDecimal(1);
        }
        calculNoteDeSemestre.setMoyenne(mgtotal);
        BigDecimal credit = releveretudiants.stream().map(Releveretudiant::getCredit).reduce(BigDecimal.ZERO, BigDecimal::add);
        calculNoteDeSemestre.setCredit(credit);
        return calculNoteDeSemestre;
    }
    //note par semestre et par cycle
    public NoteParSemestre noteParSemestre(int an, int filiere, int etudiant, int semestre){
        Appreciation appreciation = new Appreciation();
        NoteParSemestre noteParSemestre = new NoteParSemestre();
        //recherche semestre
        Semestre semestre1 = semestreRepository.findById(semestre).orElse(null);
        //remplisage
        noteParSemestre.setSemestre(semestre1);
        //les type ue
        List<NoteParTypeUe> noteParTypeUes = new ArrayList<>();
        List<Typeue> typeues = typeueRepository.findAll();
        BigDecimal mgsemestre = new BigDecimal(0);
        BigDecimal creditsemestre = new BigDecimal(0);
        BigDecimal totalmatiere = BigDecimal.ZERO;
        for (Typeue typeue: typeues){
            NoteParTypeUe noteParTypeUe = new NoteParTypeUe();
            noteParTypeUe.setTypeue(typeue);
            List<Releveretudiant> releveretudiants = this.ReleverEtudiant(an,filiere,etudiant,semestre,typeue);
            List<Releveretudiant> rlv = new ArrayList<>();
            BigDecimal mgtypeue = new BigDecimal(0);
            BigDecimal credittypeue = new BigDecimal(0);
            int nombrematiere = 0;
            for (Releveretudiant releveretudiant: releveretudiants){
                rlv.add(releveretudiant);
                mgtypeue = mgtypeue.add(releveretudiant.getMg());
                credittypeue = credittypeue.add(releveretudiant.getCredit());
                nombrematiere++;
            }

            totalmatiere = totalmatiere.add(new BigDecimal(nombrematiere));
            noteParTypeUe.setReleveretudiants(rlv);
            mgsemestre = mgsemestre.add(mgtypeue);
            if(nombrematiere != 0) {
                mgtypeue = mgtypeue.divide(new BigDecimal(nombrematiere), 2, BigDecimal.ROUND_HALF_UP);
            }else {
                mgtypeue = BigDecimal.ZERO;
            }
            noteParTypeUe.setMgtypeue(mgtypeue);
            creditsemestre = creditsemestre.add(credittypeue);
            noteParTypeUe.setCredittypeue(credittypeue);

            noteParTypeUe.setMentiontypeue("");
            noteParTypeUe.setAppreciationtypeue(appreciation.AppreciationTypeue(mgtypeue));
            noteParTypeUes.add(noteParTypeUe);
        }
        noteParSemestre.setNoteParTypeUe(noteParTypeUes);
        BigDecimal mgs = mgsemestre.divide(totalmatiere, 2, BigDecimal.ROUND_HALF_UP);
        noteParSemestre.setMgsemestre(mgs);
        noteParSemestre.setCreditsemestre(creditsemestre);
        noteParSemestre.setMentionsemestre(appreciation.Mention(mgs));
        noteParSemestre.setAppreciationsemestre(appreciation.AppreciationSemestre(mgs,creditsemestre));
        Anneeuv anneeuv = anneeuvRepository.getReferenceById(an);
        Filiere filiere1 = filiereRepository.getReferenceById(filiere);
        Etudiant etudiant1 = etudiantRepository.getReferenceById(etudiant);
        noteParSemestre.setAnneeuv(anneeuv);
        noteParSemestre.setFiliere(filiere1);
        noteParSemestre.setEtudiant(etudiant1);
        return noteParSemestre;
    }
    //relever etudiant
    public List<Releveretudiant> ReleverEtudiant(int an, int filiere, int etudiant, int semestre, Typeue typeue){
        List<Releveretudiant> donnees = new ArrayList<>();
        List<Matieresup> matieresups = matieresupRepository.matierepartypeue(typeue.getId(),filiere,semestre);
        for (Matieresup matieresup: matieresups){
            Releveretudiant releveretudiant = new Releveretudiant();
            releveretudiant.setMatieresup(matieresup);
            //note de l'etudiant
            Controle controle = controleRepository.rechercheControle(filiere,an,etudiant,matieresup.getId(),semestre).orElse(null);
            BigDecimal cc = new BigDecimal(0.0); BigDecimal ex = new BigDecimal(0.0);
            if(controle != null){
                releveretudiant.setCc(controle.getNoteclasse());
                cc = controle.getNoteclasse();
                releveretudiant.setEx(controle.getNoteexamen());
                ex = controle.getNoteexamen();
            }else {
                releveretudiant.setCc(cc);
                releveretudiant.setEx(ex);
            }
            BigDecimal mg = cc.multiply(new BigDecimal(0.4)).add(ex.multiply(new BigDecimal(0.6))).setScale(2, RoundingMode.HALF_UP);
            releveretudiant.setMg(mg);
            BigDecimal credit = (mg.compareTo(BigDecimal.valueOf(5)) < 0) ? BigDecimal.ZERO : controle.getMatieresup().getCredit();
            releveretudiant.setCredit(credit);
            Appreciation appreciation = new Appreciation();
            releveretudiant.setMention(appreciation.Mention(mg));
            donnees.add(releveretudiant);
        }
        //retour
        return donnees;
    }
    //relever etudiant semestre
    public List<Releveretudiant> ReleverEtudiantSemetre(int an, int filiere, int etudiant, int semestre){
        List<Releveretudiant> donnees = new ArrayList<>();
        List<Controle> controles = controleRepository.releveretudiantsemestre(an, filiere, etudiant, semestre);
        for (Controle controle: controles){
            Releveretudiant releveretudiant = new Releveretudiant();
            releveretudiant.setMatieresup(controle.getMatieresup());
            releveretudiant.setCc(controle.getNoteclasse());
            BigDecimal cc = controle.getNoteclasse();
            releveretudiant.setEx(controle.getNoteexamen());
            BigDecimal ex = controle.getNoteexamen();
            BigDecimal mg = cc.multiply(new BigDecimal(0.4)).add(ex.multiply(new BigDecimal(0.6)));
            releveretudiant.setMg(mg);
            BigDecimal credit = (mg.compareTo(BigDecimal.valueOf(5)) < 0) ? BigDecimal.ZERO : controle.getMatieresup().getCredit();
            releveretudiant.setCredit(credit);
            Appreciation appreciation = new Appreciation();
            releveretudiant.setMention(appreciation.Mention(mg));
            donnees.add(releveretudiant);
        }
        //retour
        return donnees;
    }

    public Map<String, Object> verifierNote(String[] donnees) {
        Map<String, Object> response = new HashMap<>();
        int filiere = Integer.parseInt(donnees[0]);
        int annee = Integer.parseInt(donnees[1]);
        int etudiant = Integer.parseInt(donnees[2]);
        int matiere = Integer.parseInt(donnees[3]);
        int semestre = Integer.parseInt(donnees[4]);
        Optional<Controle> controle = controleRepository.rechercheControle(filiere,annee,etudiant,matiere,semestre);
        if (controle.isPresent()) {
            response.put("status","true");
            response.put("control", controle.get());
            return response;
        }else {
            response.put("status","false");
            response.put("message","Aucune note correspondant trouvé.");
            return response;
        }
    }

    public Map<String, String> updateNote(String[] donnees) {
        Map<String, String> response = new HashMap<>();

        int controleId = Integer.parseInt(donnees[0]);
        String cc = donnees[6];
        String ex = donnees[7];
        cc = cc.replace(",", "."); // Remplace une éventuelle virgule par un point
        ex = ex.replace(",", ".");
        BigDecimal noteclasse = new BigDecimal(cc);
        BigDecimal noteexamen = new BigDecimal(ex);
        //verifier la note
        Controle controle = controleRepository.getReferenceById(controleId);
        // Mettre à jour les notes
        controle.setNoteclasse(noteclasse);
        controle.setNoteexamen(noteexamen);
        //System.out.println(controle+" test mdt !!!");
        // Sauvegarde en base de données
        controleRepository.saveAndFlush(controle);
        if (controle.getId() != ' ') {
            response.put("status", "true");
            response.put("message", "Notes mises à jour avec succès.");
            //response.put("controle", controle);
        } else {
            response.put("status", "false");
            response.put("message", "Contrôle non trouvé.");
        }
        return response;
    }
    @Transactional
    public void deleteControle(int id) {
        if (!controleRepository.existsById(id)) {
            throw new RuntimeException("Le contrôle avec l'ID " + id + " n'existe pas !");
        }
        controleRepository.deleteById(id);
    }

    public NoteExamenEtudiantDTO NoteExamenEtudiant(int ins) {
        Inscrire inscrire = inscrireRepository.getReferenceById((long) ins);
        System.out.println(" mdt test "+inscrire);
        NoteExamenEtudiantDTO noteExamenEtudiantDTO = new NoteExamenEtudiantDTO();
        //etudiant
        noteExamenEtudiantDTO.setEtudiant(inscrire.getEtudiant());
        //determiner le cycle
        //si DUT 2
        if(inscrire.getFiliere().getCycle().getId() == 5){
            //NoteParSemestre noteParSemestre = this.noteParSemestre(1,1,2,2);
            noteExamenEtudiantDTO.setNotesun(new BigDecimal(23));
            noteExamenEtudiantDTO.setNotesdeux(new BigDecimal(20));
            noteExamenEtudiantDTO.setMgan(new BigDecimal(25));
            noteExamenEtudiantDTO.setMention("Bien Bien");
            noteExamenEtudiantDTO.setCredit(new BigDecimal(123));
            noteExamenEtudiantDTO.setAppreciation("TTRR");
        }
        //si premier année
        if(inscrire.getFiliere().getCycle().getId() == 4 || inscrire.getFiliere().getCycle().getId() == 6 || inscrire.getFiliere().getCycle().getId() == 8){
            noteExamenEtudiantDTO.setNotesun(new BigDecimal(24));
            noteExamenEtudiantDTO.setNotesdeux(new BigDecimal(20));
            noteExamenEtudiantDTO.setMgan(new BigDecimal(25));
            noteExamenEtudiantDTO.setMention("Bien Bien");
            noteExamenEtudiantDTO.setCredit(new BigDecimal(123));
            noteExamenEtudiantDTO.setAppreciation("TTRR");
        }
        //les deuxieme annee
        if(inscrire.getFiliere().getCycle().getId() == 7 || inscrire.getFiliere().getCycle().getId() == 9){
            noteExamenEtudiantDTO.setNotesun(new BigDecimal(25));
            noteExamenEtudiantDTO.setNotesdeux(new BigDecimal(20));
            noteExamenEtudiantDTO.setMgan(new BigDecimal(25));
            noteExamenEtudiantDTO.setMention("Bien Bien");
            noteExamenEtudiantDTO.setCredit(new BigDecimal(123));
            noteExamenEtudiantDTO.setAppreciation("TTRR");
        }
        //troieme année
        if(inscrire.getFiliere().getCycle().getId() == 11){
            noteExamenEtudiantDTO.setNotesun(new BigDecimal(26));
            noteExamenEtudiantDTO.setNotesdeux(new BigDecimal(20));
            noteExamenEtudiantDTO.setMgan(new BigDecimal(25));
            noteExamenEtudiantDTO.setMention("Bien Bien");
            noteExamenEtudiantDTO.setCredit(new BigDecimal(123));
            noteExamenEtudiantDTO.setAppreciation("TTRR");
        }
        return noteExamenEtudiantDTO;
    }

    // Supprimer toutes les notes (contrôles)
    public void deleteAllControles(List<Controle> donnees) {
        for (Controle controle: donnees){
            controleRepository.deleteById(controle.getId());
        }
    }
}