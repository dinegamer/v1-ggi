package org.groupeintec.gestion.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Value;

@NoArgsConstructor
@AllArgsConstructor
@Table(name = "etudiant")
@Entity
@Data
public class Etudiant {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String photo;
    private String matricule;
    private String password;
    private String nom;
    private String prenom;
    private String telephone;
    private String adresse;
    private String email;
    private String naissance;
    private String teltuteur;
    private String prenompere;
    private String nommere;
    private String prenommere;
    private String nationalite;
    private String genre;
    private String dateajout;
    private String heureajout;
    public String getLabel(){
        return getMatricule()+" "+getPrenom()+" "+getNom();
    }
}
