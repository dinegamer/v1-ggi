package org.groupeintec.gestion.repository;

import org.groupeintec.gestion.model.Emploidutemps;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmploidutempsRepository extends JpaRepository<Emploidutemps, Integer> {
    List<Emploidutemps> findByClasseIdAndAnneeuvIdAndEcoleIdEcole(int classeId, int anneeuvId, int ecoleId);
    List<Emploidutemps> findByProfesseurIdAndAnneeuvIdAndEcoleIdEcole(int professeurId, int anneeuvId, int ecoleId);
    List<Emploidutemps> findByAnneeuvIdAndEcoleIdEcole(int anneeuvId, int ecoleId);
    List<Emploidutemps> findByJourAndProfesseurIdAndAnneeuvIdAndEcoleIdEcole(String jour, int professeurId, int anneeuvId, int ecoleId);

    List<Emploidutemps> findByJourAndAnneeuvIdAndEcoleIdEcole(String jour, int anneeuvId, int ecoleId);
    @Query("SELECT e FROM Emploidutemps e WHERE e.professeur.id = :professeurId " +
            "AND e.anneeuv.id = :anneeuvId AND e.ecole.id = :ecoleId " +
            "AND e.jour IN ('Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi') " +
            "ORDER BY FIELD(e.jour, 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'), e.heuredebut")
    List<Emploidutemps> findByProfesseurAndAnneeuvAndEcoleSemaine(
            @Param("professeurId") int professeurId,
            @Param("anneeuvId") int anneeuvId,
            @Param("ecoleId") int ecoleId
    );
}
