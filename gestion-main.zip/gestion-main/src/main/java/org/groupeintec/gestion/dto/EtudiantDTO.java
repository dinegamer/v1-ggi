package org.groupeintec.gestion.dto;

import lombok.Data;

@Data
public class EtudiantDTO {
    private int id;
    private String nom;
    private String prenom;
    private String matricule;
}
