package org.groupeintec.gestion.service;

import org.groupeintec.gestion.model.Fraiscolaire;
import org.groupeintec.gestion.repository.FraiscolaireRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FraiscolaireService {
    @Autowired
    private FraiscolaireRepository fraiscolaireRepository;

    public List<Fraiscolaire> getAllFraiscolaires() {
        return fraiscolaireRepository.findAll();
    }

    public Optional<Fraiscolaire> getFraiscolaireById(int id) {
        return fraiscolaireRepository.findById(id);
    }

    public Fraiscolaire createFraiscolaire(Fraiscolaire fraiscolaire) {
        return fraiscolaireRepository.save(fraiscolaire);
    }

    public Fraiscolaire updateFraiscolaire(int id, Fraiscolaire fraiscolaire) {
        if(fraiscolaireRepository.existsById(id)) {
            fraiscolaire.setId(id);
            return fraiscolaireRepository.save(fraiscolaire);
        }
        return null;
    }

    public boolean deleteFraiscolaire(int id) {
        if(fraiscolaireRepository.existsById(id)) {
            fraiscolaireRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
