package org.groupeintec.gestion.donnees;

import lombok.Data;
import org.groupeintec.gestion.model.Matieresup;
import org.groupeintec.gestion.model.NoteParTypeUe;
import org.groupeintec.gestion.model.Typeue;

import java.util.List;

@Data
public class ReleveParClasse {
    private Typeue typeue;
    private List<NoteParMatiere> noteParMatieres;
}
