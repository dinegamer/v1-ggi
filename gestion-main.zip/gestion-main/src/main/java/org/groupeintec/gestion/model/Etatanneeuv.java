package org.groupeintec.gestion.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table
@AllArgsConstructor
@NoArgsConstructor
public class Etatanneeuv {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private int chiffre;
    private int reduction;
    private int montant = 0;
    private int reliquat;
    private int reliquatp;
    private int annee;
    private int site;
    private int cycle;
    private int etudiant;
}
