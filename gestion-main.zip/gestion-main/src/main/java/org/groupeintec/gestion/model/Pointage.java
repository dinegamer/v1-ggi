package org.groupeintec.gestion.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "pointage")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Pointage {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "emploidutemps")
    private Emploidutemps emploidutemps;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "enseignant")
    private Enseignant enseignant;

    private String valider;
    private String datevalider;
}
