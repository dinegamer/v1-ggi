package org.groupeintec.gestion.service;

import org.groupeintec.gestion.model.Categorie;
import org.groupeintec.gestion.model.Role;
import org.groupeintec.gestion.repository.CategorieRepository;
import org.groupeintec.gestion.repository.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RoleService {
    @Autowired
    private RoleRepository roleRepository;
    @Autowired
    private CategorieRepository categorieRepository;
    public List<Role> getAllRoles() {
        return roleRepository.findAll();
    }
    public List<Role> getRoleByCategorie(int id){
        return roleRepository.findByCategorieId(id);
    }
    public Role createRole(Role role) {
        return roleRepository.save(role);
    }

    public Role updateRole(Long id, Role role) {
        Role existingRole = roleRepository.findById(id).orElseThrow(() -> new RuntimeException("Role not found"));
        existingRole.setNom(role.getNom());
        return roleRepository.save(existingRole);
    }

    public void deleteRole(Long id) {
        roleRepository.deleteById(id);
    }

    public Optional<Role> getRoleById(Long id) {
        Role role = roleRepository.getReferenceById(id);
        return Optional.of(role);
    }
}
