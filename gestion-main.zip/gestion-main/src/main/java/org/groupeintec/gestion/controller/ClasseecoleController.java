package org.groupeintec.gestion.controller;

import org.groupeintec.gestion.model.Classe;
import org.groupeintec.gestion.model.Classeecole;
import org.groupeintec.gestion.service.ClasseecoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/classeecoles")
public class ClasseecoleController {
    @Autowired
    private ClasseecoleService classeecoleService;

    @GetMapping
    public List<Classeecole> getAllClasseEcoles() {
        return classeecoleService.getAllClasseEcoles();
    }
    @GetMapping("/classeparecole/{ecoleId}")
    public ResponseEntity<List<Classe>> getClassesByEcole(@PathVariable int ecoleId) {
        List<Classe> classes = classeecoleService.getClassesByEcole(ecoleId);
        return ResponseEntity.ok(classes);
    }
    @GetMapping("/{id}")
    public ResponseEntity<Classeecole> getClasseEcoleById(@PathVariable int id) {
        Optional<Classeecole> classeecole = classeecoleService.getClasseEcoleById(id);
        return classeecole.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public Classeecole createClasseEcole(@RequestBody Classeecole classeecole) {
        return classeecoleService.saveClasseEcole(classeecole);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Classeecole> updateClasseEcole(@PathVariable int id, @RequestBody Classeecole classeecoleDetails) {
        return classeecoleService.getClasseEcoleById(id)
                .map(classeecole -> {
                    classeecole.setClasse(classeecoleDetails.getClasse());
                    classeecole.setEcole(classeecoleDetails.getEcole());
                    return ResponseEntity.ok(classeecoleService.saveClasseEcole(classeecole));
                }).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Object> deleteClasseEcole(@PathVariable int id) {
        return classeecoleService.getClasseEcoleById(id)
                .map(classeecole -> {
                    classeecoleService.deleteClasseEcole(id);
                    return ResponseEntity.noContent().build();
                }).orElseGet(() -> ResponseEntity.notFound().build());
    }
}
