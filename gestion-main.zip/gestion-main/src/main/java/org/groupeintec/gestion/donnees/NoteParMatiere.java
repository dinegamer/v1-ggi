package org.groupeintec.gestion.donnees;

import lombok.Data;
import org.groupeintec.gestion.model.Matieresup;

import java.util.List;

@Data
public class NoteParMatiere {
    private Matieresup matieresup;
    private List<NoteParClasse> noteParClasses;
}
