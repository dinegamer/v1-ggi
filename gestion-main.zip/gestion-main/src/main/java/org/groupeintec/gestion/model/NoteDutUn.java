package org.groupeintec.gestion.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class NoteDutUn {
    private Etudiant etudiant;
    private Semestre sun;
    private Semestre sdeux;
    private BigDecimal mgsun;
    private BigDecimal mgsdeux;
    private BigDecimal mannuel;
    private String mention;
    private BigDecimal credit;
    private String appreciation;
}
