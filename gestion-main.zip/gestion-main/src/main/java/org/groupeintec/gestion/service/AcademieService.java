package org.groupeintec.gestion.service;

import org.groupeintec.gestion.model.Academie;
import org.groupeintec.gestion.repository.AcademieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AcademieService {
    @Autowired
    private AcademieRepository repository;

    public List<Academie> getAll() {
        return repository.findAll();
    }

    public Optional<Academie> getById(int id) {
        return repository.findById(id);
    }

    public Academie save(Academie academie) {
        return repository.save(academie);
    }

    public void delete(int id) {
        repository.deleteById(id);
    }
}
