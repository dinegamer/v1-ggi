package org.groupeintec.gestion.controller;

import org.groupeintec.gestion.dto.ClasseDTO;
import org.groupeintec.gestion.model.Classeecole;
import org.groupeintec.gestion.model.Eleveecole;
import org.groupeintec.gestion.repository.ClasseecoleRepository;
import org.groupeintec.gestion.repository.EleveecoleRepository;
import org.groupeintec.gestion.service.EleveEcoleService;
import org.groupeintec.gestion.service.EleveService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/eleveecoles")
public class EleveecoleController {
    @Autowired
    private EleveEcoleService eleveEcoleService;
    @GetMapping
    public ResponseEntity<List<Eleveecole>> getAllEleveecole(){
        return ResponseEntity.ok(eleveEcoleService.getAllEleveecole());
    }
    @PostMapping("/eleveparclasse")
    public ResponseEntity<List<Eleveecole>> EleveParClasse(@RequestBody String donnees[]){
        String an = donnees[0]; String ecole = donnees[1]; String classe = donnees[2];
        return ResponseEntity.ok(eleveEcoleService.eleveparclasse(an, ecole, classe));
    }
    @GetMapping("/nombreparclasse")
    public ResponseEntity<List<ClasseDTO>> NombreParClasse(){
        return ResponseEntity.ok(eleveEcoleService.nombreParClasse());
    }
    //affecter un etudiant
    @PostMapping
    public Eleveecole create(@RequestBody Eleveecole eleveecole) {
        return eleveEcoleService.save(eleveecole);
    }

    @GetMapping("/{id}")
    public Eleveecole getById(@PathVariable int id) {
        return eleveEcoleService.findById(id)
                .orElseThrow(() -> new RuntimeException("Eleveecole not found"));
    }

    @PutMapping("/{id}")
    public Eleveecole update(@PathVariable int id, @RequestBody Eleveecole eleveecole) {
        return eleveEcoleService.update(id, eleveecole);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable int id) {
        eleveEcoleService.delete(id);
    }
}
