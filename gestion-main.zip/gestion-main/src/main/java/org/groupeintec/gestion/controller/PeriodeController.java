package org.groupeintec.gestion.controller;

import org.groupeintec.gestion.model.Paiement;
import org.groupeintec.gestion.model.Periode;
import org.groupeintec.gestion.repository.PeriodeRepository;
import org.groupeintec.gestion.service.PaiementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/periodes")
@CrossOrigin(origins = "*")
public class PeriodeController {
    @Autowired
    private PeriodeRepository periodeRepository;
    @GetMapping
    public ResponseEntity<List<Periode>> getAllPeriode(){
        return ResponseEntity.ok(periodeRepository.findAll());
    }
}
