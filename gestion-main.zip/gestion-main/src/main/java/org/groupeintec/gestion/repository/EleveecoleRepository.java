package org.groupeintec.gestion.repository;

import org.groupeintec.gestion.dto.ClasseDTO;
import org.groupeintec.gestion.model.Eleveecole;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface EleveecoleRepository extends JpaRepository<Eleveecole, Integer> {
    @Query("SELECT ee FROM Eleveecole ee WHERE ee.anneeuv.id = :an AND ee.ecole.id = :ecole AND ee.classe.id = :classe")
    List<Eleveecole> eleveparclasse(String an, String ecole, String classe);
    @Query("SELECT COUNT(ee.eleve.id) as eleve, ee.classe.id as ecole FROM Eleveecole ee, Classe c WHERE ee.ecole.id = :i GROUP BY c.id")
    List<Eleveecole> nombreparclasse(int i);
}
