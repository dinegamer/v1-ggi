package org.groupeintec.gestion.controller;

import org.groupeintec.gestion.model.Ecole;
import org.groupeintec.gestion.repository.EcoleRepository;
import org.groupeintec.gestion.service.EcoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/ecoles")
public class EcoleController {
    @Autowired
    private EcoleService ecoleService;
    @GetMapping
    public ResponseEntity<List<Ecole>> getAllEcole(){
        return ResponseEntity.ok(ecoleService.findEcoleSup());
    }
    @GetMapping("/secondaires")
    public ResponseEntity<List<Ecole>> getAllSecondaire(){
        return ResponseEntity.ok(ecoleService.findEcole());
    }

    @GetMapping("/{id}")
    public Ecole getById(@PathVariable int id) {
        return ecoleService.getById(id);
    }

    @PostMapping
    public Ecole save(@RequestBody Ecole ecole) {
        return ecoleService.save(ecole);
    }

    @PutMapping("/{id}")
    public Ecole update(@PathVariable int id, @RequestBody Ecole ecole) {
        ecole.setIdEcole(id); // Assure-toi de bien modifier l'ID avant de mettre à jour
        return ecoleService.save(ecole);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable int id) {
        ecoleService.delete(id);
    }
}
