package org.groupeintec.gestion.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.groupeintec.gestion.donnees.EtatParCycle;

import java.math.BigDecimal;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TableaudebordDg {
    private Anneeuv anneep;
    private List<Tableaudebord> tableaudebords;
    private List<EtatParCycle> etatParCycles;
    private int totalEtudiant;
    private int totalChiffre;
    private int totalReduction;
    private int totalPaie;
    private int totalReliquat;
    private int totalReliquatp;
    private BigDecimal etatParRapportAnP;
    private BigDecimal etatFraisParAnp;
    private BigDecimal tauxRecouvrement;

}
