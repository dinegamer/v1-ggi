package org.groupeintec.gestion.donnees;

import lombok.Data;

@Data
public class EtudiantRequest {
    public String nomEtudiant;
    public String prenomEtudiant;
    public String numeroTuteur;
    public String telephoneEtudiant;
}
