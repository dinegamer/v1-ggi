package org.groupeintec.gestion.controller;

import org.groupeintec.gestion.model.Enseignant;
import org.groupeintec.gestion.repository.EnseignantRepository;
import org.groupeintec.gestion.service.EnseignantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/enseignants")
public class EnseignantController {
    @Autowired
    private EnseignantService enseignantService;

    @GetMapping
    public List<Enseignant> getAllEnseignants() {
        return enseignantService.getAllEnseignants();
    }
    //enseignants par ecole
    @GetMapping("/ecole/{ecoleId}")
    public List<Enseignant> ProfesseurParEcole(@PathVariable Long ecoleId){
        return enseignantService.getByEcoleId(ecoleId);
    }
    @GetMapping("/{id}")
    public Optional<Enseignant> getEnseignantById(@PathVariable int id) {
        return enseignantService.getEnseignantById(id);
    }

    @PostMapping
    public Enseignant createEnseignant(@RequestBody Enseignant enseignant) {
        return enseignantService.createEnseignant(enseignant);
    }

    @PutMapping("/{id}")
    public Enseignant updateEnseignant(@PathVariable int id, @RequestBody Enseignant enseignantDetails) {
        return enseignantService.updateEnseignant(id, enseignantDetails);
    }

    @DeleteMapping("/{id}")
    public void deleteEnseignant(@PathVariable int id) {
        enseignantService.deleteEnseignant(id);
    }
}
