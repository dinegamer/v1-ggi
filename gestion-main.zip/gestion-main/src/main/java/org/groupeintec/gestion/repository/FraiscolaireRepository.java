package org.groupeintec.gestion.repository;

import org.groupeintec.gestion.model.Fraiscolaire;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FraiscolaireRepository extends JpaRepository<Fraiscolaire, Integer> {
}
