package org.groupeintec.gestion.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Ecole {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idEcole;
    private String nomEcole;
    private String descriptionEcole;
    private String adresseEcole;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "categorie")
    private Categorie categorie;
}
