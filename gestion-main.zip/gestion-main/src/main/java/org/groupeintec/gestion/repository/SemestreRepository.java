package org.groupeintec.gestion.repository;

import org.groupeintec.gestion.model.Semestre;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface SemestreRepository extends JpaRepository<Semestre, Integer> {
    @Query("SELECT s FROM Semestre s WHERE s.id = :semestre")
    Semestre RetourUnSemetre(String semestre);
}
