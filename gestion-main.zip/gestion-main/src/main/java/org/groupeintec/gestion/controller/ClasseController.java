package org.groupeintec.gestion.controller;

import org.groupeintec.gestion.model.Classe;
import org.groupeintec.gestion.service.ClasseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/classes")
public class ClasseController {
    @Autowired
    private ClasseService classeService;

    @GetMapping
    public List<Classe> getAllClasses() {
        return classeService.getAllClasses();
    }

    @GetMapping("/{id}")
    public Optional<Classe> getClasseById(@PathVariable int id) {
        return classeService.getClasseById(id);
    }

    @PostMapping
    public Classe createClasse(@RequestBody Classe classe) {
        return classeService.createClasse(classe);
    }

    @PutMapping("/{id}")
    public Classe updateClasse(@PathVariable int id, @RequestBody Classe classeDetails) {
        return classeService.updateClasse(id, classeDetails);
    }

    @DeleteMapping("/{id}")
    public void deleteClasse(@PathVariable int id) {
        classeService.deleteClasse(id);
    }
}
