package org.groupeintec.gestion.repository;

import org.groupeintec.gestion.model.Classe;
import org.groupeintec.gestion.model.Classeecole;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ClasseecoleRepository extends JpaRepository<Classeecole, Integer> {

    List<Classeecole> findClasseByEcoleIdEcole(int ecoleId);
    @Query("SELECT c.classe FROM Classeecole c WHERE c.ecole.id = :ecoleId")
    List<Classe> findClassesByEcole(@Param("ecoleId") int ecoleId);
}
