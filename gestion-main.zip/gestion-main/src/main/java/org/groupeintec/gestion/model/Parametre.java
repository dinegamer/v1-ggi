package org.groupeintec.gestion.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "parametre")
public class Parametre {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "anneepardefaut")
    private Anneeuv anneepardefaut;
    @Column(name = "accesetudiant", columnDefinition = "boolean default false")
    private boolean accesetudiant;
    @Column(name = "c1", columnDefinition = "boolean default false")
    private boolean c1;
    @Column(name = "c2", columnDefinition = "boolean default false")
    private boolean c2;
    @Column(name = "c3", columnDefinition = "boolean default false")
    private boolean c3;
    @Column(name = "c4", columnDefinition = "boolean default false")
    private boolean c4;
    @Column(name = "c5", columnDefinition = "boolean default false")
    private boolean c5;
    @Column(name = "c6", columnDefinition = "boolean default false")
    private boolean c6;
    @Column(name = "c7", columnDefinition = "boolean default false")
    private boolean c7;
    private int pourcentage;
}
