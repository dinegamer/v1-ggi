package org.groupeintec.gestion.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.groupeintec.gestion.donnees.EtatParCycle;

import java.math.BigDecimal;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Tableaudebord {
    private Site site;
    private Anneeuv anneeuvp;
    private List<EtatParCycle> etatParCycles;
    private int totalEtudiant;
    private int totalFrais;
    private int totalReduction;
    private int totalpaie;
    private int totalReliquat;
    private int totalReliquatPaie;
    private BigDecimal etatParRapportAnP;
    private BigDecimal etatFraisParAnp;
    private BigDecimal tauxRecouvrement;
}
