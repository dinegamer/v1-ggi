package org.groupeintec.gestion.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Entity
@Table(name = "fraiscolaire")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Fraiscolaire {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "ecole")
    private Ecole ecole;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "classe")
    private Classe classe;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "eleve")
    private Eleve eleve;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "anneeuv")
    private Anneeuv anneeuv;

    private BigDecimal montant;
    private BigDecimal reduction;
}
