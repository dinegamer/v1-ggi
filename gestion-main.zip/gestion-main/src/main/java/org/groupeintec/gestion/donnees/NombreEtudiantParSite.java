package org.groupeintec.gestion.donnees;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.groupeintec.gestion.model.Site;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NombreEtudiantParSite {
    private Site site;
    private List<NombreEtudiantParCycle> nombreEtudiantParCycles;
    private int nombreEtudiant;
}
