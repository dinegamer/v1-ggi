package org.groupeintec.gestion.fonctions;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CalculNoteDeSemestre {
    private BigDecimal moyenne;
    private BigDecimal credit;
}
