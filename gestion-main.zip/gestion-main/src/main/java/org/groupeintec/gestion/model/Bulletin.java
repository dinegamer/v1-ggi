package org.groupeintec.gestion.model;

import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Bulletin {
    private Eleve eleve;
    private List<Note> notes;
    private BigDecimal total;
    private BigDecimal moyg;
    private String observation;
}
