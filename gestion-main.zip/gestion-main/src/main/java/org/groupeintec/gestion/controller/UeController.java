package org.groupeintec.gestion.controller;

import org.groupeintec.gestion.model.Enseigner;
import org.groupeintec.gestion.model.Ue;
import org.groupeintec.gestion.repository.EnseignerRepository;
import org.groupeintec.gestion.repository.UeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/ues")
public class UeController {
    @Autowired
    private UeRepository ueRepository;
    @GetMapping
    public ResponseEntity<List<Ue>> getAllUe(){
        return ResponseEntity.ok(ueRepository.findAll());
    }
}
