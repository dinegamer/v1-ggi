package org.groupeintec.gestion.repository;

import org.groupeintec.gestion.model.Etatanneeuv;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EtatanneeuvRepository extends JpaRepository<Etatanneeuv, Long> {
    @Query("SELECT e FROM Etatanneeuv e WHERE e.annee = :an AND e.cycle = :cycle AND e.site = :site")
    Etatanneeuv etatAnneAnterieur(int an, int cycle, int site);
}
