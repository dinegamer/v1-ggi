package org.groupeintec.gestion.service;

import org.groupeintec.gestion.donnees.FraisParCycle;
import org.groupeintec.gestion.donnees.FraisParFiliere;
import org.groupeintec.gestion.donnees.FraisParSite;
import org.groupeintec.gestion.model.*;
import org.groupeintec.gestion.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class FraixscolaireService {
    @Autowired
    private FraixscolaireRepository repository;
    @Autowired
    private InscrireRepository inscrireRepository;
    @Autowired
    private SiteRepository siteRepository;
    @Autowired
    private CycleRepository cycleRepository;
    @Autowired
    private FiliereRepository filiereRepository;
    @Autowired
    private AnneeuvRepository anneeuvRepository;
    @Autowired
    private EtudiantRepository etudiantRepository;
    //frai par filiere
    public FraisParFiliere fraisparfiliere(int site,int an,int cours,int filiere){
        //System.out.println(" mdt "+site+"-"+an+"-"+cours+"-"+filiere+" mdt");
        FraisParFiliere fraisParFiliere = new FraisParFiliere();
        //les inscriptions
        String cour;
        if(cours == 1){ cour = "Jour";}else {cour = "Soir";}
        List<Inscrire> inscrires = inscrireRepository.EtudiantParClasse(an,cour,filiere,site);
        List<Fraixscolaire> fraixscolaires = new ArrayList<>();
        for (Inscrire inscrire: inscrires){
            Fraixscolaire fraixscolaire = new Fraixscolaire();
            fraixscolaire.setEtudiant(inscrire.getEtudiant());
            fraixscolaire.setFiliere(inscrire.getFiliere());
            fraixscolaire.setAnneeuv(inscrire.getAnneeuv());
            int montant = repository.FraiPourEtudiant(inscrire.getAnneeuv().getId(),inscrire.getFiliere().getId(),inscrire.getEtudiant().getId()).orElse(0);
            if(montant == 0){
                fraixscolaire.setId(0);
            }else {
                Fraixscolaire f = repository.findByEtudiantIdAndAnneeuvIdAndFiliereId(inscrire.getEtudiant().getId(),inscrire.getAnneeuv().getId(),inscrire.getFiliere().getId());
                fraixscolaire.setId(f.getId());
            }
            fraixscolaire.setMontant(montant);
            int reduction = repository.ReductionPourEtudiant(inscrire.getAnneeuv().getId(),inscrire.getFiliere().getId(),inscrire.getEtudiant().getId()).orElse(0);
            fraixscolaire.setReduction(reduction);

            fraixscolaires.add(fraixscolaire);
        }
        fraisParFiliere.setFraixscolaires(fraixscolaires);
        //les frais
        int totalmontant = fraixscolaires.stream().mapToInt(Fraixscolaire::getMontant).sum();
        int reductiontotal = fraixscolaires.stream().mapToInt(Fraixscolaire::getReduction).sum();
        fraisParFiliere.setMontanttotal(totalmontant);
        fraisParFiliere.setFraixscolaires(fraixscolaires);
        fraisParFiliere.setReductiontotal(reductiontotal);
        //System.out.println(" mdt "+fraixscolaires+" mdt");

        return fraisParFiliere;
    }
    //frais par site
    public FraisParSite fraisParSite(int rive, int an){
        FraisParSite fraisParSite = new FraisParSite();
        Site site = siteRepository.getReferenceById(rive);
        fraisParSite.setSite(site);
        //liste des cycles
        List<Cycle> cycles = cycleRepository.findAllByOrderByNomAsc();
        List<FraisParCycle> fraisParCycles = new ArrayList<>();
        for(Cycle cycle: cycles){
            //les frais par cycle
            FraisParCycle fraisParCycle = new FraisParCycle();
            fraisParCycle.setCycle(cycle);
            fraisParCycles.add(fraisParCycle);
            //les frais par filiere
            List<Filiere> filieres = filiereRepository.filieresparcycle(cycle.getId());
            List<FraisParFiliere> fraisParFilieres = new ArrayList<>();
            for (Filiere filiere: filieres){
                FraisParFiliere fraisParFiliere = new FraisParFiliere();
                fraisParFiliere.setFiliere(filiere);
                int sommeMontantParFiliere = repository.SommeMontantParFiliere(an,filiere.getId()).orElse(0).intValue();
                fraisParFiliere.setMontanttotal(sommeMontantParFiliere);
                int sommeReductionParfiliere = repository.SommeReductionParfiliere(an,filiere.getId()).orElse(0).intValue();
                fraisParFiliere.setReductiontotal(sommeReductionParfiliere);
                fraisParFilieres.add(fraisParFiliere);
            }
            int sommeMontantParCycle = fraisParFilieres.stream().mapToInt(FraisParFiliere::getMontanttotal).sum();
            fraisParCycle.setMontantotal(sommeMontantParCycle);
            int sommeReductionParCycle = fraisParFilieres.stream().mapToInt(FraisParFiliere::getReductiontotal).sum();
            fraisParCycle.setTotalreduction(sommeReductionParCycle);
            fraisParCycle.setFraisParFilieres(fraisParFilieres);
        }
        //ajout des frai cycle
        fraisParSite.setFraisParCycles(fraisParCycles);
        int sommeMontantparSite = fraisParCycles.stream().mapToInt(FraisParCycle::getMontantotal).sum();
        fraisParSite.setTotalfrais(sommeMontantparSite);
        int sommeReductionParSite = fraisParCycles.stream().mapToInt(FraisParCycle::getTotalreduction).sum();
        fraisParSite.setTotalreduction(sommeReductionParSite);
        //retour
        return fraisParSite;
    }
    //search
    public Integer getUniqueFrais(int annne, int cours,int filiere,int site,int etudiant) {
        String cour;
        if(cours == 1){cour = "Jour";}else{cour = "Soir";}
        return repository.FraiPourEtudiant(annne,filiere,etudiant).orElse(0); // Retourne null si aucun résultat n'est trouvé
    }
    public Integer getUniqueReduction(int annne, int cours,int filiere,int site,int etudiant) {
        String cour;
        if(cours == 1){cour = "Jour";}else{cour = "Soir";}
        return repository.ReductionPourEtudiant(annne,filiere,etudiant).orElse(0); // Retourne null si aucun résultat n'est trouvé
    }
    public List<Fraixscolaire> getAll() {
        return repository.findAll();
    }

    public Fraixscolaire getById(int id) {
        return repository.findById(id).orElseThrow(() -> new RuntimeException("Frais non trouvé"));
    }

    public Fraixscolaire create(Fraixscolaire frais) {
        // Vérifier si le frais existe déjà
        boolean exists = repository.existsByEtudiantAndFiliereAndAnneeuv(frais.getEtudiant(), frais.getFiliere(), frais.getAnneeuv());

        if (exists) {
            throw new RuntimeException("Ce frais scolaire existe déjà !");
        }
        // Vérifier si l'année universitaire existe en base
        Anneeuv anneeuv = anneeuvRepository.findById(frais.getAnneeuv().getId())
                .orElseThrow(() -> new RuntimeException("Année universitaire introuvable !"));
        frais.setAnneeuv(anneeuv);
        // Vérifier si la filière existe en base
        Filiere filiere = filiereRepository.findById(frais.getFiliere().getId())
                .orElseThrow(() -> new RuntimeException("Filière introuvable !"));
        frais.setFiliere(filiere);
        // Vérifier si l'étudiant existe en base
        Etudiant etudiant = etudiantRepository.findById(frais.getEtudiant().getId())
                .orElseThrow(() -> new RuntimeException("Étudiant introuvable !"));
        frais.setEtudiant(etudiant);

        return repository.save(frais);
    }

    public Fraixscolaire update(int id, Fraixscolaire frais) {
        Fraixscolaire existing = getById(id);
        existing.setMontant(frais.getMontant());
        existing.setReduction(frais.getReduction());
        existing.setFiliere(frais.getFiliere());
        existing.setEtudiant(frais.getEtudiant());
        existing.setAnneeuv(frais.getAnneeuv());
        return repository.save(existing);
    }

    public void delete(int id) {
        repository.deleteById(id);
    }

    public List<Fraixscolaire> fraisetudiant(int etudiantId) {
        return repository.findByEtudiantId(etudiantId);
    }
}
