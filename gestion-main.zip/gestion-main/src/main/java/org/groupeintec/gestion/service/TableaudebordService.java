package org.groupeintec.gestion.service;

import org.groupeintec.gestion.donnees.EtatParCycle;
import org.groupeintec.gestion.dto.FiliereDTO;
import org.groupeintec.gestion.dto.TableauDeBordSite;
import org.groupeintec.gestion.model.*;
import org.groupeintec.gestion.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class TableaudebordService {
    @Autowired
    private CycleRepository cycleRepository;
    @Autowired
    private FiliereRepository filiereRepository;
    @Autowired
    private InscrireRepository inscrireRepository;
    @Autowired
    private SiteRepository siteRepository;
    @Autowired
    private FraixscolaireRepository fraixscolaireRepository;
    @Autowired
    private PaiementRepository paiementRepository;
    @Autowired
    private AnneeuvRepository anneeuvRepository;
    @Autowired
    private EtatanneeuvRepository etatanneeuvRepository;
    public Tableaudebord Tableaudebord(Integer annee, Integer siteId){

        Tableaudebord tableaudebord = new Tableaudebord();
        //annee precedent
        Anneeuv anneeuvp = anneeuvRepository.getReferenceById(annee-1);
        tableaudebord.setAnneeuvp(anneeuvp);
        Site site = siteRepository.getReferenceById(siteId);
        tableaudebord.setSite(site);
        List<Cycle> cycles = cycleRepository.findAllByOrderByNomAsc();
        List<EtatParCycle> etatParCycles = new ArrayList<>();
        for (Cycle cycle: cycles){
            EtatParCycle etatParCycle = new EtatParCycle();
            etatParCycle.setCycle(cycle);
            int nombreEtudiant =  inscrireRepository.nombreEtudiant(annee,cycle.getId(),site.getId());
            etatParCycle.setNombreEtudiant(nombreEtudiant);
            int chiffreAffaire = fraixscolaireRepository.SommeMontantParCycle(annee,cycle.getId(),site.getId());
            etatParCycle.setChiffreAffaire(chiffreAffaire);
            int reduction = fraixscolaireRepository.ReductionMontantParCycle(annee,cycle.getId(),site.getId());
            etatParCycle.setReduction(reduction);
            int montantpaye = paiementRepository.montantpaye(annee,cycle.getId(),site.getId());
            etatParCycle.setMontantpaye(montantpaye);
            //calcul du reliquat
            int chiffreAffairep = fraixscolaireRepository.SommeMontantParCycle(anneeuvp.getId(),cycle.getId(),site.getId());
            int reductionp = fraixscolaireRepository.ReductionMontantParCycle(anneeuvp.getId(),cycle.getId(),site.getId());
            int montantpayep = paiementRepository.montantpaye(anneeuvp.getId(),cycle.getId(),site.getId());
            int reliquat = chiffreAffairep - reductionp - montantpayep;
            etatParCycle.setReliquat(reliquat);
            //reliquat paie ,,
            int reliquatpaye = paiementRepository.reliquatpaie(annee, anneeuvp.getId(),site.getId(), cycle.getId());
            etatParCycle.setReliquatpays(reliquatpaye);
            etatParCycles.add(etatParCycle);
        }
        //total etudiant du cycle
        int totalEtudiant = etatParCycles.stream().mapToInt(EtatParCycle::getNombreEtudiant).sum();
        tableaudebord.setTotalEtudiant(totalEtudiant);
        int totalFrais = etatParCycles.stream().mapToInt(EtatParCycle::getChiffreAffaire).sum();
        tableaudebord.setTotalFrais(totalFrais);
        int totalReduction = etatParCycles.stream().mapToInt(EtatParCycle::getReduction).sum();
        tableaudebord.setTotalReduction(totalReduction);
        int totalpaie = etatParCycles.stream().mapToInt(EtatParCycle::getMontantpaye).sum();
        tableaudebord.setTotalpaie(totalpaie);
        int totalReliquat = etatParCycles.stream().mapToInt(EtatParCycle::getReliquat).sum();
        tableaudebord.setTotalReliquat(totalReliquat);
        int totalReliquatPaie = etatParCycles.stream().mapToInt(EtatParCycle::getReliquatpays).sum();
        tableaudebord.setTotalReliquatPaie(totalReliquatPaie);
        tableaudebord.setEtatParCycles(etatParCycles);
        //etat par rapport a l'anne enterieur
        int nombreParSiteEtAn = inscrireRepository.nombreParSiteEtAn(anneeuvp.getId(),site.getId());
        BigDecimal pourcentage = BigDecimal.valueOf(totalEtudiant)
                .multiply(BigDecimal.valueOf(100))
                .divide(BigDecimal.valueOf(nombreParSiteEtAn), 0, RoundingMode.HALF_UP);

        tableaudebord.setEtatParRapportAnP(pourcentage);

        int fraiParSiteEtAn = fraixscolaireRepository.SommeFraiAnP(anneeuvp.getId(),site.getId());
        BigDecimal pourcentagefrais = BigDecimal.valueOf(totalFrais)
                .multiply(BigDecimal.valueOf(100))
                .divide(BigDecimal.valueOf(fraiParSiteEtAn), 0, RoundingMode.HALF_UP);

        tableaudebord.setEtatFraisParAnp(pourcentagefrais);

        BigDecimal paies = new BigDecimal(totalpaie);
        BigDecimal reliquatp = new BigDecimal(totalReliquatPaie);
        BigDecimal reduction = new BigDecimal(totalReduction);
        BigDecimal chiffre = new BigDecimal(totalFrais);

        // Calcul de la somme des montants payés et reliquats payés
        BigDecimal totalPayes = paies.add(reliquatp);
        // Calcul de la différence entre le Chiffre d'Affaire et la réduction
        BigDecimal differenceCA = chiffre.subtract(reduction);
        // Calcul final de la formule
        BigDecimal pourcentagef = totalPayes.multiply(new BigDecimal("100")).divide(differenceCA, 0, RoundingMode.HALF_UP); // 4 décimales pour plus de précision
        // Calcul du pourcentage
        tableaudebord.setTauxRecouvrement(pourcentagef);
        return tableaudebord;
    }
    public Tableaudebord TableaudebordTotal(Integer annee) {
        Anneeuv anneep = anneeuvRepository.getReferenceById(annee - 1);
        Tableaudebord tableaudebord = new Tableaudebord();
        tableaudebord.setAnneeuvp(anneep);
        //les cycles
        List<Cycle> cycles = cycleRepository.findAllByOrderByNomAsc();
        List<EtatParCycle> etatParCycles = new ArrayList<>();
        for (Cycle cycle: cycles){
            EtatParCycle etatParCycle = new EtatParCycle();
            etatParCycle.setCycle(cycle);
            int nombreEtudiant =  inscrireRepository.nombreEtudiant(annee,cycle.getId());
            etatParCycle.setNombreEtudiant(nombreEtudiant);
            int chiffreAffaire = fraixscolaireRepository.SommeMontantTotalParCycle(annee,cycle.getId());
            etatParCycle.setChiffreAffaire(chiffreAffaire);
            int reduction = fraixscolaireRepository.ReductionMontantTotalParCycle(annee,cycle.getId());
            etatParCycle.setReduction(reduction);
            int montantpaye = paiementRepository.paie(annee,cycle.getId());
            etatParCycle.setMontantpaye(montantpaye);
            //calcul du reliquat
            int chiffreAffairep = fraixscolaireRepository.SommeMontantTotalParCycle(anneep.getId(),cycle.getId());
            int reductionp = fraixscolaireRepository.ReductionMontantTotalParCycle(anneep.getId(),cycle.getId());
            int montantpayep = paiementRepository.paie(anneep.getId(),cycle.getId());
            int reliquat = chiffreAffairep-reductionp-montantpayep;
            etatParCycle.setReliquat(reliquat);
            //reliquat paie ,,
            int reliquatpaye = paiementRepository.reliquattotalpaie(annee, anneep.getId(), cycle.getId());
            etatParCycle.setReliquatpays(reliquatpaye);
            etatParCycles.add(etatParCycle);
        }
        //ajout des cycles
        tableaudebord.setEtatParCycles(etatParCycles);
        //total etudiant du cycle
        int totalEtudiant = etatParCycles.stream().mapToInt(EtatParCycle::getNombreEtudiant).sum();
        tableaudebord.setTotalEtudiant(totalEtudiant);
        int frais = etatParCycles.stream().mapToInt(EtatParCycle::getChiffreAffaire).sum();
        tableaudebord.setTotalFrais(frais);
        int reduction = etatParCycles.stream().mapToInt(EtatParCycle::getReduction).sum();
        tableaudebord.setTotalReduction(reduction);
        int paies = etatParCycles.stream().mapToInt(EtatParCycle::getMontantpaye).sum();
        tableaudebord.setTotalpaie(paies);
        int reliquat = etatParCycles.stream().mapToInt(EtatParCycle::getReliquat).sum();
        tableaudebord.setTotalReliquat(reliquat);
        int reliquatp = etatParCycles.stream().mapToInt(EtatParCycle::getReliquatpays).sum();
        tableaudebord.setTotalReliquatPaie(reliquatp);
        //tableaudebord.setEtatParCycles(0);
        //etat par rapport a l'anne enterieur
        int etudiantp = inscrireRepository.nombreInscrit(anneep.getId());
        BigDecimal pourcentage = BigDecimal.valueOf(totalEtudiant)
                .multiply(BigDecimal.valueOf(100))
                .divide(BigDecimal.valueOf(etudiantp), 0, RoundingMode.HALF_UP);
        tableaudebord.setEtatParRapportAnP(pourcentage);

        int fraisp = fraixscolaireRepository.totalMontant(anneep.getId());
        BigDecimal pourcentagefrais = BigDecimal.valueOf(frais)
                .multiply(BigDecimal.valueOf(100))
                .divide(BigDecimal.valueOf(fraisp), 0, RoundingMode.HALF_UP);
        tableaudebord.setEtatFraisParAnp(pourcentagefrais);

        /**/
        BigDecimal paiesBD = new BigDecimal(paies);
        BigDecimal reliquatpp = new BigDecimal(reliquatp);
        BigDecimal reductionBD = new BigDecimal(reduction);
        BigDecimal fraisBD = new BigDecimal(frais);

        // Calcul de la somme des montants payés et reliquats payés
        BigDecimal totalPayes = paiesBD.add(reliquatpp);
        // Calcul de la différence entre le Chiffre d'Affaire et la réduction
        BigDecimal differenceCA = fraisBD.subtract(reductionBD);
        // Calcul final de la formule
        BigDecimal recouvrement = totalPayes.multiply(BigDecimal.valueOf(100)).divide(differenceCA, 0, RoundingMode.HALF_UP);
        tableaudebord.setTauxRecouvrement(recouvrement);
        return tableaudebord;

    }

    public List<TableauDeBordSite> tableaudebordsite(int an, int site) {
        List<TableauDeBordSite> tableauDeBordSites = new ArrayList<>();
        List<Cycle> cycles = cycleRepository.findAllByOrderByNomAsc();
        for (Cycle cycle: cycles){
            TableauDeBordSite tdbs = new TableauDeBordSite();
            tdbs.setCycle(cycle);
            //rechercher des filieres
            List<Filiere> filieres = filiereRepository.filieresparcycle(cycle.getId());
            List<FiliereDTO> filiereDTOS = new ArrayList<>();
            for (Filiere filiere: filieres){
                FiliereDTO filiereDTO = new FiliereDTO();
                filiereDTO.setFiliere(filiere);
                //nombre d'inscrit par filiere
                Optional<Integer> nmbetudiant = inscrireRepository.NombreEtudiantParFiliere(an,filiere.getId(),site);
                filiereDTO.setNombreinscrit(nmbetudiant);
                int montantfrai = fraixscolaireRepository.sommeFraisPourFiliereEtSiteEtAnnee(an,filiere.getId(),site);
                filiereDTO.setFrai(montantfrai);

                filiereDTOS.add(filiereDTO);
            }
            tdbs.setFilieres(filiereDTOS);
            //recherche des valeurs par cycle
            int totaetudiant = filiereDTOS.stream().mapToInt(f -> f.getNombreinscrit().orElse(0)).sum();
            tdbs.setNombreetudiant(totaetudiant);
            int frais = filiereDTOS.stream().mapToInt(f -> f.getFrai()).sum();
            tdbs.setFrai(frais);

            tableauDeBordSites.add(tdbs);
        }
        return tableauDeBordSites;
    }
}