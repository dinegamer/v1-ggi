package org.groupeintec.gestion.controller;

import org.groupeintec.gestion.donnees.StatistiqueParEtudiant;
import org.groupeintec.gestion.donnees.Statistiqueparclasse;
import org.groupeintec.gestion.model.Paiement;
import org.groupeintec.gestion.repository.AnneeuvRepository;
import org.groupeintec.gestion.repository.EtudiantRepository;
import org.groupeintec.gestion.repository.FiliereRepository;
import org.groupeintec.gestion.service.PaiementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/paiements")
@CrossOrigin(origins = "*")
public class PaiementController {
    @Autowired
    private PaiementService paiementService;
    @Autowired
    private FiliereRepository filiereRepository;
    @Autowired
    private AnneeuvRepository anneeuvRepository;
    @Autowired
    private EtudiantRepository etudiantRepository;
    /*  @GetMapping
     public ResponseEntity<List<Paiement>> getAllPaiement(){
         return ResponseEntity.ok(paiementRepository.findAll());
     }  /* @PostMapping("/totalmontantpaie")
     public ResponseEntity<Integer> getTotalMontantPai(@RequestBody int an){
         return ResponseEntity.ok(paiementRepository.totalmontantpaie(an));
     }*/
    //enregistrement d'un paiment
    @PostMapping("/enregistre")
    public ResponseEntity<Map<String, String>> enregistrePaiment(@RequestBody String[] donnees){
        String anneunv = donnees[0];
        String filiere = donnees[1];
        String etudiant = donnees[2];
        String reliquat = donnees[3];
        String anneereliquat = donnees[4];
        String montant = donnees[5];
        String enlettre = donnees[6];
        String datepaie = donnees[7];
        String motif = donnees[8];
        String dateAction = donnees[9];

        //System.out.println(donnees[0]+" "+donnees[1]+" "+donnees[2]+" "+donnees[3]+" "+donnees[4]+" "+donnees[5]+" "+donnees[6]+" "+donnees[7]+" ");
        Paiement paiement = new Paiement();
        paiement.setFiliere(filiereRepository.getReferenceById(Integer.valueOf(filiere)));
        paiement.setAnneunv(anneeuvRepository.getReferenceById(Integer.valueOf(anneunv)));
        paiement.setEtudiant(etudiantRepository.getReferenceById(Integer.valueOf(etudiant)));
        paiement.setMontant(Integer.parseInt(montant));
        paiement.setMotif(motif);
        paiement.setEnlettre(enlettre);
        if (Boolean.parseBoolean(reliquat) == true){
        paiement.setReliquat(Boolean.parseBoolean(reliquat));
        paiement.setAnneeuvreliquat(anneeuvRepository.getReferenceById(Integer.valueOf(anneereliquat)));
        }else {
            paiement.setReliquat(false);
            paiement.setAnneeuvreliquat(null);
        }
        paiement.setDateaction(dateAction);
        paiement.setDatepaie(datepaie);
        Map<String, String> response = paiementService.savePaiement(paiement);
        return ResponseEntity.ok(response);

    }
    //paiement pour un etudiant
    @PostMapping("/statistiqueetudiant")
    public ResponseEntity<StatistiqueParEtudiant> getStatistiqueEtudiant(@RequestBody int[] search){
        int etudiant = search[0]; int filiere = search[1]; int an = search[2]; int cours = search[3]; int site = search[4];
        return ResponseEntity.ok(paiementService.statistiqueParEtudiant(etudiant,filiere,an,cours, site));
    }
    //paiement par classe
    @PostMapping("/statistiqueclasse")
    public ResponseEntity<Statistiqueparclasse> getStatistiqueClasse(@RequestBody int[] search){
        int site = search[0]; int filiere = search[1]; int an = search[2]; int cours = search[3];
        return ResponseEntity.ok(paiementService.statistiqueparclasse(site,filiere,an,cours));

    }
    @GetMapping("/paretudiant/{etudiantId}")
    public ResponseEntity<List<Paiement>> getPaieEtudiant(@PathVariable int etudiantId){
        return ResponseEntity.ok(paiementService.paieParEtudiant(etudiantId));
    }
}
