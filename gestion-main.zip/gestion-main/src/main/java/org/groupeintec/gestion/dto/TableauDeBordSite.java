package org.groupeintec.gestion.dto;

import lombok.Data;
import org.groupeintec.gestion.model.Cycle;
import org.groupeintec.gestion.model.Filiere;

import java.util.List;

@Data
public class TableauDeBordSite {
    private Cycle cycle;
    private List<FiliereDTO> filieres;
    private Integer nombreetudiant;
    private Integer frai;
}
