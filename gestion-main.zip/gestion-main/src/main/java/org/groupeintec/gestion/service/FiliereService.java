package org.groupeintec.gestion.service;

import org.groupeintec.gestion.model.Filiere;
import org.groupeintec.gestion.model.Parametre;
import org.groupeintec.gestion.repository.FiliereRepository;
import org.groupeintec.gestion.repository.ParametreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class FiliereService {
    @Autowired
    private FiliereRepository repo;
    @Autowired
    private ParametreRepository parametreRepository;
    public Filiere save(Filiere f) {
        return repo.save(f);
    }

    public Filiere update(Filiere f) {
        return repo.save(f);
    }

    public List<Filiere> getAll() {
        return repo.findByOrderByNomAsc();
    }

    public void delete(int id) {
        repo.deleteById(id);
    }

    public List<Filiere> filieresparcycle(int cycle) {
        return repo.filieresparcycle(cycle);
    }

    public List<Filiere> filiereautorise() {
        Parametre parametre = parametreRepository.getReferenceById(1L);
        List<Filiere> filiereList = new ArrayList<>();
        boolean c1 = parametre.isC1(); boolean c4 = parametre.isC4(); boolean c7 = parametre.isC7();
        boolean c2 = parametre.isC2(); boolean c5 = parametre.isC5();
        boolean c3 = parametre.isC3(); boolean c6 = parametre.isC6();
        if (c1 || c2 || c3 || c4 || c5 || c6 || c7) {
            if (c1) {List<Filiere> filieres = repo.filieresparcycle(4); filiereList.addAll(filieres);}
            if (c2) {List<Filiere> filieres = repo.filieresparcycle(5); filiereList.addAll(filieres);}
            if (c3) {List<Filiere> filieres = repo.filieresparcycle(6); filiereList.addAll(filieres);}
            if (c4) {List<Filiere> filieres = repo.filieresparcycle(7); filiereList.addAll(filieres);}
            if (c5) {List<Filiere> filieres = repo.filieresparcycle(8); filiereList.addAll(filieres);}
            if (c6) {List<Filiere> filieres = repo.filieresparcycle(9); filiereList.addAll(filieres);}
            if (c7) {List<Filiere> filieres = repo.filieresparcycle(11);filiereList.addAll(filieres);}
        } else {
            // charger toutes les filières
            List<Filiere> filieres = repo.findByOrderByNomAsc();
            filiereList.addAll(filieres);
        }
        return filiereList;
    }
}
