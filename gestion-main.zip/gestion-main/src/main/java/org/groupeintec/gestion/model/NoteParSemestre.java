package org.groupeintec.gestion.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NoteParSemestre {
    private Semestre semestre;
    private List<NoteParTypeUe> noteParTypeUe;
    private BigDecimal mgsemestre;
    private BigDecimal creditsemestre;
    private String mentionsemestre;
    private String appreciationsemestre;
    private Anneeuv anneeuv;
    private Filiere filiere;
    private Etudiant etudiant;
}
