package org.groupeintec.gestion.controller;

import org.groupeintec.gestion.donnees.NombreEtudiantParFiliere;
import org.groupeintec.gestion.donnees.NombreEtudiantParSite;
import org.groupeintec.gestion.model.Etudiant;
import org.groupeintec.gestion.model.Inscrire;
import org.groupeintec.gestion.service.InscrireService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@Controller
@CrossOrigin(origins = "*")
@RequestMapping("/inscriptions")
public class InscrireController {
    @Autowired
    private InscrireService inscrireService;
    @GetMapping
    public ResponseEntity<List<Inscrire>> getAllInscrire(){
        return ResponseEntity.ok(inscrireService.getAll());
    }
    //nombre d'etudiant par site
    @GetMapping("/nombreetudiantparsite/{an}/{site}")
    public ResponseEntity<NombreEtudiantParSite> nombreetudiantparsite(@PathVariable int an, @PathVariable int site){
        return ResponseEntity.ok(inscrireService.nombreetudiantparsite(an,site));
    }
    //les inscription de l'etuidant
    @GetMapping("/etudiantinscrire/{etudiantId}")
    public ResponseEntity<List<Inscrire>> etudiantinscrire(@PathVariable int etudiantId){
        return ResponseEntity.ok(inscrireService.etudiantinscrire(etudiantId));
    }
    //nombre d'etudiant par an et site
    @GetMapping("/nombreetudiantparfiliere/{an}/{site}")
    public ResponseEntity<List<NombreEtudiantParFiliere>> nombreetudiantparfiliere(@PathVariable int an, @PathVariable int site){
        return ResponseEntity.ok(inscrireService.nombreetudiantparfiliere(an,site));
    }
    //recherche les etudiants d'une classe
    @PostMapping("/listeparclasse")
    public ResponseEntity<List<Etudiant>> listeEtudiantParClasse(@RequestBody int donnees[]){
        //System.out.println("*** mdt **** "+donnees[0]+"-*-"+donnees[1]+"-*-"+donnees[2]);
        int annee = donnees[0]; int cours = donnees[1]; int filiere = donnees[2];int site = donnees[3];
        return ResponseEntity.ok(inscrireService.EtudiantParFiliereAnneeCours(annee,cours,filiere,site));
    }
    //nombre d'etudiant par an
    @PostMapping("/nombreetudiant")
    public ResponseEntity<Integer> nombreInscritAn(@RequestBody int an){
        return ResponseEntity.ok(inscrireService.NombreEtudiant(an));
    }
    //enregistre
    @PostMapping("/enregistre")
    public ResponseEntity<Integer> inscrireEtudiant(@RequestBody String[] inscrire) {
        Inscrire inscrire1 = inscrireService.inscrireEtudiant(inscrire);
        return ResponseEntity.ok(inscrire1.getId());
    }

}
