package org.groupeintec.gestion.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.groupeintec.gestion.model.Etudiant;
import org.groupeintec.gestion.model.Fraixscolaire;
import org.groupeintec.gestion.model.Inscrire;
import org.groupeintec.gestion.model.Paiement;

import java.util.List;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EtudiantDetailsDTO {
    private Etudiant etudiant;
    private Inscrire inscrire;
    private Fraixscolaire fraixscolaire;
    private List<Paiement> paiements;
}
