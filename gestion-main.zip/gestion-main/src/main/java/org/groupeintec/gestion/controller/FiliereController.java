package org.groupeintec.gestion.controller;

import org.groupeintec.gestion.model.Filiere;
import org.groupeintec.gestion.repository.FiliereRepository;
import org.groupeintec.gestion.service.FiliereService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/filieres")
public class FiliereController {
    @Autowired
    private FiliereService service;
    @GetMapping
    public ResponseEntity<List<Filiere>> getAllFiliere(){
        return ResponseEntity.ok(service.getAll());
    }
    @PostMapping("/filieresparcycle")
    public ResponseEntity<List<Filiere>> getFiliereParCycle(@RequestBody int cycle){
        return ResponseEntity.ok(service.filieresparcycle(cycle));
    }
    @GetMapping("/controledaccess")
    public ResponseEntity<List<Filiere>> getFiliereAutorise(){
        return ResponseEntity.ok(service.filiereautorise());
    }
}
