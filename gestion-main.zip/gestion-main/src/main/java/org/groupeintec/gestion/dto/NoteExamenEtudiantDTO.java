package org.groupeintec.gestion.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.groupeintec.gestion.model.Etudiant;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
public class NoteExamenEtudiantDTO {
    private Etudiant etudiant;
    private BigDecimal notesun;
    private BigDecimal notesdeux;
    private BigDecimal mgan;
    private String mention;
    private BigDecimal credit;
    private String appreciation;
}
