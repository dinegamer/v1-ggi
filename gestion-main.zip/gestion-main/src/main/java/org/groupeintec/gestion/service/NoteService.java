package org.groupeintec.gestion.service;

import org.groupeintec.gestion.fonctions.Appreciation;
import org.groupeintec.gestion.model.Bulletin;
import org.groupeintec.gestion.model.Eleve;
import org.groupeintec.gestion.model.Note;
import org.groupeintec.gestion.repository.EleveRepository;
import org.groupeintec.gestion.repository.NoteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

@Service
public class NoteService {
    @Autowired
    private NoteRepository noteRepository;
    @Autowired
    private EleveRepository eleveRepository;
    public List<Note> getAllNotes(){
        List<Note> donnees = noteRepository.findAll();
        return donnees;
    }
    //bulletin d'un eleve
    public Bulletin NoteEleve(String eleve, String annee, String periode, String classe, String ecole){
        //retour de l'eleve
        Eleve eleve1 = eleveRepository.retourEleve(eleve);
        //retour du bulletin
        Bulletin bulletin = new Bulletin();
        bulletin.setEleve(eleve1);
        List<Note> donnees = noteRepository.NoteEleve(eleve, annee, periode, classe, ecole);
        bulletin.setNotes(donnees);
        //le total des moyennes
        BigDecimal moyg = BigDecimal.ZERO;
        int totalcoef = 0;
        for (Note donnee: donnees){
            BigDecimal moy = donnee.getMgc();
            moyg = moyg.add(moy);
            totalcoef += donnee.getMatiere().getCoefficient();
        }
        bulletin.setTotal(moyg);
        //moyenne
        BigDecimal coeft = new BigDecimal(totalcoef);
        BigDecimal moyenne = moyg.divide(coeft, 2, RoundingMode.HALF_UP);
        bulletin.setMoyg(moyenne);
        //appreciation
        Appreciation appreciation = new Appreciation();
        bulletin.setObservation(appreciation.Mention(moyenne));

        return bulletin;
    }
    //note par classe
    //note pour un eleve
    //note par matiere
    //relever
    //bulletin par classe
}
