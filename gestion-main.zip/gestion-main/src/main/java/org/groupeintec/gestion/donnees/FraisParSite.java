package org.groupeintec.gestion.donnees;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.groupeintec.gestion.model.Site;

import java.util.List;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class FraisParSite {
    private Site site;
    private List<FraisParCycle>  fraisParCycles;
    private int totalfrais;
    private int totalreduction;
}
