package org.groupeintec.gestion.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ListeParClasse {
    private List<Fraixscolaire> fraixscolaires;
    private int totalmontant;
    private int totalreduction;
}
