package org.groupeintec.gestion.service;
import org.groupeintec.gestion.model.Categorie;
import org.groupeintec.gestion.repository.CategorieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class CategorieService {
    @Autowired
    private CategorieRepository repository;
    public List<Categorie> getAll(){
        return repository.findAll();
    }
    public Categorie getById(int id){
        return repository.getReferenceById(id);
    }
    public Categorie save(Categorie categorie){
        return repository.save(categorie);
    }

    public void delete(int id){
        Categorie categorie = repository.getReferenceById(id);
        repository.delete(categorie);
    }

    public Categorie update(Categorie categorie) {
        return repository.save(categorie);
    }
}
