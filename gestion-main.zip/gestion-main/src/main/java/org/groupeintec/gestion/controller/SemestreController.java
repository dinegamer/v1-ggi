package org.groupeintec.gestion.controller;

import org.groupeintec.gestion.model.Semestre;
import org.groupeintec.gestion.repository.SemestreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("/semestres")
@CrossOrigin(origins = "*")
public class SemestreController {
    @Autowired
    private SemestreRepository semestreRepository;
    @GetMapping
    public ResponseEntity<List<Semestre>> getAllSemestre(){
        return ResponseEntity.ok(semestreRepository.findAll());
    }
    @GetMapping("/{id}")
    public ResponseEntity<Semestre> getSemestreById(@PathVariable("id") String id){
        return ResponseEntity.ok(semestreRepository.RetourUnSemetre(id));
    }
}
