package org.groupeintec.gestion.service;

import org.groupeintec.gestion.model.Ecole;
import org.groupeintec.gestion.repository.EcoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EcoleService {
    @Autowired
    private EcoleRepository ecoleRepository;
    public List<Ecole> getAll() {
        return ecoleRepository.findAll();
    }
    public Ecole getById(int id) {
        return ecoleRepository.findById(id).orElse(null);
    }
    public Ecole save(Ecole ecole) {
        return ecoleRepository.save(ecole);
    }

    public void delete(int id) {
        ecoleRepository.deleteById(id);
    }
    public List<Ecole> findEcoleSup(){
        return ecoleRepository.findEcoleSup();
    }
    public List<Ecole> findEcole(){
        return ecoleRepository.findEcole();
    }
}
