package org.groupeintec.gestion.controller;

import org.groupeintec.gestion.model.Academie;
import org.groupeintec.gestion.service.AcademieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/academies")
@CrossOrigin("*")
public class AcademieController {
    @Autowired
    private AcademieService service;

    @GetMapping
    public List<Academie> getAll() {
        return service.getAll();
    }

    @GetMapping("/{id}")
    public Optional<Academie> getById(@PathVariable int id) {
        return service.getById(id);
    }

    @PostMapping
    public Academie create(@RequestBody Academie academie) {
        return service.save(academie);
    }

    @PutMapping("/{id}")
    public Academie update(@PathVariable int id, @RequestBody Academie academie) {
        academie.setId(id);
        return service.save(academie);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable int id) {
        service.delete(id);
    }
}
