package org.groupeintec.gestion.service;

import org.groupeintec.gestion.model.Site;
import org.groupeintec.gestion.repository.SiteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SiteService {
    @Autowired
    private SiteRepository siteRepository;

    public List<Site> findAll() {
        return siteRepository.findAll();
    }
    public Site save(Site site) {
        return siteRepository.save(site);
    }
    public Site update(Site site) {
        return siteRepository.save(site);
    }
    public void delete(int id) {
        siteRepository.deleteById(id);
    }
    public Site findById(int id) {
        return siteRepository.findById(id).orElse(null);
    }
}
