package org.groupeintec.gestion.service;

import org.groupeintec.gestion.model.Anneeuv;
import org.groupeintec.gestion.repository.AnneeuvRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AnneeuvService {
    @Autowired
    private AnneeuvRepository repository;

    public List<Anneeuv> getAll() {
        return repository.findByOrderByIdDesc();
    }

    public Anneeuv getById(int id) {
        return repository.findById(id).orElse(null);
    }

    public Anneeuv save(Anneeuv anneeuv) {
        return repository.save(anneeuv);
    }

    public void delete(int id) {
        repository.deleteById(id);
    }
}
