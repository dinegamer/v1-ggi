package org.groupeintec.gestion.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ControleParCycle {
    private Etudiant etudiant;
    private BigDecimal moyennes1;
    private BigDecimal moyennes2;
    private BigDecimal moyenneannuelle;
    private String mention;
    private BigDecimal credit;
    private String appreciation;
    private Semestre semestreun;
    private Semestre semestredeux;
    private Cycle cycle;
}
