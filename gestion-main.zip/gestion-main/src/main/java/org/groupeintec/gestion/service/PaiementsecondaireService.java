package org.groupeintec.gestion.service;

import org.groupeintec.gestion.model.Paiementsecondaire;
import org.groupeintec.gestion.repository.PaiementsecondaireRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PaiementsecondaireService {
    @Autowired
    private PaiementsecondaireRepository repository;

    public List<Paiementsecondaire> paiementsecondaires(){
        return repository.findAll();
    }
}
