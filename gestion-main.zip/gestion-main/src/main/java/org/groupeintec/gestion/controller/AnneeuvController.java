package org.groupeintec.gestion.controller;

import org.groupeintec.gestion.model.Anneeuv;
import org.groupeintec.gestion.repository.AnneeuvRepository;
import org.groupeintec.gestion.service.AnneeuvService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/annees")
public class AnneeuvController {
    @Autowired
    private AnneeuvService service;
    @GetMapping
    public ResponseEntity<List<Anneeuv>> getAll() {
        return ResponseEntity.ok(service.getAll());
    }

    @GetMapping("/{id}")
    public Anneeuv getById(@PathVariable int id) {
        return service.getById(id);
    }

    @PostMapping
    public Anneeuv create(@RequestBody Anneeuv anneeuv) {
        return service.save(anneeuv);
    }

    @PutMapping("/{id}")
    public Anneeuv update(@PathVariable int id, @RequestBody Anneeuv anneeuv) {
        anneeuv.setId(id);
        return service.save(anneeuv);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable int id) {
        service.delete(id);
    }
}
