package org.groupeintec.gestion.repository;

import org.groupeintec.gestion.model.Typeue;
import org.groupeintec.gestion.model.Ue;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UeRepository extends JpaRepository<Ue, Long> {
    @Query("SELECT u FROM Ue u WHERE u.typeue = :typeue")
    List<Ue> ueParTypeue(Typeue typeue);
}
