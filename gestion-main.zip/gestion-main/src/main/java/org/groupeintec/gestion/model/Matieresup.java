package org.groupeintec.gestion.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Entity
@Table
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Matieresup {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String code;
    private String nom;
    @Column(precision = 10, scale = 2) // 10 chiffres au total, 2 chiffres après la virgule
    private BigDecimal credit;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "ue")
    private Ue ue;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "filiere")
    private Filiere filiere;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "semestre")
    private Semestre semestre;
}
