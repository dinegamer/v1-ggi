package org.groupeintec.gestion.controller;

import org.groupeintec.gestion.model.Enseigner;
import org.groupeintec.gestion.model.Matiere;
import org.groupeintec.gestion.repository.EnseignerRepository;
import org.groupeintec.gestion.service.EnseignerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/enseigners")
public class EnseignerController {
    @Autowired
    private EnseignerService enseignerService;

    @GetMapping
    public List<Enseigner> getAllEnseigners() {
        return enseignerService.getAllEnseigners();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Enseigner> getEnseignerById(@PathVariable int id) {
        Optional<Enseigner> enseigner = enseignerService.getEnseignerById(id);
        return enseigner.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).build());
    }

    @PostMapping
    public ResponseEntity<Enseigner> createEnseigner(@RequestBody Enseigner enseigner) {
        Enseigner createdEnseigner = enseignerService.createEnseigner(enseigner);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdEnseigner);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Enseigner> updateEnseigner(@PathVariable int id, @RequestBody Enseigner enseigner) {
        Enseigner updatedEnseigner = enseignerService.updateEnseigner(id, enseigner);
        return updatedEnseigner != null ? ResponseEntity.ok(updatedEnseigner)
                : ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEnseigner(@PathVariable int id) {
        return enseignerService.deleteEnseigner(id) ? ResponseEntity.noContent().build()
                : ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }
    //la liste des matieres par ecole et par annee
    @GetMapping("/enseigners")
    public List<Enseigner> getMatieresParEcoleEtAnnee(@RequestParam int ecoleId, @RequestParam int anneeId) {
        return enseignerService.getMatieresParEcoleEtAnnee(ecoleId, anneeId);
    }
}
