package org.groupeintec.gestion.service;

import org.groupeintec.gestion.model.Classe;
import org.groupeintec.gestion.model.Classeecole;
import org.groupeintec.gestion.repository.ClasseecoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ClasseecoleService {
    @Autowired
    private ClasseecoleRepository classeecoleRepository;

    public List<Classeecole> getAllClasseEcoles() {
        return classeecoleRepository.findAll();
    }

    public Optional<Classeecole> getClasseEcoleById(int id) {
        return classeecoleRepository.findById(id);
    }

    public Classeecole saveClasseEcole(Classeecole classeecole) {
        return classeecoleRepository.save(classeecole);
    }

    public void deleteClasseEcole(int id) {
        classeecoleRepository.deleteById(id);
    }


    public List<Classe> getClassesByEcole(int ecoleId) {
        return classeecoleRepository.findClassesByEcole(ecoleId);
    }
}
