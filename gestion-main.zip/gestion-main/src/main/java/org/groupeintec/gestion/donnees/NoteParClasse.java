package org.groupeintec.gestion.donnees;

import lombok.Data;
import org.groupeintec.gestion.model.Etudiant;

import java.math.BigDecimal;

@Data
public class NoteParClasse {
    private Etudiant etudiant;
    private BigDecimal cc;
    private BigDecimal ex;
    private BigDecimal mg;
    private BigDecimal credit;
    private String validation;
}
