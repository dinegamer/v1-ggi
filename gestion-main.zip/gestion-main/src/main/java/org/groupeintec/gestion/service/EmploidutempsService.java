package org.groupeintec.gestion.service;

import org.groupeintec.gestion.model.Emploidutemps;
import org.groupeintec.gestion.repository.EmploidutempsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmploidutempsService {

    @Autowired
    private EmploidutempsRepository repository;

    public List<Emploidutemps> getAllEmplois() {
        return repository.findAll();
    }
    public Optional<Emploidutemps> getEmploiById(int id) {
        return repository.findById(id);
    }
    public Emploidutemps saveEmploi(Emploidutemps emploi) {
        return repository.save(emploi);
    }

    public void deleteEmploi(int id) {
        repository.deleteById(id);
    }

    public List<Emploidutemps> getByClasseAnneeEcole(int classeId, int anneeuvId, int ecoleId) {
        return repository.findByClasseIdAndAnneeuvIdAndEcoleIdEcole(classeId, anneeuvId, ecoleId);
    }

    public List<Emploidutemps> getByProfesseurAnneeEcole(int professeurId, int anneeuvId, int ecoleId) {
        return repository.findByProfesseurIdAndAnneeuvIdAndEcoleIdEcole(professeurId, anneeuvId, ecoleId);
    }

    public List<Emploidutemps> getByAnneeEcole(int anneeuvId, int ecoleId) {
        return repository.findByAnneeuvIdAndEcoleIdEcole(anneeuvId, ecoleId);
    }
    public List<Emploidutemps> getByJourProfesseurAnneeEcole(String jour, int professeurId, int anneeuvId, int ecoleId) {
        return repository.findByJourAndProfesseurIdAndAnneeuvIdAndEcoleIdEcole(jour, professeurId, anneeuvId, ecoleId);
    }
    public List<Emploidutemps> getByJourAnneeEcole(String jour, int anneeuvId, int ecoleId) {
        return repository.findByJourAndAnneeuvIdAndEcoleIdEcole(jour, anneeuvId, ecoleId);
    }
    public List<Emploidutemps> getByProfesseurAnneeEcoleSemaine(int professeurId, int anneeuvId, int ecoleId) {
        return repository.findByProfesseurAndAnneeuvAndEcoleSemaine(professeurId, anneeuvId, ecoleId);
    }
}