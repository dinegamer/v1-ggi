package org.groupeintec.gestion.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MatiereDTO {
    private String nomMatiere;
    private BigDecimal credit;
    private List<NoteDTO> notes = new ArrayList<>();
}
