package org.groupeintec.gestion.controller;

import org.groupeintec.gestion.model.Emploidutemps;
import org.groupeintec.gestion.service.EmploidutempsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/emploidutemps")
public class EmploidutempsController {
    @Autowired
    private EmploidutempsService service;
    //l'ensemble des emploi du temps
    @GetMapping
    public List<Emploidutemps> getAllEmplois() {
        return service.getAllEmplois();
    }
    //un emploi du temps
    @GetMapping("/{id}")
    public ResponseEntity<Emploidutemps> getEmploiById(@PathVariable int id) {
        Optional<Emploidutemps> emploi = service.getEmploiById(id);
        return emploi.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }
    //Enregistre un emploi du temps
    @PostMapping
    public Emploidutemps createEmploi(@RequestBody Emploidutemps emploi) {
        return service.saveEmploi(emploi);
    }
    //mise a jour de l'emploi du temps
    @PutMapping("/{id}")
    public ResponseEntity<Emploidutemps> updateEmploi(@PathVariable int id, @RequestBody Emploidutemps emploi) {
        if (!service.getEmploiById(id).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        emploi.setId(id);
        return ResponseEntity.ok(service.saveEmploi(emploi));
    }
    //supprimer un emploi du temps
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEmploi(@PathVariable int id) {
        if (!service.getEmploiById(id).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        service.deleteEmploi(id);
        return ResponseEntity.noContent().build();
    }
    //emploi du temps par classe annee ecole
    @GetMapping("/classe/{classeId}/annee/{anneeuvId}/ecole/{ecoleId}")
    public List<Emploidutemps> getByClasseAnneeEcole(@PathVariable int classeId, @PathVariable int anneeuvId, @PathVariable int ecoleId) {
        return service.getByClasseAnneeEcole(classeId, anneeuvId, ecoleId);
    }
    //emploi du temps par professeur annee ecole
    @GetMapping("/professeur/{professeurId}/annee/{anneeuvId}/ecole/{ecoleId}")
    public List<Emploidutemps> getByProfesseurAnneeEcole(@PathVariable int professeurId, @PathVariable int anneeuvId, @PathVariable int ecoleId) {
        return service.getByProfesseurAnneeEcole(professeurId, anneeuvId, ecoleId);
    }
    //emploi du temps par annee ecole
    @GetMapping("/annee/{anneeuvId}/ecole/{ecoleId}")
    public List<Emploidutemps> getByAnneeEcole(@PathVariable int anneeuvId, @PathVariable int ecoleId) {
        return service.getByAnneeEcole(anneeuvId, ecoleId);
    }
    //emploi du temps par jour prof annee ecole
    @GetMapping("/jour/{jour}/professeur/{professeurId}/annee/{anneeuvId}/ecole/{ecoleId}")
    public List<Emploidutemps> getByJourProfesseurAnneeEcole(@PathVariable String jour, @PathVariable int professeurId, @PathVariable int anneeuvId, @PathVariable int ecoleId) {
        return service.getByJourProfesseurAnneeEcole(jour, professeurId, anneeuvId, ecoleId);
    }
    //par jour
    @GetMapping("/jour/{jour}/annee/{anneeuvId}/ecole/{ecoleId}")
    public List<Emploidutemps> getByJourAnneeEcole(@PathVariable String jour, @PathVariable int anneeuvId, @PathVariable int ecoleId) {
        return service.getByJourAnneeEcole(jour, anneeuvId, ecoleId);
    }
    //emploi du temps par prof pour une semaine
    @GetMapping("/semaine/professeur/{professeurId}/annee/{anneeuvId}/ecole/{ecoleId}")
    public List<Emploidutemps> getByProfesseurAnneeEcoleSemaine(
            @PathVariable int professeurId,
            @PathVariable int anneeuvId,
            @PathVariable int ecoleId
    ) {
        return service.getByProfesseurAnneeEcoleSemaine(professeurId, anneeuvId, ecoleId);
    }
}
