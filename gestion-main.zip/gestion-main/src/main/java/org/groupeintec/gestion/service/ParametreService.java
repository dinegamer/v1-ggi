package org.groupeintec.gestion.service;

import org.groupeintec.gestion.model.Parametre;
import org.groupeintec.gestion.repository.ParametreRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ParametreService {
    private final ParametreRepository parametreRepository;

    public ParametreService(ParametreRepository parametreRepository) {
        this.parametreRepository = parametreRepository;
    }

    public List<Parametre> findAll() {
        return parametreRepository.findAll();
    }

    public Parametre save(Parametre parametre) {
        return parametreRepository.save(parametre);
    }

    public void deleteById(Long id) {
        parametreRepository.deleteById(id);
    }

    public Parametre getById(Long id) {
        return parametreRepository.getReferenceById(id);
    }
}
