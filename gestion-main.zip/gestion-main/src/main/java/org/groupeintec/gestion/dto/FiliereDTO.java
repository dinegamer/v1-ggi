package org.groupeintec.gestion.dto;

import lombok.Data;
import org.groupeintec.gestion.model.Filiere;

import java.util.Optional;

@Data
public class FiliereDTO {
    private Filiere filiere;
    private Optional<Integer> nombreinscrit;
    private int frai;
}
