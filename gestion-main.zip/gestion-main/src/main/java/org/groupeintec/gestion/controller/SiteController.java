package org.groupeintec.gestion.controller;

import org.groupeintec.gestion.model.Site;
import org.groupeintec.gestion.repository.SiteRepository;
import org.groupeintec.gestion.service.SiteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/sites")
@CrossOrigin(origins = "*")
public class SiteController {
    @Autowired
    private SiteService siteService;
    @GetMapping
    public List<Site> getAll() {
        return siteService.findAll();
    }

    @PostMapping
    public Site save(@RequestBody Site site) {
        return siteService.save(site);
    }

    @PutMapping
    public Site update(@RequestBody Site site) {
        return siteService.update(site);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable int id) {
        siteService.delete(id);
    }

    @GetMapping("/{id}")
    public Site findById(@PathVariable int id) {
        return siteService.findById(id);
    }
}
