package org.groupeintec.gestion.repository;

import org.groupeintec.gestion.model.Enseignant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EnseignantRepository extends JpaRepository<Enseignant, Integer> {
    List<Enseignant> findByEcoleIdEcole(long ecoleId);
}
