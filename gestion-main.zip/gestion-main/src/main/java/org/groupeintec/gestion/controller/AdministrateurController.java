package org.groupeintec.gestion.controller;

import org.groupeintec.gestion.model.Administrateur;
import org.groupeintec.gestion.model.AuthRequest;
import org.groupeintec.gestion.model.User;
import org.groupeintec.gestion.service.AdministrateurService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.config.ConfigDataResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/administrateurs")
public class AdministrateurController {
    @Autowired
    private AdministrateurService administrateurService;
    //enregistrement
    @PostMapping
    public Administrateur addAdministrateur(@RequestBody Administrateur administrateur){
        return administrateurService.save(administrateur);
    }
    //liste des admin sup
    @GetMapping("/sup")
    public ResponseEntity<List<Administrateur>> getAllAdministrateursSup(){
        return ResponseEntity.ok(administrateurService.getAllAdministrateursSup());
    }
    //liste des admin secondaire
    @GetMapping("/second")
    public ResponseEntity<List<Administrateur>> getAllAdministrateursSecond(){
        return ResponseEntity.ok(administrateurService.getAllAdministrateursSecond());
    }
    //afficher un admin
    @GetMapping("/{id}")
    public ResponseEntity<Administrateur> getAdministrateur(@PathVariable(value = "id") Integer administrateurId) throws ConfigDataResourceNotFoundException {
        Administrateur administrateur = administrateurService.findById(administrateurId).orElse(null);
        return ResponseEntity.ok().body(administrateur);
    }
    //mise a jour
    @PutMapping("/{id}")
    public ResponseEntity<Administrateur> updateAdministrateur(@PathVariable(value = "id") Integer administrateurid, @RequestBody Administrateur administrateurDetails){

        Administrateur updateAdministrateur = administrateurService.updateAdmin(administrateurid, administrateurDetails);
        return ResponseEntity.ok(updateAdministrateur);
    }
    //la suppression
    @DeleteMapping("/{id}")
    public Map<String, Boolean> deleteAdministrateu(@PathVariable(value = "id") Integer administrateurId){
        administrateurService.deleteById(administrateurId);
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return response;
    }
    //connexion
    @PostMapping("/loginsecond")
    public ResponseEntity<?> loginsecond(@RequestBody String[] authRequest){
        try {
            // Appel au service pour authentifier l'utilisateur
            User user = administrateurService.administrateur(authRequest[0], authRequest[1]);
            //System.out.println(authRequest[0]+" "+ authRequest[1]+"69***69");
            return ResponseEntity.ok(user);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(e.getMessage()+" mdt123 ");
        }
    }
    //connexion des admins du sup
    @PostMapping("/loginsup")
    public ResponseEntity<?> login(@RequestBody AuthRequest authRequest) {
        try {
            // Appel au service pour authentifier l'utilisateur
            User user = administrateurService.authenticate(authRequest.getUsername(), authRequest.getPassword());
            //System.out.println(user+"69***69");
            return ResponseEntity.ok(user);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(e.getMessage());
        }
    }

}
