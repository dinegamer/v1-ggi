package org.groupeintec.gestion.repository;

import org.groupeintec.gestion.model.Parametre;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ParametreRepository extends JpaRepository<Parametre, Long> {
}
