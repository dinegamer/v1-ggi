package org.groupeintec.gestion.service;

import org.groupeintec.gestion.dto.ClasseDTO;
import org.groupeintec.gestion.model.Eleveecole;
import org.groupeintec.gestion.repository.EleveecoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class EleveEcoleService {
    @Autowired
    private EleveecoleRepository repository;

    public List<ClasseDTO> nombreParClasse() {
        List<ClasseDTO> donnees = new ArrayList<>();
        List<Eleveecole> eleveecoles = repository.nombreparclasse(20);
        for (Eleveecole eleveecole: eleveecoles){
            ClasseDTO classeDTO = new ClasseDTO();
            classeDTO.setNom(eleveecole.getClasse().getNom());
            donnees.add(classeDTO);
        }
        return donnees;
    }
    public List<Eleveecole> getAllEleveecole(){
        List<Eleveecole> donnees = repository.findAll();
        return donnees;
    }
    public List<Eleveecole> eleveparclasse(String an, String ecole, String classe){
        List<Eleveecole> donnees = repository.eleveparclasse(an, ecole, classe);
        return donnees;
    }
    public Eleveecole save(Eleveecole eleveecole) {
        return repository.save(eleveecole);
    }

    public List<Eleveecole> findAll() {
        return repository.findAll();
    }

    public Optional<Eleveecole> findById(int id) {
        return repository.findById(id);
    }

    public Eleveecole update(int id, Eleveecole updated) {
        return repository.findById(id).map(eleveecole -> {
            eleveecole.setEleve(updated.getEleve());
            eleveecole.setEcole(updated.getEcole());
            eleveecole.setClasse(updated.getClasse());
            eleveecole.setAnneeuv(updated.getAnneeuv());
            eleveecole.setAcademie(updated.getAcademie());
            return repository.save(eleveecole);
        }).orElseThrow(() -> new RuntimeException("Eleveecole n'existe pas'"));
    }

    public void delete(int id) {
        repository.deleteById(id);
    }
}
