package org.groupeintec.gestion.controller;

import org.groupeintec.gestion.dto.TableauDeBordSite;
import org.groupeintec.gestion.model.Tableaudebord;
import org.groupeintec.gestion.model.TableaudebordDg;
import org.groupeintec.gestion.service.TableaudebordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/dashboard")
@CrossOrigin(origins = "*")
public class DashboardController {
    @Autowired
    private TableaudebordService tableaudebordService;

    @GetMapping("/{annee}/{site}")
    public ResponseEntity<Tableaudebord> gettableaudebordDg(
            @PathVariable(value = "annee") Integer anneeId,
            @PathVariable(value = "site") Integer siteId
    ){
        return ResponseEntity.ok(tableaudebordService.Tableaudebord(anneeId,siteId));
    }
    @GetMapping("/detailsite/{annee}/{site}")
    public ResponseEntity<List<TableauDeBordSite>> getdetailsite(
            @PathVariable(value = "annee") Integer anneeId,
            @PathVariable(value = "site") Integer site
    ){
        return ResponseEntity.ok(tableaudebordService.tableaudebordsite(anneeId,site));
    }
    @GetMapping("/{annee}")
    public ResponseEntity<Tableaudebord> TableaudebordTotal(@PathVariable(value = "annee") Integer anneeId){
        return ResponseEntity.ok(tableaudebordService.TableaudebordTotal(anneeId));
    }

}
