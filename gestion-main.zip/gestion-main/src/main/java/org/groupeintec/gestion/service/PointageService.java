package org.groupeintec.gestion.service;

import org.groupeintec.gestion.model.Pointage;
import org.groupeintec.gestion.repository.PointageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PointageService {
    @Autowired
    private PointageRepository pointageRepository;

    public List<Pointage> pointages(){
        return pointageRepository.findAll();
    }
}
