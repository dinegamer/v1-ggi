package org.groupeintec.gestion.service;

import org.groupeintec.gestion.model.Departement;
import org.groupeintec.gestion.repository.DepartementRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepartementService {
    @Autowired
    private DepartementRepository repo;

    public List<Departement> getAllDepartement() {
        return repo.findAll();
    }

    public Departement getById(int id) {
        return repo.findById(id).orElse(null);
    }

    public Departement save(Departement d) {
        return repo.save(d);
    }

    public Departement update(Departement d) {
        return repo.save(d);
    }

    public void delete(int id) {
        repo.deleteById(id);
    }
}
