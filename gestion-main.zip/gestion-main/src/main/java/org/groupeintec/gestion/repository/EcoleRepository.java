package org.groupeintec.gestion.repository;

import org.groupeintec.gestion.model.Ecole;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EcoleRepository extends JpaRepository<Ecole, Integer> {
    @Query("SELECT e FROM Ecole e WHERE e.idEcole = 1")
    List<Ecole> findEcoleSup();
    @Query("SELECT e FROM Ecole e WHERE e.idEcole != 1 ")
    List<Ecole> findEcole();
}
