package org.groupeintec.gestion.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "paiementsecondaire")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Paiementsecondaire {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private int montant;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "eleve")
    private Eleve eleve;
    private String datepaie;
    private String enlettre;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "anneeuv")
    private Anneeuv anneeuv;
    private String motif;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "classe")
    private Classe classe;
    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "ecole")
    private Ecole ecole;

    private String numerorecu;
}
