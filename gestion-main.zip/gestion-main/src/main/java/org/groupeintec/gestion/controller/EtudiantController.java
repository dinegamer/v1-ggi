package org.groupeintec.gestion.controller;

import org.groupeintec.gestion.donnees.EtudiantRequest;
import org.groupeintec.gestion.dto.EtudiantDetailsDTO;
import org.groupeintec.gestion.model.Etudiant;
import org.groupeintec.gestion.service.EtudiantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/etudiants")
public class EtudiantController {
    @Autowired
    private EtudiantService etudiantService;
    @GetMapping
    public ResponseEntity<List<Etudiant>> getAllEtudiants(){
        return ResponseEntity.ok(etudiantService.getAllEtudiant());
    }
    //retourner un etudaint
    @GetMapping("/id/{id}")
    public ResponseEntity<Etudiant> getEtudiantById(@PathVariable int id) {
        Optional<Etudiant> etudiant = etudiantService.getEtudiantById(id);

        return etudiant.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
    @GetMapping("/{matricule}")
    public ResponseEntity<Map<String, String>> getEtudiantParMatricule(@PathVariable(value = "matricule") String matriucle){
        Map<String, String> response = etudiantService.etudiantParMatricule(matriucle);
        return ResponseEntity.ok(response);
    }
    @PostMapping("/save")
    public ResponseEntity<Map<String, String>> save(@RequestBody String[] donnees){
        Map<String, String> response = etudiantService.saveEtudiant(donnees);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/{id}/{an}/details")
    public ResponseEntity<EtudiantDetailsDTO> getEtudiantDetails(@PathVariable int id, @PathVariable int an) {
        return ResponseEntity.ok(etudiantService.getEtudiantDetails(id,an));
    }
    @PostMapping("/tranfereEntreClasse")
    public ResponseEntity<EtudiantDetailsDTO> transfereEtudiantEntreClasse(@RequestBody String[] donnees){
        return ResponseEntity.ok(etudiantService.transfereEtudiantEntreClasse(donnees));
    }
    //connexion etudiant
    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody String[] donnees){
        Map<String, Object> response = etudiantService.login(donnees);
        return ResponseEntity.ok(response);
    }
    @PutMapping("/{id}")
    public ResponseEntity<Etudiant> updateEtudiant(@PathVariable int id, @RequestBody Etudiant etudiantDetails) {
        Etudiant etudiant = etudiantService.getEtudiantById(id)
                .orElseThrow(() -> new RuntimeException("Étudiant non trouvé"));

        etudiant.setPassword("Intec@Sup*-");

        Etudiant updatedEtudiant = etudiantService.save(etudiant);
        return ResponseEntity.ok(updatedEtudiant);
    }
    @GetMapping("/search")
    public ResponseEntity<List<Etudiant>> rechercherEtudiants(
            @RequestParam(required = false) String nomEtudiant,
            @RequestParam(required = false) String prenomEtudiant,
            @RequestParam(required = false) String numeroTuteur,
            @RequestParam(required = false) String telephoneEtudiant) {

        List<Etudiant> etudiants = etudiantService.rechercherEtudiants(nomEtudiant, prenomEtudiant, numeroTuteur, telephoneEtudiant);
        return ResponseEntity.ok(etudiants);
    }
}
