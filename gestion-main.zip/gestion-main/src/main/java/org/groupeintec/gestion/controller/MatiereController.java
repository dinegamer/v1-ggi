package org.groupeintec.gestion.controller;

import org.groupeintec.gestion.model.Matiere;
import org.groupeintec.gestion.repository.ClasseRepository;
import org.groupeintec.gestion.repository.MatiereRepository;
import org.groupeintec.gestion.service.MatiereService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/matieres")
public class MatiereController {
    @Autowired
    private MatiereService matiereService;
    @GetMapping
    public List<Matiere> getAllMatieres() {
        return matiereService.getAllMatieres();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Matiere> getMatiereById(@PathVariable int id) {
        Optional<Matiere> matiere = matiereService.getMatiereById(id);
        return matiere.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).build());
    }

    @PostMapping
    public ResponseEntity<Matiere> createMatiere(@RequestBody Matiere matiere) {
        Matiere createdMatiere = matiereService.createMatiere(matiere);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdMatiere);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Matiere> updateMatiere(@PathVariable int id, @RequestBody Matiere matiere) {
        Matiere updatedMatiere = matiereService.updateMatiere(id, matiere);
        return updatedMatiere != null ? ResponseEntity.ok(updatedMatiere)
                : ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMatiere(@PathVariable int id) {
        return matiereService.deleteMatiere(id) ? ResponseEntity.noContent().build()
                : ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }
}
