package org.groupeintec.gestion.controller;

import org.groupeintec.gestion.model.*;
import org.groupeintec.gestion.repository.FiliereRepository;
import org.groupeintec.gestion.repository.MatieresupRepository;
import org.groupeintec.gestion.repository.SemestreRepository;
import org.groupeintec.gestion.repository.UeRepository;
import org.groupeintec.gestion.service.MatieresupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/matieresups")
@CrossOrigin(origins = "*")
public class MatieresupController {
    @Autowired
    private MatieresupService matieresupService;
    @Autowired
    private SemestreRepository semestreRepository;
    @Autowired
    private FiliereRepository filiereRepository;
    @Autowired
    private UeRepository ueRepository;
    @GetMapping
    public ResponseEntity<List<Matieresup>> getAllMatieres(){
        return ResponseEntity.ok(matieresupService.findAll());
    }
    @PostMapping(path = "/semestreandfiliere")
    public ResponseEntity<List<Matieresup>> getBySemestreAndFiliere(@RequestBody int donnees[]){
        int semestre = donnees[0];
        int filiere = donnees[1];
        return ResponseEntity.ok(matieresupService.ListeparMSF(semestre, filiere));
    }

    @PostMapping(path = "/semestreandfiliereue")
    public ResponseEntity<List<Matieresup>> getBySemestreAndFiliereAndUe(@RequestBody String donnees[]){
        String semestr = donnees[0];
        String filier = donnees[1];
        String ue = donnees[1];
        Semestre semestre = semestreRepository.getReferenceById(Integer.valueOf(semestr));
        Filiere filiere = filiereRepository.getReferenceById(Integer.valueOf(filier));
        Ue ue1 = ueRepository.getReferenceById(Long.valueOf(ue));

        return ResponseEntity.ok(matieresupService.ListeparMSFU(semestre, filiere, ue1));
    }
    //enregistrement
    @PostMapping(path = "/save")
    public ResponseEntity<?> save(@RequestBody Matieresup matieresup){
        //System.out.println(matieresup+"mdt****");
        return new ResponseEntity<>(matieresupService.save(matieresup), HttpStatus.CREATED);
    }
}
