package org.groupeintec.gestion.service;

import org.groupeintec.gestion.model.Filiere;
import org.groupeintec.gestion.model.Matieresup;
import org.groupeintec.gestion.model.Semestre;
import org.groupeintec.gestion.model.Ue;
import org.groupeintec.gestion.repository.MatieresupRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MatieresupService {
    @Autowired
    private MatieresupRepository matieresupRepository;
    public long TotalMatiereFiliereSemestre(String filiere, String semestre){
        long nombrematiere = matieresupRepository.nombreMFS(filiere, semestre);
        return nombrematiere;
    }

    public List<Matieresup> findAll() {
        List<Matieresup> matieresups = matieresupRepository.findAll();
        return matieresups;
    }

    public List<Matieresup> ListeparMSF(int semestre, int filiere) {
        List<Matieresup> matieresups = matieresupRepository.findBySemestreIdAndFiliereId(semestre,filiere);
        return matieresups;
    }

    public List<Matieresup> ListeparMSFU(Semestre semestre, Filiere filiere, Ue ue) {
        List<Matieresup> matieresups = matieresupRepository.findBySemestreIdAndFiliereIdAndUeId(semestre,filiere,ue);
        return matieresups;
    }

    public Matieresup save(Matieresup matieresup) {
        Matieresup matieresup1 = matieresupRepository.save(matieresup);
        return matieresup1;
    }
}
