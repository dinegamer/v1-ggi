package org.groupeintec.gestion.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "fraixscolaire")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Fraixscolaire {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(nullable = false)
    private int montant;

    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinColumn(name = "filiere", nullable = false)
    private Filiere filiere;

    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinColumn(name = "etudiant", nullable = false)
    private Etudiant etudiant;

    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinColumn(name = "anneeuv", nullable = false)
    private Anneeuv anneeuv;

    @Column(columnDefinition = "int default 0")
    private Integer reduction;
}

