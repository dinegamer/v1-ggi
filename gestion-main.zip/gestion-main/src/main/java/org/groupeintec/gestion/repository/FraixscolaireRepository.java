package org.groupeintec.gestion.repository;

import org.groupeintec.gestion.model.Anneeuv;
import org.groupeintec.gestion.model.Etudiant;
import org.groupeintec.gestion.model.Filiere;
import org.groupeintec.gestion.model.Fraixscolaire;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface FraixscolaireRepository extends JpaRepository<Fraixscolaire, Integer> {
    @Query("SELECT COALESCE(SUM(f.montant), 0) " +
            "FROM Fraixscolaire f, Inscrire i " +
            "WHERE f.etudiant.id = i.etudiant.id "+
            "AND f.filiere.id = i.filiere.id " +
            "AND f.anneeuv.id = i.anneeuv.id "+
            "AND i.anneeuv.id = :anneeId " +
            "AND i.filiere.id = :filiereId " +
            "AND i.rive.id = :siteId")
    Integer sommeFraisPourFiliereEtSiteEtAnnee(
            @Param("anneeId") int anneeId,
            @Param("filiereId") int filiereId,
            @Param("siteId") int siteId
    );

    @Query("SELECT SUM(f.montant) FROM Fraixscolaire f WHERE f.anneeuv.id = :annee AND f.filiere.id = :filiere AND f.etudiant.id = :etudiant")
    Optional<Integer> FraiPourEtudiant(int annee, int filiere, int etudiant);
    @Query("SELECT SUM(f.reduction) FROM Fraixscolaire f WHERE f.anneeuv.id = :annee AND f.filiere.id = :filiere AND f.etudiant.id = :etudiant")
    Optional<Integer> ReductionPourEtudiant(int annee, int filiere, int etudiant);
    //Somme frai par cycle
    @Query("SELECT SUM(f.montant) FROM Fraixscolaire f WHERE f.anneeuv.id = :annee AND f.filiere.id = :filiere")
    Optional<Integer> SommeMontantParFiliere(int annee, int filiere);
    //Somme frai par cycle
    @Query("SELECT SUM(f.reduction) FROM Fraixscolaire f WHERE f.anneeuv.id = :annee AND f.filiere.id = :filiere")
    Optional<Integer> SommeReductionParfiliere(int annee, int filiere);
    //frai par cycle
    @Query("SELECT COALESCE(SUM(f.montant), 0) FROM Fraixscolaire f " +
            "JOIN Inscrire i ON f.etudiant.id = i.etudiant.id " +
            "WHERE f.anneeuv.id = :annee " +
            "AND f.filiere.cycle.id = :cycle " +
            "AND i.rive.id = :site " +
            "AND f.anneeuv.id = i.anneeuv.id " +
            "AND f.filiere.id = i.filiere.id")
    int SommeMontantParCycle(@Param("annee") int annee, @Param("cycle") int cycle, @Param("site") int site);

    @Query("SELECT COALESCE(SUM(f.montant), 0) FROM Fraixscolaire f " +
            "JOIN f.etudiant e " +
            "JOIN Inscrire i ON i.etudiant.id = e.id " +
            "WHERE f.anneeuv.id = :annee " +
            "AND f.filiere.cycle.id = :cycle " +
            "AND i.anneeuv.id = :annee " +
            "AND i.filiere.id = f.filiere.id")
    Integer SommeMontantTotalParCycle(@Param("annee") int annee, @Param("cycle") int cycle);
    @Query("SELECT SUM(f.montant) FROM Fraixscolaire f WHERE f.anneeuv.id = :annee AND f.filiere.cycle.id = :cycle")
    Optional<Integer> SommeMontantTotal(int annee, int cycle);
    @Query("SELECT SUM(f.reduction) FROM Fraixscolaire f WHERE f.anneeuv.id = :annee AND f.filiere.cycle.id = :cycle")
    Optional<Integer> SommeMontantReduction(int annee, int cycle);
    //reduction
    @Query("SELECT COALESCE(SUM(f.reduction), 0) FROM Fraixscolaire f " +
            "JOIN Inscrire i ON f.etudiant.id = i.etudiant.id " +
            "WHERE f.anneeuv.id = :annee " +
            "AND f.filiere.cycle.id = :cycle " +
            "AND i.rive.id = :site " +
            "AND i.anneeuv.id = f.anneeuv.id " +
            "AND f.filiere.id = i.filiere.id")
    int ReductionMontantParCycle(@Param("annee") int annee, @Param("cycle") int cycle, @Param("site") int site);

    @Query("SELECT COALESCE(SUM(f.reduction), 0) FROM Fraixscolaire f " +
            "JOIN f.etudiant e " +
            "JOIN Inscrire i ON e.id = i.etudiant.id " +
            "WHERE f.anneeuv.id = :annee " +
            "AND f.filiere.cycle.id = :cycle " +
            "AND f.anneeuv.id = i.anneeuv.id " +
            "AND f.filiere.id = i.filiere.id")
    Integer ReductionMontantTotalParCycle(@Param("annee") int annee, @Param("cycle") int cycle);

    @Query("SELECT COALESCE(SUM(f.montant), 0) FROM Fraixscolaire f " +
            "JOIN Inscrire i ON f.etudiant.id = i.etudiant.id " +
            "WHERE f.anneeuv.id = :annee " +
            "AND i.rive.id = :site " +
            "AND f.anneeuv.id = i.anneeuv.id " +
            "AND f.filiere.id = i.filiere.id")
    int SommeFraiAnP(@Param("annee") int annee, @Param("site") int site);

    @Query("SELECT COALESCE(SUM(f.montant), 0) FROM Fraixscolaire f " +
            "JOIN Inscrire i ON f.etudiant = i.etudiant " +
            "WHERE f.anneeuv.id = :annee " +
            "AND f.filiere = i.filiere " +
            "AND f.anneeuv = i.anneeuv")
    int totalMontant(@Param("annee") int annee);


    Fraixscolaire findByEtudiantIdAndAnneeuvIdAndFiliereId(int etudiantId, int anneeuvId, int filiereId);

    boolean existsByEtudiantAndFiliereAndAnneeuv(Etudiant etudiant, Filiere filiere, Anneeuv anneeuv);

    List<Fraixscolaire> findByEtudiantId(int etudiantId);
}
