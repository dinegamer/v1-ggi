package org.groupeintec.gestion.repository;

import org.groupeintec.gestion.model.Inscrire;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface InscrireRepository extends JpaRepository<Inscrire, Long> {
    @Query("SELECT i FROM Inscrire i WHERE i.anneeuv.id = 8")
    List<Inscrire> findAllAnneeuvInscrires();
    //nombre d'etudiant total
    @Query("SELECT count(i.etudiant.id) FROM Inscrire i, Filiere f WHERE i.anneeuv.id = :an AND f.cycle.id = :cycle AND i.filiere.id = f.id")
    int nombreEtudiant(int an, int cycle);
    //nombre d'etudiant par type de cours et filiere et année
    @Query("SELECT count(i.etudiant.id) FROM Inscrire i WHERE i.anneeuv.id = :an AND  i.filiere.id = :filiere AND i.cours = :cours AND i.rive.id = :site")
    int nombreParTypeCours(int site, int an, int filiere, String cours);
    //nombre d'étudiant par an et par cycle
    @Query("SELECT COALESCE(COUNT(i), 0) FROM Inscrire i " +
            "WHERE i.anneeuv.id = :an " +
            "AND i.filiere.cycle.id = :cycle " +
            "AND i.rive.id = :site")
    Integer nombreEtudiant(@Param("an") int an, @Param("cycle") int cycle, @Param("site") int site);

    //nombre par site et par an
    @Query("SELECT count(i.etudiant.id) FROM Inscrire i WHERE i.anneeuv.id = :an AND i.rive.id = :site")
    int nombreParSiteEtAn(@Param("an") int an, @Param("site") int site);
    //nombre d'incrit par an
    @Query("SELECT COUNT(*) FROM Inscrire i WHERE i.anneeuv.id = :an")
    int nombreInscrit(@Param("an") int an);
    @Query("SELECT i FROM Inscrire i WHERE i.etudiant.id = :etudiant AND i.anneeuv.id = :an AND i.filiere.id = :filiere AND i.cours = :cours")
    Inscrire unInscrit(String an,String filiere, String etudiant, String cours);
    //liste des etudiants d'un classe
    @Query("SELECT i FROM Inscrire i WHERE i.anneeuv.id = :an AND i.cours = :cours AND i.filiere.id = :filiere")
    List<Inscrire> EtudiantParClasse(int an,String cours,int filiere);

    @Query("SELECT i FROM Inscrire i WHERE i.anneeuv.id = :an AND i.cours = :cours AND i.filiere.id = :filiere AND i.rive.id = :rive")
    List<Inscrire> EtudiantParClasse(int an,String cours,int filiere, int rive);
    //nombre d'etuidiant par filiere
    @Query("SELECT COUNT(*) FROM Inscrire i WHERE i.anneeuv.id = :an AND i.filiere.id = :filiere AND i.rive.id = :site")
    Optional<Integer> NombreEtudiantParFiliere(@Param("an") int an, @Param("filiere") int filiere, @Param("site") int site);

    Inscrire findByEtudiantIdAndAnneeuvId(int etudiantId,int anneeuvId);
    Optional<Inscrire> findByEtudiantIdAndAnneeuvIdAndFiliereId(int etudiantId, int anneeuvId, int filiere);

    List<Inscrire> findByEtudiantId(int etudiantId);
}
