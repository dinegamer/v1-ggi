package org.groupeintec.gestion.repository;

import org.groupeintec.gestion.model.Anneeuv;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AnneeuvRepository extends JpaRepository<Anneeuv, Integer> {
    public List<Anneeuv> findByOrderByIdDesc();

}
