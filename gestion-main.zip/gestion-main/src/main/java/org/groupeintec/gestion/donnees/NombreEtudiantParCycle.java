package org.groupeintec.gestion.donnees;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.groupeintec.gestion.model.Cycle;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NombreEtudiantParCycle {
    private Cycle cycle;
    private List<NombreEtudiantParFiliere> nombreEtudiantParFilieres;
    private int nombreEtudiant;
}
