package org.groupeintec.gestion.service;

import org.groupeintec.gestion.model.Cycle;
import org.groupeintec.gestion.repository.CycleRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CycleService {
    private CycleRepository repository;
    public List<Cycle> getAllCycle(){
        return repository.findAll();
    }
    public List<Cycle> getAll() {
        return repository.findAll();
    }

    public Cycle create(Cycle cycle) {
        return repository.save(cycle);
    }

    public Cycle update(int id, Cycle cycle) {
        cycle.setId(id);
        return repository.save(cycle);
    }

    public void delete(int id) {
        repository.deleteById(id);
    }
}
