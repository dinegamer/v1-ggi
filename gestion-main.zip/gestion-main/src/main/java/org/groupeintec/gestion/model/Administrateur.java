package org.groupeintec.gestion.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Table
@Entity
@Data
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"}) // Évite les problèmes de sérialisation JSON
public class Administrateur {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String matricule;
    private String nom;
    private String prenom;
    private String adresse;
    private String telephone;
    private String email;
    private String lieun;
    private String datedn;
    private String photo;
    private String username;
    private String password;
    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "role")
    private Role role;
    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "site", nullable = true)
    private Site site;
    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "ecole")
    private Ecole ecole;
}
