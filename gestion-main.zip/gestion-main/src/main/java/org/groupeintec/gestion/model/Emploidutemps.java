package org.groupeintec.gestion.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Emploidutemps {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String jour;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "matiere")
    private Matiere matiere;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "professeur")
    private Enseignant professeur;
    private String heuredebut;
    private String heurefin;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "classe")
    private Classe classe;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "ecole")
    private Ecole ecole;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "anneeuv")
    private Anneeuv anneeuv;
}
