package org.groupeintec.gestion.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Statistique {
    private Filiere classe;
    private String jour = "Jour";
    private String soir = "Soir";
    private int nombrejour;
    private int nombresoir;
    private Long validejour;
    private Long validesoir;
    private Long enjabementjour;
    private Long enjabementsoir;
    private Long nonvalidejour;
    private Long nonvalidesoir;
    private Long pourcentagejour;
    private Long pourcentagesoir;
}
