package org.groupeintec.gestion.service;

import org.groupeintec.gestion.model.Enseigner;
import org.groupeintec.gestion.model.Matiere;
import org.groupeintec.gestion.repository.EnseignerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EnseignerService {
    @Autowired
    private EnseignerRepository enseignerRepository;

    public List<Enseigner> getAllEnseigners() {
        return enseignerRepository.findAll();
    }

    public Optional<Enseigner> getEnseignerById(int id) {
        return enseignerRepository.findById(id);
    }

    public Enseigner createEnseigner(Enseigner enseigner) {
        return enseignerRepository.save(enseigner);
    }

    public Enseigner updateEnseigner(int id, Enseigner enseigner) {
        if (enseignerRepository.existsById(id)) {
            enseigner.setId(id);
            return enseignerRepository.save(enseigner);
        }
        return null;
    }

    public boolean deleteEnseigner(int id) {
        if (enseignerRepository.existsById(id)) {
            enseignerRepository.deleteById(id);
            return true;
        }
        return false;
    }
    public List<Enseigner> getMatieresParEcoleEtAnnee(int ecoleId, int anneeId) {
        return enseignerRepository.findMatieresByEcoleAndAnnee(ecoleId, anneeId);
    }
}
