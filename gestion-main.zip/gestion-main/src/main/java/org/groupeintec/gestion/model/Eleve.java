package org.groupeintec.gestion.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table
public class Eleve {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String matricule;
    private String nom;
    private String prenom;
    private String datedn;
    private String lieudn;
    private String prenompere;
    private String prenommere;
    private String nommere;
    private String nationalite;
    private String sexe;
}
/*
*  SELECT id, matricule, nom, prenom, datedn, lieudn, prenompere, prenommere, nommere, nationalite, sexe FROM `eleve`
 * */