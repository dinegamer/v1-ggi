package org.groupeintec.gestion.repository;

import org.groupeintec.gestion.model.Enseigner;
import org.groupeintec.gestion.model.Matiere;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EnseignerRepository extends JpaRepository<Enseigner, Integer> {
    @Query("SELECT e FROM Enseigner e WHERE e.ecole.id = :ecoleId AND e.anneeuv.id = :anneeId")
    List<Enseigner> findMatieresByEcoleAndAnnee(@Param("ecoleId") int ecoleId, @Param("anneeId") int anneeId);
}
