package org.groupeintec.gestion.donnees;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.groupeintec.gestion.model.Etudiant;
import org.groupeintec.gestion.model.Fraixscolaire;
import org.groupeintec.gestion.model.Paiement;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StatistiqueParEtudiant {
    private Etudiant etudiant;
    List<Paiement> paiements;
    private int frais;
    private int reduction;
    private int due;
    private int paie;
    private int reste;
    private double pourcentage;
}
