package org.groupeintec.gestion.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table
public class Eleveecole {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "eleve")
    private Eleve eleve;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "ecole")
    private Ecole ecole;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "classe")
    private Classe classe;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "anneeuv")
    private Anneeuv anneeuv;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "academie", nullable = true)
    private Academie academie;
}
