package org.groupeintec.gestion.repository;

import org.groupeintec.gestion.model.Etudiant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EtudiantRepository extends JpaRepository<Etudiant, Integer> {
    boolean existsByMatricule(String matricule);
    Optional<Etudiant> findByMatriculeAndPassword(String matricule, String password);

    List<Etudiant> findByNom(String nom);

    List<Etudiant> findByPrenom(String prenom);

    List<Etudiant> findByTeltuteur(String numeroTuteur);

    List<Etudiant> findByTelephone(String telephone);
}
