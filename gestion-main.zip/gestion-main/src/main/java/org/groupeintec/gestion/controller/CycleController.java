package org.groupeintec.gestion.controller;

import org.groupeintec.gestion.model.Cycle;
import org.groupeintec.gestion.repository.CycleRepository;
import org.groupeintec.gestion.service.CycleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/cycles")
public class CycleController {
    @Autowired
    private CycleService service;
    @GetMapping
    public ResponseEntity<List<Cycle>> getAllCycle(){
        return ResponseEntity.ok(service.getAllCycle());
    }
    @PostMapping
    public Cycle create(@RequestBody Cycle cycle) {
        return service.create(cycle);
    }

    @PutMapping("/{id}")
    public Cycle update(@PathVariable int id, @RequestBody Cycle cycle) {
        return service.update(id, cycle);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable int id) {
        service.delete(id);
    }

}
