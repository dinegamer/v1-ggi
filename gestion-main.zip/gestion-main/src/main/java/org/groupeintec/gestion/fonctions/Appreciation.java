package org.groupeintec.gestion.fonctions;

import java.math.BigDecimal;

public class Appreciation {
    private String mention;
    private String apprecier;

    public String getMention() {
        return mention;
    }

    public void setMention(String mention) {
        this.mention = mention;
    }

    public String getApprecier() {
        return apprecier;
    }

    public void setApprecier(String apprecier) {
        this.apprecier = apprecier;
    }

    public String Mention(BigDecimal mgg){
        int mg = mgg.intValue();
        if(mg < 6){
            setMention("Médiocre");
        }else
        if(5 < mg && mg < 10){
            setMention("Insuffissant");
        }else

        if(9 < mg && mg  < 12) {
            setMention("Passable");
        }else

        if(11 < mg && mg  < 14) {
            setMention("Assez Bien");
        }else

        if(13 < mg && mg  < 16) {
            setMention("Bien");
        }else

        if(15 < mg && mg < 18) {
            setMention("Trés Bien");
        }else

        if(17 < mg && mg < 20) {
            setMention("Exellent");
        }
        return getMention();
    }
    public String Apprecier(BigDecimal credit, BigDecimal my){
        int c = credit.intValue();
        int moy = my.intValue();
        if(c == 60 && moy >= 7){
            setApprecier("Admis");
        }else
            if(c >= 42 && moy >= 7){
            setApprecier("Admission Conditionnelle");
        }else{
            setApprecier("Ajourné");
        }
        return getApprecier();
    }
    //gestion des appreciations
    public String AppreciationSecondaire(BigDecimal mgg)
    {
        String appreciation = "**";
        int mg = mgg.intValue();
        if(mg < 6){appreciation = "Médiocre";}else
        if(5 < mg && mg < 10){appreciation = "Insuffissant";}else
        if(9 < mg && mg  < 12) {appreciation = "Passable";}else
        if(11 < mg && mg  < 14) {appreciation = "Assez Bien";}else
        if(13 < mg && mg  < 16) {appreciation = "Bien";}else
        if(15 < mg && mg < 18) {appreciation = "Trés Bien";}else
        if(17 < mg && mg <= 20) {appreciation = "Exellent";}
        return appreciation;
    }
    public String AppreciationTypeue(BigDecimal mg){
        String appreciation = "**";
        int m = mg.intValue();
        if(m<10){
            appreciation= "Non Validé";
        }else{
            appreciation= "Validé";
        }
        return appreciation;
    }
    public String AppreciationSemestre(BigDecimal my, BigDecimal credit){
        int c = credit.intValue();
        int moy = my.intValue();
        if(c < 30 || moy < 10){
            setApprecier("Non Validé");
        }else{
            setApprecier("Validé");
        }
        return getApprecier();
    }
}
