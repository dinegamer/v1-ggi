package org.groupeintec.gestion.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TypeUEDTO {
    private String nomTypeUE;
    private List<MatiereDTO> matieres = new ArrayList<>();
    private List<EtudiantDTO> etudiants = new ArrayList<>();
}
