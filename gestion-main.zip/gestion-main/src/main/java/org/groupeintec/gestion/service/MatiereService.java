package org.groupeintec.gestion.service;

import org.groupeintec.gestion.model.Matiere;
import org.groupeintec.gestion.repository.MatiereRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MatiereService {
    @Autowired
    private MatiereRepository matiereRepository;

    public List<Matiere> getAllMatieres() {
        return matiereRepository.findAll();
    }

    public Optional<Matiere> getMatiereById(int id) {
        return matiereRepository.findById(id);
    }

    public Matiere createMatiere(Matiere matiere) {
        return matiereRepository.save(matiere);
    }

    public Matiere updateMatiere(int id, Matiere matiere) {
        if (matiereRepository.existsById(id)) {
            matiere.setId(id);
            return matiereRepository.save(matiere);
        }
        return null;
    }

    public boolean deleteMatiere(int id) {
        if (matiereRepository.existsById(id)) {
            matiereRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
