package org.groupeintec.gestion.controller;
import org.groupeintec.gestion.donnees.FraisParFiliere;
import org.groupeintec.gestion.donnees.FraisParSite;
import org.groupeintec.gestion.model.Fraixscolaire;
import org.groupeintec.gestion.service.FraixscolaireService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("/frais")
@CrossOrigin(origins = "*")
public class FraixscolaireController {
    @Autowired
    private FraixscolaireService fraixscolaireService;
    //frais par filiere
    @GetMapping("/fraisparfiliere/{site}/{an}/{cours}/{filiere}")
    public ResponseEntity<FraisParFiliere> fraisparfiliere(@PathVariable int site, @PathVariable int an, @PathVariable int cours, @PathVariable int filiere){
        return ResponseEntity.ok(fraixscolaireService.fraisparfiliere(site,an,cours,filiere));
    }
    //les frais de l'etudiant
    @GetMapping("/fraisetudiant/{etudiantId}")
    public ResponseEntity<List<Fraixscolaire>> fraisetudiant(@PathVariable int etudiantId){
        return ResponseEntity.ok(fraixscolaireService.fraisetudiant(etudiantId));
    }
    //frais par site
    @GetMapping("/fraisparsite/{site}/{an}")
    public ResponseEntity<FraisParSite> fraisParSite(@PathVariable int site, @PathVariable int an){
        //System.out.println(site+' '+an);
        return ResponseEntity.ok(fraixscolaireService.fraisParSite(site,an));
    }
    //recherche frai
    @PostMapping("/search")
    public ResponseEntity<Integer> search(@RequestBody int[] search){
        int annne = search[0]; int cours = search[1]; int filiere = search[2]; int site = search[3]; int etudiant = search[4];
        int resultat = fraixscolaireService.getUniqueFrais(annne,cours,filiere,site,etudiant);
        //System.out.println(resultat+" mdt");
        return ResponseEntity.ok(resultat);

    }
    @GetMapping
    public List<Fraixscolaire> getAll() {
        return fraixscolaireService.getAll();
    }

    @GetMapping("/{id}")
    public Fraixscolaire getById(@PathVariable int id) {
        return fraixscolaireService.getById(id);
    }

    @PostMapping
    public Fraixscolaire create(@RequestBody Fraixscolaire frais) {
        return fraixscolaireService.create(frais);
    }

    @PutMapping("/{id}")
    public Fraixscolaire update(@PathVariable int id, @RequestBody Fraixscolaire frais) {
        return fraixscolaireService.update(id, frais);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable int id) {
        fraixscolaireService.delete(id);
    }
}
