package org.groupeintec.gestion.repository;

import org.groupeintec.gestion.model.Paiement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PaiementRepository extends JpaRepository<Paiement, Integer> {
    //verifier l'existance du paiement
    @Query("SELECT COUNT(p) > 0 FROM Paiement p WHERE p.filiere.id = :filiereId AND p.etudiant.id = :etudiantId AND p.anneunv.id = :anneunvId AND p.montant = :montant AND p.datepaie = :datepaie")
    boolean existsPaiement(int etudiantId,int anneunvId,int filiereId,int montant, String datepaie);
    //montant paie par cycle
    @Query("SELECT COALESCE(SUM(p.montant), 0) FROM Paiement p " +
            "JOIN Inscrire i ON p.etudiant.id = i.etudiant.id " +
            "WHERE p.anneunv.id = :an " +
            "AND p.filiere.cycle.id = :cycle " +
            "AND i.rive.id = :site " +
            "AND p.filiere.id = i.filiere.id " +
            "AND p.anneunv.id = i.anneeuv.id " )
    int montantpaye(@Param("an") int an, @Param("cycle") int cycle, @Param("site") int site);

    @Query("SELECT COALESCE(SUM(p.montant), 0) FROM Paiement p " +
            "JOIN Inscrire i ON p.etudiant.id = i.etudiant.id " +
            "WHERE p.anneunv.id = :an " +
            "AND p.filiere.cycle.id = :cycle " +
            "AND p.filiere.id = i.filiere.id " +
            "AND p.anneunv.id = i.anneeuv.id ")
    int paie(@Param("an") int an, @Param("cycle") int cycle);

    @Query("SELECT SUM(p.montant) FROM Paiement p WHERE p.anneeuvreliquat.id = :an AND p.filiere.cycle.id = :cycle ")
    Optional<Integer> reliquattpaie(int an, int cycle);
    @Query("SELECT COALESCE(SUM(p.montant), 0) FROM Paiement p " +
            "JOIN Inscrire i ON i.etudiant.id = p.etudiant.id " +
            "WHERE p.anneunv.id = :an " +
            "AND i.anneeuv.id = :anp " +
            "AND p.filiere.id = i.filiere.id " +
            "AND p.filiere.cycle.id = :cycle " +
            "AND p.reliquat = true " +
            "AND i.rive.id = :site "+
            "AND p.anneeuvreliquat.id = :anp")
    int reliquatpaie(@Param("an") int an, @Param("anp") int anp, @Param("site") int site, @Param("cycle") int cycle);

    @Query("SELECT COALESCE(SUM(p.montant), 0) FROM Paiement p " +
            "JOIN Inscrire i ON i.etudiant.id = p.etudiant.id " +
            "WHERE p.anneunv.id = :an " +
            "AND i.anneeuv.id = :anp " +
            "AND p.filiere.id = i.filiere.id " +
            "AND p.filiere.cycle.id = :cycle " +
            "AND p.reliquat = true " +
            "AND p.anneeuvreliquat.id = :anp")
    int reliquattotalpaie(@Param("an") int an, @Param("anp") int anp, @Param("cycle") int cycle);

    //statistique pour une etudiant
    @Query("SELECT p FROM Paiement p WHERE p.etudiant.id = :etudiant AND p.filiere.id = :filiere AND p.anneunv.id = :an")
    List<Paiement> statistiqueEtudiant(int etudiant, int filiere, int an);

    List<Paiement> findByEtudiantIdAndAnneunvId(int etudiantId, int anneeuvId);
    //les paiements de l'etudiant
    List<Paiement> findByEtudiantId(int etudiantId);

}
