package org.groupeintec.gestion.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NoteDutDeux {
    private Etudiant etudiant;
    private BigDecimal mgsun;
    private BigDecimal mgsdeux;
    private BigDecimal mdut;
    private BigDecimal mannuel;
    private String mention;
    private BigDecimal credit;
    private String appreciation;
}
