package org.groupeintec.gestion.controller;

import org.groupeintec.gestion.model.Categorie;
import org.groupeintec.gestion.service.CategorieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/categories")
public class CategorieController {
    @Autowired
    private CategorieService service;
    @GetMapping
    public List<Categorie> getAll() {
        return service.getAll();
    }

    @GetMapping("/{id}")
    public Categorie getById(@PathVariable int id) {
        return service.getById(id);
    }

    @PostMapping
    public Categorie save(@RequestBody Categorie categorie) {
        return service.save(categorie);
    }

    @PutMapping
    public Categorie update(@RequestBody Categorie categorie) {
        return service.update(categorie);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable int id) {
        service.delete(id);
    }

}
