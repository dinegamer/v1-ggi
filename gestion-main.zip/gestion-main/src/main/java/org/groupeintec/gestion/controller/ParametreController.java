package org.groupeintec.gestion.controller;

import org.groupeintec.gestion.model.Parametre;
import org.groupeintec.gestion.service.ParametreService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("/parametres")
@CrossOrigin(origins = "*")
public class ParametreController {
    private final ParametreService parametreService;

    public ParametreController(ParametreService parametreService) {
        this.parametreService = parametreService;
    }

    @GetMapping
    public List<Parametre> getAllParametres() {
        return parametreService.findAll();
    }
    @GetMapping("/{id}")
    public Parametre getParametre(@PathVariable Long id){
        return parametreService.getById(id);
    }

    @PostMapping
    public Parametre addParametre(@RequestBody Parametre parametre) {
        return parametreService.save(parametre);
    }

    @DeleteMapping("/{id}")
    public void deleteParametre(@PathVariable Long id) {
        parametreService.deleteById(id);
    }
}
