package org.groupeintec.gestion.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class NoteDTO {
    private int etudiantId;
    private String nomEtudiant;
    private String prenomEtudiant;
    private String matricule;
    private BigDecimal noteClasse;
    private BigDecimal noteExamen;
    private BigDecimal moyenne;
    private BigDecimal noteCredit;
    private String validation; // "V" ou "NV"
}
