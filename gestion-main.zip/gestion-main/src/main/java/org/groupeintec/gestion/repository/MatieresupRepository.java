package org.groupeintec.gestion.repository;

import org.groupeintec.gestion.model.Filiere;
import org.groupeintec.gestion.model.Matieresup;
import org.groupeintec.gestion.model.Semestre;
import org.groupeintec.gestion.model.Ue;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MatieresupRepository extends JpaRepository<Matieresup, Integer> {
    //liste de matiere par filiere et semestre
    @Query("SELECT m FROM Matieresup m WHERE m.semestre.id = :semestre AND m.filiere.id = :filiere")
    List<Matieresup> ListeparMSF(int semestre, int filiere);
    //les matieres par type ue
    @Query("SELECT m FROM Matieresup m, Filiere f, Ue u, Typeue tu " +
            " WHERE tu.id = :tue AND f.id = :filiere AND m.filiere.id = f.id " +
            " AND m.ue.id = u.id AND u.typeue.id = tu.id AND m.semestre.id = :semestre")
    List<Matieresup> matierepartypeue(int tue, int filiere, int semestre);
    //liste de matiere par filiere et semestre
    @Query("SELECT m FROM Matieresup m WHERE m.semestre.id = :semestre AND m.filiere.id = :filiere AND m.ue.id = :ue")
    List<Matieresup> ListeparMSFU(String semestre, String filiere, String ue);
    //nombre de matiere par filiere et par semestre
    @Query("SELECT COUNT(*) FROM Matieresup m WHERE m.filiere.id = :filiere AND m.semestre.id = :semestre")
    long nombreMFS(String filiere, String semestre);

    List<Matieresup> findBySemestreIdAndFiliereId(int semestre, int filiere);

    List<Matieresup> findBySemestreIdAndFiliereIdAndUeId(Semestre semestre, Filiere filiere, Ue ue);
}
