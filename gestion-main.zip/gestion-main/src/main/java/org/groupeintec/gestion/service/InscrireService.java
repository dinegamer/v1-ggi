package org.groupeintec.gestion.service;

import org.groupeintec.gestion.donnees.NombreEtudiantParCycle;
import org.groupeintec.gestion.donnees.NombreEtudiantParFiliere;
import org.groupeintec.gestion.donnees.NombreEtudiantParSite;
import org.groupeintec.gestion.model.*;
import org.groupeintec.gestion.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class InscrireService {
    @Autowired
    private InscrireRepository inscrireRepository;
    @Autowired
    private CycleRepository cycleRepository;
    @Autowired
    private FiliereRepository filiereRepository;
    @Autowired
    private SiteRepository siteRepository;
    @Autowired
    private AnneeuvRepository anneeuvRepository;
    @Autowired
    private EtudiantRepository etudiantRepository;
    public List<Inscrire> etudiantinscrire(int etudiantId){
        List<Inscrire> inscrires = inscrireRepository.findByEtudiantId(etudiantId);
        return inscrires;
    }
    //save
    public Inscrire inscrireEtudiant(String[] donnee) {
        Inscrire inscrire = new Inscrire();
        //recuperation
        Site site = siteRepository.getReferenceById(Integer.valueOf(donnee[0]));
        String cours = donnee[1];
        Filiere filiere = filiereRepository.getReferenceById(Integer.valueOf(donnee[2]));
        Anneeuv anneeuv = anneeuvRepository.getReferenceById(Integer.valueOf(donnee[3]));
        Etudiant etudiant = etudiantRepository.getReferenceById(Integer.valueOf(donnee[4]));
        //instance
        inscrire.setRive(site);
        inscrire.setCours(cours);
        inscrire.setFiliere(filiere);
        inscrire.setAnneeuv(anneeuv);
        inscrire.setEtudiant(etudiant);
        inscrire.setDateajout(donnee[5]);
        inscrire.setHeureajout(donnee[6]);
        inscrire.setObservation("RAS");

        return inscrireRepository.save(inscrire);
    }
    //nombre etudiant par cycle
    public NombreEtudiantParSite nombreetudiantparsite(int an, int site){
        //nombre d'etudiant par site
        NombreEtudiantParSite nombreEtudiantParSite = new NombreEtudiantParSite();
        List<NombreEtudiantParCycle> nombreEtudiantParCycles = new ArrayList<>();
        //nombre d'etudiant par cycle
        List<Cycle> cycles = cycleRepository.findAll();
        for (Cycle cycle: cycles){
            NombreEtudiantParCycle nombreEtudiantParCycle = new NombreEtudiantParCycle();
            nombreEtudiantParCycle.setCycle(cycle);
            List<Filiere> filieres = filiereRepository.filieresparcycle(cycle.getId());
            List<NombreEtudiantParFiliere> nombreEtudiantParFilieres = new ArrayList<>();
            for(Filiere filiere: filieres){
                NombreEtudiantParFiliere nombreEtudiantParFiliere = new NombreEtudiantParFiliere();
                nombreEtudiantParFiliere.setFiliere(filiere);
                //nombre d'etudiant
                int nombre = inscrireRepository.NombreEtudiantParFiliere(an,filiere.getId(),site).orElse(0);
                nombreEtudiantParFiliere.setNombreEtudiant(nombre);
                nombreEtudiantParFilieres.add(nombreEtudiantParFiliere);
            }
            nombreEtudiantParCycle.setNombreEtudiantParFilieres(nombreEtudiantParFilieres);
            //somme des etudiants
            int totalparcycle = nombreEtudiantParFilieres.stream().mapToInt(NombreEtudiantParFiliere::getNombreEtudiant).sum();
            nombreEtudiantParCycle.setNombreEtudiant(totalparcycle);
            nombreEtudiantParCycles.add(nombreEtudiantParCycle);
        }
        //total etudiant du cycle
        nombreEtudiantParSite.setNombreEtudiantParCycles(nombreEtudiantParCycles);
        //nombre total par site
        int totaletudiant = nombreEtudiantParCycles.stream().mapToInt(NombreEtudiantParCycle::getNombreEtudiant).sum();
        nombreEtudiantParSite.setNombreEtudiant(totaletudiant);
        nombreEtudiantParSite.setSite(siteRepository.getReferenceById(site));
        return nombreEtudiantParSite;
    }
    /*public List<Inscrire> inscritparAnCoursFiliere(int annee, int cours, int filiere){
        List<Inscrire> inscrires = inscrireRepository.EtudiantParClasse(annee,cours,filiere);
        return  inscrires;
    }*/
    //nombre d'inscrit par filiere an et tupe de cours
    public Integer nombreParTypeCours(int site, int an, int filiere, String cours){
        Integer nmb = inscrireRepository.nombreParTypeCours(site, an,filiere,cours);
        return nmb;
    }
    public  List<Inscrire> getAll(){
        List<Inscrire> inscrires = inscrireRepository.findAllAnneeuvInscrires();
        return inscrires;
    }
    public List<Etudiant> EtudiantParFiliereAnneeCours(int an, int cours, int filiere, int site){
        String cour; int rive = site;
        if(cours == 1){ cour = "JOUR";}else{ cour = "SOIR";}
        List<Etudiant> etudiants = new ArrayList<>();
        List<Inscrire> inscrires;
        if(rive == 0){
            inscrires = inscrireRepository.EtudiantParClasse(an,cour,filiere);
        }else {
            inscrires = inscrireRepository.EtudiantParClasse(an, cour, filiere, rive);
        }

        for (Inscrire inscrire: inscrires){
            Etudiant e = new Etudiant();
            e.setId(inscrire.getEtudiant().getId());
            e.setMatricule(inscrire.getEtudiant().getMatricule());
            e.setPassword(inscrire.getEtudiant().getPassword());
            e.setNom(inscrire.getEtudiant().getNom());
            e.setPrenom(inscrire.getEtudiant().getPrenom());
            e.setTelephone(inscrire.getEtudiant().getTelephone());
            e.setNaissance(inscrire.getEtudiant().getNaissance());
            String g;
            if(inscrire.getEtudiant().getGenre() == "M"){g = "Masculin";}else {g = "Feminin";}
            e.setGenre(g);
            e.setPrenompere(inscrire.getEtudiant().getPrenompere());
            e.setPrenommere(inscrire.getEtudiant().getPrenommere());
            e.setNommere(inscrire.getEtudiant().getNommere());
            e.setNationalite(inscrire.getEtudiant().getNationalite());
            e.getLabel();
            etudiants.add(e);
        }
        return etudiants;
    }
    public int NombreEtudiant(int an){
        int nombre = inscrireRepository.nombreInscrit(an);
        return nombre;
    }

    public List<NombreEtudiantParFiliere> nombreetudiantparfiliere(int an, int site) {
        List<NombreEtudiantParFiliere> nombreEtudiantParFilieres = new ArrayList<>();
        List<Filiere> filieres = filiereRepository.findByOrderByNomAsc();
        for (Filiere filiere: filieres){
            NombreEtudiantParFiliere nombreEtudiantParFiliere = new NombreEtudiantParFiliere();
            nombreEtudiantParFiliere.setFiliere(filiere);
            int nombre = inscrireRepository.NombreEtudiantParFiliere(an,filiere.getId(),site).orElse(0);
            nombreEtudiantParFiliere.setNombreEtudiant(nombre);
            nombreEtudiantParFilieres.add(nombreEtudiantParFiliere);
        }
        return nombreEtudiantParFilieres;
    }


}
