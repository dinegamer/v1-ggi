package org.groupeintec.gestion.service;

import org.groupeintec.gestion.model.Classe;
import org.groupeintec.gestion.model.Classeecole;
import org.groupeintec.gestion.repository.ClasseRepository;
import org.groupeintec.gestion.repository.ClasseecoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ClasseService {
    @Autowired
    private ClasseRepository classeRepository;
    @Autowired
    private ClasseecoleRepository classeecoleRepository;
    public List<Classe> getAllClasses() {
        return classeRepository.findAll();
    }

    public Optional<Classe> getClasseById(int id) {
        return classeRepository.findById(id);
    }

    public Classe createClasse(Classe classe) {
        return classeRepository.save(classe);
    }

    public Classe updateClasse(int id, Classe classeDetails) {
        Classe classe = classeRepository.findById(id).orElseThrow(() -> new RuntimeException("Classe non trouvée"));
        classe.setNom(classeDetails.getNom());
        classe.setDescription(classeDetails.getDescription());
        classe.setFiliere(classeDetails.getFiliere());
        classe.setOptions(classeDetails.getOptions());
        return classeRepository.save(classe);
    }

    public void deleteClasse(int id) {
        classeRepository.deleteById(id);
    }

    public List<Classe> findClasseByEcoleId(int ecoleId) {
        List<Classeecole> classeecoles = classeecoleRepository.findClasseByEcoleIdEcole(ecoleId);
        List<Classe> classes = classeecoles.stream()
                .map(Classeecole::getClasse)
                .collect(Collectors.toList());

        return classes;
    }
}
