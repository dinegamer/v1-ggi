package org.groupeintec.gestion.controller;

import org.groupeintec.gestion.model.Fraiscolaire;
import org.groupeintec.gestion.service.FraiscolaireService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/fraiscolaires")
public class FraiscolaireController {
    @Autowired
    private FraiscolaireService fraiscolaireService;

    @GetMapping
    public List<Fraiscolaire> getAllFraiscolaires() {
        return fraiscolaireService.getAllFraiscolaires();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Fraiscolaire> getFraiscolaireById(@PathVariable int id) {
        Optional<Fraiscolaire> fraiscolaire = fraiscolaireService.getFraiscolaireById(id);
        return fraiscolaire.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).build());
    }

    @PostMapping
    public ResponseEntity<Fraiscolaire> createFraiscolaire(@RequestBody Fraiscolaire fraiscolaire) {
        Fraiscolaire createdFraiscolaire = fraiscolaireService.createFraiscolaire(fraiscolaire);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdFraiscolaire);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Fraiscolaire> updateFraiscolaire(@PathVariable int id, @RequestBody Fraiscolaire fraiscolaire) {
        Fraiscolaire updatedFraiscolaire = fraiscolaireService.updateFraiscolaire(id, fraiscolaire);
        return updatedFraiscolaire != null ? ResponseEntity.ok(updatedFraiscolaire)
                : ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteFraiscolaire(@PathVariable int id) {
        return fraiscolaireService.deleteFraiscolaire(id) ? ResponseEntity.noContent().build()
                : ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }

}
