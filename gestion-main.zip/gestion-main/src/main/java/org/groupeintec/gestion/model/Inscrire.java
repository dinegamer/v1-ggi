package org.groupeintec.gestion.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Table(name = "inscrire")
@AllArgsConstructor
@NoArgsConstructor
public class Inscrire {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "rive")
    private Site rive;
    private String cours;
    private String observation;

    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "filiere")
    private Filiere filiere;

    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "anneeuv")
    private Anneeuv anneeuv;

    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "etudiant")
    private Etudiant etudiant;

    private String dateajout;
    private String heureajout;
}
